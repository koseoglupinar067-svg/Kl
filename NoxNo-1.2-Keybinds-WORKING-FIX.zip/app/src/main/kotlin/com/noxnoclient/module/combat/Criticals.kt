
package com.noxnoclient.module.combat

import com.noxnoclient.utils.CombatUtil
import com.noxnoclient.events.PacketEvent
import com.noxnoclient.events.PacketEventBus
import com.noxnoclient.module.*
import kotlinx.coroutines.*
import org.cloudburstmc.protocol.bedrock.data.inventory.transaction.InventoryTransactionType
import org.cloudburstmc.protocol.bedrock.packet.InventoryTransactionPacket

class Criticals : BaseModule(
    name        = "Criticals",
    category    = ModuleCategory.COMBAT,
    description = "Makes every hit critical (ULTRA FAST)"
) {
    enum class CritMode {
        Vanilla,
        Fast,
        UltraFast,
        Packet
    }

    companion object {

        private const val CRIT_LOCK_KEY = "crit-injection-criticals"

        private const val TPAURA_CONFLICT_WINDOW_MS = 120L
    }

    private fun tpAuraRecentlyMovedSelf(): Boolean =
        System.currentTimeMillis() - TPAura.lastPositionOverrideMs < TPAURA_CONFLICT_WINDOW_MS

    private val mode     = enum ("Mode",      CritMode.Fast)
    private val cooldown = int  ("Cooldown",  0, 0, 100)
    private val shortcut = bool ("Shortcut",  false)

    @Volatile private var lastCritMs = 0L

    override fun onPacket(event: PacketEvent) {
        if (!isEnabled) return
        if (event.direction != PacketEvent.Direction.CLIENT_TO_SERVER) return
        val pkt = event.packet as? InventoryTransactionPacket ?: return

        val isAttack = pkt.transactionType == InventoryTransactionType.ITEM_USE_ON_ENTITY &&
                       pkt.actionType == 1

        if (!isAttack) return

        val now = System.currentTimeMillis()
        if (now - lastCritMs < cooldown.value) return

        val session = PacketEventBus.currentSession ?: return

        if (tpAuraRecentlyMovedSelf()) {

            return
        }

        event.cancel()

        scope.launch {

            val acquired = CombatUtil.tryRunWait(CRIT_LOCK_KEY, timeoutMs = 30L) {
                lastCritMs = now
                when (mode.value) {
                    CritMode.Vanilla    -> injectVanilla(session, pkt)
                    CritMode.Fast       -> injectFast(session, pkt)
                    CritMode.UltraFast  -> injectUltraFast(session, pkt)
                    CritMode.Packet     -> injectPacket(session, pkt)
                }
            }

            if (!acquired) session.serverBound(pkt)
        }
    }

    private suspend fun injectFast(s: com.noxnoclient.core.relay.NoxNoRelaySession, pkt: InventoryTransactionPacket) {
        CombatUtil.sendMoveAtSelf(s, dyOffset = 0.42f, onGround = false)
        delay(10L)
        CombatUtil.sendMoveAtSelf(s, dyOffset = 0.0f, onGround = false)
        delay(5L)
        s.serverBound(pkt)
        CombatUtil.sendMoveAtSelf(s, dyOffset = 0.0f, onGround = true)
    }

    private suspend fun injectUltraFast(s: com.noxnoclient.core.relay.NoxNoRelaySession, pkt: InventoryTransactionPacket) {
        CombatUtil.sendMoveAtSelf(s, dyOffset = 0.42f, onGround = false)
        delay(5L)
        s.serverBound(pkt)
        CombatUtil.sendMoveAtSelf(s, dyOffset = 0.0f, onGround = true)
    }

    private suspend fun injectVanilla(s: com.noxnoclient.core.relay.NoxNoRelaySession, pkt: InventoryTransactionPacket) {

        listOf(0.42f, 0.1f).forEach { dy ->
            CombatUtil.sendMoveAtSelf(s, dyOffset = dy, onGround = false)
            delay(8L)
        }
        s.serverBound(pkt)
        CombatUtil.sendMoveAtSelf(s, dyOffset = 0.0f, onGround = true)
    }

    private suspend fun injectPacket(s: com.noxnoclient.core.relay.NoxNoRelaySession, pkt: InventoryTransactionPacket) {
        CombatUtil.sendMoveAtSelf(s, dyOffset = 0.001f, onGround = false)
        delay(2L)
        s.serverBound(pkt)
        CombatUtil.sendMoveAtSelf(s, dyOffset = 0.0f, onGround = true)
    }
}
