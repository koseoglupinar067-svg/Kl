package com.noxnoclient.utils

import com.noxnoclient.core.proxy.EntityTracker
import com.noxnoclient.events.PacketEvent
import com.noxnoclient.events.PacketEventBus
import io.netty.buffer.ByteBuf
import io.netty.buffer.ByteBufInputStream
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.ConcurrentLinkedQueue
import kotlin.math.floor
import org.cloudburstmc.math.vector.Vector3i
import org.cloudburstmc.nbt.NbtMap
import org.cloudburstmc.nbt.NbtUtils
import org.cloudburstmc.protocol.bedrock.packet.ChangeDimensionPacket
import org.cloudburstmc.protocol.bedrock.packet.ClientCacheStatusPacket
import org.cloudburstmc.protocol.bedrock.packet.LevelChunkPacket
import org.cloudburstmc.protocol.bedrock.packet.StartGamePacket
import org.cloudburstmc.protocol.bedrock.packet.SubChunkPacket
import org.cloudburstmc.protocol.bedrock.packet.UpdateBlockPacket
import org.cloudburstmc.protocol.bedrock.packet.UpdateSubChunkBlocksPacket

object WorldBlockTracker : PacketEventBus.PacketListener {

    private const val TAG = "WorldBlockTracker"
    private const val SECTION_BLOCKS = 4096

    private val sections = ConcurrentHashMap<Long, IntArray>()

    private val persistentPalettes = ConcurrentHashMap<Long, Array<String?>>()

    private val insertOrder = ConcurrentLinkedQueue<Long>()

    private const val MAX_SECTIONS = 4096

    private val overrides = ConcurrentHashMap<Long, Int>()

    private val identifierCache = ConcurrentHashMap<Int, String>()

    private val statChunksReceived    = java.util.concurrent.atomic.AtomicInteger(0)
    private val statSkippedNoSubCount = java.util.concurrent.atomic.AtomicInteger(0)
    private val statSkippedStreamed   = java.util.concurrent.atomic.AtomicInteger(0)
    private val statSkippedCaching    = java.util.concurrent.atomic.AtomicInteger(0)
    private val statSkippedNoBuf      = java.util.concurrent.atomic.AtomicInteger(0)
    private val statDecodeFailed      = java.util.concurrent.atomic.AtomicInteger(0)
    private val statSectionsStored    = java.util.concurrent.atomic.AtomicInteger(0)
    @Volatile private var lastException: String? = null
    @Volatile private var lastVersionByte: Int = -1

    @Volatile private var curTrace: StringBuilder? = null
    @Volatile private var curChunkCx: Int = 0
    @Volatile private var curChunkCz: Int = 0
    @Volatile private var curChunkBufStart: Int = 0
    @Volatile private var curSubIndex: Int = -1
    @Volatile private var curSubSy: Int = 0

    @Volatile private var lastConsumedTailHex: String = "-"

    fun debugSummary(): String =
        "chunks=${statChunksReceived.get()} skip_noSubCount=${statSkippedNoSubCount.get()} " +
        "skip_streamed=${statSkippedStreamed.get()} " +
        "skip_caching=${statSkippedCaching.get()} skip_noBuf=${statSkippedNoBuf.get()} " +
        "decodeFailed=${statDecodeFailed.get()} sectionsStored=${statSectionsStored.get()} " +
        "lastEx=${lastException ?: "-"} lastVersionByte=$lastVersionByte"

    init {

        register()
    }

    fun init() = register()

    private fun register() {
        PacketEventBus.register(this)
    }

    fun reset() {
        sections.clear(); insertOrder.clear(); overrides.clear(); persistentPalettes.clear()
        statChunksReceived.set(0); statSkippedNoSubCount.set(0); statSkippedStreamed.set(0)
        statSkippedCaching.set(0)
        statSkippedNoBuf.set(0); statDecodeFailed.set(0); statSectionsStored.set(0)
        lastException = null
        lastVersionByte = -1
        curTrace = null
        lastConsumedTailHex = "-"
    }

    @Volatile private var loggedCacheOverride = false

    private fun handleClientCacheStatus(event: PacketEvent, p: ClientCacheStatusPacket) {
        if (p.isSupported) {
            p.isSupported = false
            if (!loggedCacheOverride) {
                loggedCacheOverride = true
            }
            event.cancelAndReplace(p)
        }
    }

    override fun onPacket(event: PacketEvent) {
        when (val p = event.packet) {
            is SubChunkPacket -> handleSubChunkPacket(p)
            is LevelChunkPacket -> handleLevelChunkPacket(p)
            is UpdateBlockPacket -> handleUpdateBlock(p)
            is UpdateSubChunkBlocksPacket -> handleUpdateSubChunkBlocks(p)
            is ClientCacheStatusPacket -> handleClientCacheStatus(event, p)
            is ChangeDimensionPacket -> reset()

            is StartGamePacket -> reset()
            else -> {}
        }
    }

    fun hasAnyTerrainData(): Boolean = sections.isNotEmpty()

    fun getBlockIdentifier(x: Int, y: Int, z: Int): String? {

        val posKey = blockPosKey(x, y, z)
        overrides[posKey]?.let { return resolveIdentifier(it) }

        val cx = x shr 4
        val cz = z shr 4
        val sy = y shr 4
        val key = sectionKey(cx, sy, cz)
        val arr = sections[key] ?: return null

        val lx = x and 15
        val ly = y and 15
        val lz = z and 15

        val idx = (lx shl 8) or (lz shl 4) or ly
        val runtimeId = arr[idx]

        if (runtimeId <= -2) {
            val paletteIdx = -(runtimeId + 2)
            val names = persistentPalettes[key] ?: return null
            val name = names.getOrNull(paletteIdx)
            return if (name.isNullOrBlank()) null else name
        }
        if (runtimeId < 0) return null

        return resolveIdentifier(runtimeId)
    }

    fun isBlock(x: Int, y: Int, z: Int, vararg identifiers: String): Boolean {
        val id = getBlockIdentifier(x, y, z) ?: return false
        return identifiers.any { it == id }
    }

    internal inline fun forEachBlockInRange(
        centerX: Int, centerY: Int, centerZ: Int, radius: Int,
        crossinline predicate: (String) -> Boolean,
        crossinline onMatch: (x: Int, y: Int, z: Int, identifier: String) -> Unit
    ) {
        val minCx = (centerX - radius) shr 4
        val maxCx = (centerX + radius) shr 4
        val minCz = (centerZ - radius) shr 4
        val maxCz = (centerZ + radius) shr 4
        val minSy = (centerY - radius) shr 4
        val maxSy = (centerY + radius) shr 4

        for (cx in minCx..maxCx) {
            for (cz in minCz..maxCz) {
                for (sy in minSy..maxSy) {
                    val key = sectionKey(cx, sy, cz)
                    val arr = sections[key] ?: continue
                    val baseX = cx shl 4
                    val baseY = sy shl 4
                    val baseZ = cz shl 4

                    for (idx in 0 until SECTION_BLOCKS) {
                        val ly = idx and 15
                        val lz = (idx shr 4) and 15
                        val lx = (idx shr 8) and 15
                        val wx = baseX + lx
                        val wy = baseY + ly
                        val wz = baseZ + lz

                        val dx = wx - centerX
                        val dy = wy - centerY
                        val dz = wz - centerZ
                        if (dx * dx + dy * dy + dz * dz > radius * radius) continue

                        val posKey = blockPosKey(wx, wy, wz)
                        val override = overrides[posKey]
                        val identifier = if (override != null) {
                            resolveIdentifier(override)
                        } else {
                            val runtimeId = arr[idx]
                            if (runtimeId <= -2) {
                                val paletteIdx = -(runtimeId + 2)
                                val names = persistentPalettes[key]
                                names?.getOrNull(paletteIdx)?.takeIf { it.isNotBlank() }
                            } else if (runtimeId < 0) {
                                null
                            } else {
                                resolveIdentifier(runtimeId)
                            }
                        } ?: continue

                        if (predicate(identifier)) onMatch(wx, wy, wz, identifier)
                    }
                }
            }
        }
    }

    fun hasData(x: Int, y: Int, z: Int): Boolean {
        if (overrides.containsKey(blockPosKey(x, y, z))) return true
        val cx = x shr 4; val cz = z shr 4; val sy = y shr 4
        return sections.containsKey(sectionKey(cx, sy, cz))
    }

    private val WATER_IDS = arrayOf(
        "minecraft:water", "minecraft:flowing_water", "minecraft:bubble_column"
    )

    fun isPlayerInWater(): Boolean {
        val bx = floor(EntityTracker.selfX).toInt()
        val bz = floor(EntityTracker.selfZ).toInt()
        val feetY = floor(EntityTracker.selfY).toInt()
        val eyeY  = floor(EntityTracker.selfY + 1.2f).toInt()

        if (!hasData(bx, feetY, bz) && !hasData(bx, eyeY, bz)) return false

        return isBlock(bx, feetY, bz, *WATER_IDS) || isBlock(bx, eyeY, bz, *WATER_IDS)
    }

    private fun handleUpdateBlock(p: UpdateBlockPacket) {
        if (p.dataLayer != 0) return
        val runtimeId = runCatching { p.definition?.runtimeId }.getOrElse { null } ?: return
        val pos = p.blockPosition ?: return
        overrides[blockPosKey(pos.x, pos.y, pos.z)] = runtimeId
    }

    private fun handleUpdateSubChunkBlocks(p: UpdateSubChunkBlocksPacket) {
        for (entry in p.standardBlocks) {
            val runtimeId = runCatching { entry.definition?.runtimeId }.getOrElse { null } ?: continue
            val pos = entry.position ?: continue
            overrides[blockPosKey(pos.x, pos.y, pos.z)] = runtimeId
        }
    }

    private fun handleSubChunkPacket(p: SubChunkPacket) {

        val origin = resolveSubChunkOrigin(p)
        for (sub in p.subChunks) {
            try {
                val rel = sub.position ?: continue
                val buf = sub.data ?: continue
                if (!buf.isReadable) continue

                val decoded = decodeSubChunkBlocks(buf.duplicate())
                if (decoded == null) continue

                storeSection(origin.x + rel.x, origin.y + rel.y, origin.z + rel.z, decoded.first, decoded.second)
            } catch (e: Exception) {
            }
        }
    }

    private fun resolveSubChunkOrigin(p: SubChunkPacket): org.cloudburstmc.math.vector.Vector3i {
        for (name in listOf("centerPosition", "position", "origin", "basePosition")) {
            try {
                val m = p.javaClass.getMethod(name)
                val v = m.invoke(p)
                if (v is org.cloudburstmc.math.vector.Vector3i) return v
            } catch (_: Exception) {}
        }
        return org.cloudburstmc.math.vector.Vector3i.ZERO
    }

    fun handleLevelChunkPacket(p: LevelChunkPacket) {
        statChunksReceived.incrementAndGet()
        try {
            val cachingEnabled = p.isCachingEnabled()

            if (cachingEnabled) statSkippedCaching.incrementAndGet()

            if (p.isRequestSubChunks) {
                statSkippedStreamed.incrementAndGet()
                return
            }

            val buf = p.data
            if (buf == null || !buf.isReadable) { statSkippedNoBuf.incrementAndGet(); return }

            val subChunksLength = resolveSubChunkCount(p)

            val cx = p.chunkX
            val cz = p.chunkZ
            val dim = EntityTracker.selfDimension
            val minSectionY = if (dim == 0) -4 else 0

            val dup = buf.duplicate()
            var storedAny = false

            val trace = StringBuilder()
            curTrace = trace
            curChunkCx = cx
            curChunkCz = cz
            curChunkBufStart = dup.readerIndex()
            lastConsumedTailHex = "-"

            if (subChunksLength > 0) {
                var consecutiveErrors = 0
                for (i in 0 until subChunksLength) {
                    if (!dup.isReadable) { trace.append("i=$i EOF\n"); break }
                    val fallbackSy = minSectionY + i
                    curSubIndex = i; curSubSy = fallbackSy
                    val decoded = decodeSubChunkBlocks(dup)
                    if (decoded == null) {
                        consecutiveErrors++
                        if (consecutiveErrors >= 3) break
                        continue
                    }

                    val sy = decoded.third ?: fallbackSy
                    if (decoded.first.isEmpty()) {

                        storeSection(cx, sy, cz, IntArray(SECTION_BLOCKS), null)
                        consecutiveErrors = 0; continue
                    }
                    consecutiveErrors = 0
                    storeSection(cx, sy, cz, decoded.first, decoded.second)
                    statSectionsStored.incrementAndGet()
                    storedAny = true
                }
            } else {
                statSkippedNoSubCount.incrementAndGet()
                var sy = minSectionY
                var consecutiveErrors = 0
                var i = 0
                while (dup.isReadable && sy < minSectionY + 24) {
                    curSubIndex = i; curSubSy = sy
                    val decoded = decodeSubChunkBlocks(dup)
                    if (decoded == null) {
                        consecutiveErrors++
                        if (consecutiveErrors >= 3) break
                        sy++; i++; continue
                    }
                    val realSy = decoded.third ?: sy
                    if (decoded.first.isEmpty()) {
                        storeSection(cx, realSy, cz, IntArray(SECTION_BLOCKS), null)
                        sy++; i++; consecutiveErrors = 0; continue
                    }
                    consecutiveErrors = 0
                    storeSection(cx, realSy, cz, decoded.first, decoded.second)
                    statSectionsStored.incrementAndGet()
                    storedAny = true
                    sy++; i++
                }
            }

            if (!storedAny) {
                val traceStr = trace.toString()
                val allAir = traceStr.lines()
                    .filter { it.startsWith("i=") }
                    .all { it.contains("blocks=0 ok=true") }

                if (!allAir) {
                    statDecodeFailed.incrementAndGet()
                }
            }
            curTrace = null
        } catch (e: Exception) {
            lastException = "${e::class.simpleName}: ${e.message}"
            statDecodeFailed.incrementAndGet()
            curTrace = null
        }
    }

    private fun resolveSubChunkCount(p: LevelChunkPacket): Int {

        for (methodName in listOf("getSubChunksLength", "getSubChunkLimit", "getSubChunkCount", "getSectionCount")) {
            try {
                val v = p.javaClass.getMethod(methodName).invoke(p)
                if (v is Int && v > 0) return v
            } catch (_: Exception) {}
        }

        var cls: Class<*>? = p.javaClass
        while (cls != null) {
            for (fieldName in listOf("subChunksLength", "subChunkLimit", "subChunkCount", "sectionCount")) {
                try {
                    val f = cls.getDeclaredField(fieldName)
                    f.isAccessible = true
                    val v = f.get(p)
                    if (v is Int && v > 0) return v
                } catch (_: Exception) {}
            }
            cls = cls.superclass
        }
        return -1
    }

    private fun storeSection(cx: Int, sy: Int, cz: Int, blocks: IntArray, names: Array<String?>?) {
        val key = sectionKey(cx, sy, cz)

        val isUpdate = sections.containsKey(key)
        sections[key] = blocks
        if (names != null) persistentPalettes[key] = names else persistentPalettes.remove(key)

        if (isUpdate) insertOrder.remove(key)
        insertOrder.add(key)

        while (insertOrder.size > MAX_SECTIONS) {
            val old = insertOrder.poll() ?: break
            sections.remove(old)
            persistentPalettes.remove(old)
        }
    }

    private fun decodeSubChunkBlocks(buf: ByteBuf): Triple<IntArray, Array<String?>?, Int?>? {
        if (buf.readableBytes() < 2) {
            curTrace?.append("i=$curSubIndex sy=$curSubSy EOF(readable=${buf.readableBytes()})\n")
            return null
        }
        val startIdx = buf.readerIndex()
        val relOffset = startIdx - curChunkBufStart
        lastVersionByte = buf.getUnsignedByte(startIdx).toInt()
        val result = try {
            tryDecode(buf)
        } catch (e: Exception) {
            lastException = "${e::class.simpleName}: ${e.message}"
            curTrace?.append("i=$curSubIndex sy=$curSubSy off=$relOffset ver=$lastVersionByte EXCEPTION=${e::class.simpleName}:${e.message}\n")
            null
        }
        val consumed = buf.readerIndex() - startIdx
        if (result != null) {
            curTrace?.append(
                "i=$curSubIndex sy=$curSubSy off=$relOffset ver=$lastVersionByte consumed=$consumed " +
                    "blocks=${result.first.size} ok=true\n"
            )
            val tailStart = maxOf(startIdx, buf.readerIndex() - 8)
            lastConsumedTailHex = (tailStart until buf.readerIndex()).joinToString(" ") {
                buf.getUnsignedByte(it).toString(16).padStart(2, '0')
            }
        } else if (buf.readableBytes() >= 0 && consumed >= 0) {

            curTrace?.append("i=$curSubIndex sy=$curSubSy off=$relOffset ver=$lastVersionByte consumed=$consumed ok=false\n")
        }
        return result
    }

    private fun tryDecode(buf: ByteBuf): Triple<IntArray, Array<String?>?, Int?>? {
        val hexDump = (0 until minOf(8, buf.readableBytes())).joinToString(" ") {
            buf.getUnsignedByte(buf.readerIndex() + it).toString(16).padStart(2, '0')
        }

        var realSy: Int? = null
        val version = buf.readUnsignedByte().toInt()
        val storageCount: Int
        when (version) {
            1 -> storageCount = 1
            8 -> storageCount = buf.readUnsignedByte().toInt()
            9 -> {

                storageCount = buf.readUnsignedByte().toInt()
                realSy = buf.readByte().toInt()
                if (storageCount == 0) return Triple(IntArray(0), null, realSy)
            }
            else -> {
                lastException = "raw=$hexDump unknown_version=$version"
                return null
            }
        }
        if (storageCount <= 0 || storageCount > 8) {
            lastException = "raw=$hexDump bad_sc=$storageCount ver=$version"
            return null
        }

        var primary: IntArray? = null
        var primaryNames: Array<String?>? = null
        repeat(storageCount) { idx ->
            val storage = readBlockStorage(buf) ?: return null
            if (idx == 0) { primary = storage.first; primaryNames = storage.second }
        }
        val p = primary ?: return null
        return Triple(p, primaryNames, realSy)
    }

    private fun readBlockStorage(buf: ByteBuf): Pair<IntArray, Array<String?>?>? {
        val header = buf.readUnsignedByte().toInt()
        val bitsPerBlock = header ushr 1
        if (bitsPerBlock !in intArrayOf(0, 1, 2, 3, 4, 5, 6, 8, 16)) return null

        if (bitsPerBlock == 0) {
            val id = readSignedVarInt(buf)
            return IntArray(SECTION_BLOCKS) { id } to null
        }

        val indices = IntArray(SECTION_BLOCKS)
        val blocksPerWord = 32 / bitsPerBlock
        val wordCount = (SECTION_BLOCKS + blocksPerWord - 1) / blocksPerWord
        val mask = (1 shl bitsPerBlock) - 1
        var bi = 0
        repeat(wordCount) {
            val word = buf.readIntLE()
            var w = word
            var c = 0
            while (c < blocksPerWord && bi < SECTION_BLOCKS) {
                indices[bi] = w and mask
                w = w ushr bitsPerBlock
                bi++; c++
            }
        }

        val paletteSize = readSignedVarInt(buf)
        if (paletteSize <= 0 || paletteSize > 8192) return null
        val palette = IntArray(paletteSize) { readSignedVarInt(buf) }

        val result = IntArray(SECTION_BLOCKS) { i ->
            val p = indices[i]
            if (p < palette.size) palette[p] else 0
        }
        return result to null
    }

    private fun readSignedVarInt(buf: ByteBuf): Int {
        val raw = readUnsignedVarInt(buf)
        return (raw ushr 1) xor -(raw and 1)
    }

    private fun readUnsignedVarInt(buf: ByteBuf): Int {
        var result = 0
        var shift = 0
        while (true) {
            val b = buf.readUnsignedByte().toInt()
            result = result or ((b and 0x7F) shl shift)
            if (b and 0x80 == 0) break
            shift += 7
            if (shift > 35) throw IllegalStateException("VarInt too long")
        }
        return result
    }

    internal fun resolveIdentifier(runtimeId: Int): String? {
        identifierCache[runtimeId]?.let { return it }
        val session = PacketEventBus.currentSession ?: return null

        fun extract(def: Any?): String? = when (def) {
            is org.cloudburstmc.protocol.bedrock.data.definitions.SimpleBlockDefinition -> def.identifier
            is com.noxnoclient.core.relay.Definitions.NbtBlockDefinitionRegistry.NbtBlockDefinition -> def.tag.getString("name")
            else -> null
        }

        val primary = runCatching {
            extract(session.clientSession.peer.codecHelper.blockDefinitions?.getDefinition(runtimeId))
        }.getOrNull()

        if (primary != null) {
            identifierCache[runtimeId] = primary
            return primary
        }

        val fallback = runCatching {
            extract(
                com.noxnoclient.core.relay.Definitions
                    .getClosestDefinitions(session.activeCodec.protocolVersion)
                    .blockDefinitions
                    ?.getDefinition(runtimeId)
            )
        }.getOrNull() ?: return null

        identifierCache[runtimeId] = fallback
        return fallback
    }

    private fun sectionKey(cx: Int, sy: Int, cz: Int): Long {
        val cxL = cx.toLong() and 0xFFFFFFL
        val syL = (sy + 128).toLong() and 0xFFL
        val czL = cz.toLong() and 0xFFFFFFL
        return (cxL shl 32) or (syL shl 24) or czL
    }

    private fun blockPosKey(x: Int, y: Int, z: Int): Long =
        ((x.toLong() and 0x3FFFFFFL) shl 38) or
        ((y.toLong() and 0xFFFL) shl 26) or
        (z.toLong() and 0x3FFFFFFL)
}

object ChunkParser {

    private const val TAG = "ChunkParser"
    private const val MAX_SUBCHUNKS = 64
    private const val MAX_SCAN_ATTEMPTS = 512

    data class ParsedBlockEntity(val x: Int, val y: Int, val z: Int, val tag: NbtMap)

    fun extractBlockEntities(pkt: LevelChunkPacket, subChunkCount: Int? = null): List<ParsedBlockEntity> {
        val original = readDataField(pkt) ?: run {
            return emptyList()
        }

        val buf = original.duplicate()

        return try {
            val count = subChunkCount ?: resolveSubChunkCount(pkt) ?: run {
                -1
            }

            if (count >= 0) skipKnownSubChunks(buf, count) else skipSubChunksByVersionByte(buf)

            val direct = tryParseCompoundsFrom(buf.duplicate())
            if (direct.isNotEmpty()) return direct

            scanForCompounds(buf)
        } catch (e: Exception) {
            emptyList()
        }
    }

    private fun readDataField(pkt: LevelChunkPacket): ByteBuf? {

        try { return pkt.data } catch (_: Throwable) {}
        return try {
            val m = pkt.javaClass.methods.firstOrNull { it.name == "getData" && it.parameterCount == 0 }
            m?.invoke(pkt) as? ByteBuf
        } catch (_: Exception) { null }
    }

    private fun resolveSubChunkCount(pkt: LevelChunkPacket): Int? {
        val direct = try { pkt.subChunksLength } catch (_: Throwable) { 0 }
        if (direct in 1..MAX_SUBCHUNKS) return direct

        for (methodName in listOf("getSubChunkCount", "getSubChunkLimit", "getSectionCount")) {
            try {
                val m = pkt.javaClass.getMethod(methodName)
                val v = m.invoke(pkt)
                if (v is Int && v in 0..MAX_SUBCHUNKS) return v
            } catch (_: Exception) {}
        }
        return null
    }

    private fun skipKnownSubChunks(buf: ByteBuf, count: Int) {
        repeat(count.coerceAtMost(MAX_SUBCHUNKS)) {
            if (!buf.isReadable) return
            skipOneSubChunk(buf)
        }
    }

    private fun skipSubChunksByVersionByte(buf: ByteBuf) {
        var i = 0
        while (buf.isReadable && i < MAX_SUBCHUNKS) {
            buf.markReaderIndex()
            val version = buf.readUnsignedByte().toInt()
            if (version != 1 && version != 8 && version != 9) {
                buf.resetReaderIndex()
                return
            }
            buf.resetReaderIndex()
            if (!trySkipOneSubChunk(buf)) return
            i++
        }
    }

    private fun trySkipOneSubChunk(buf: ByteBuf): Boolean = try {
        skipOneSubChunk(buf); true
    } catch (_: Exception) { false }

    private fun skipOneSubChunk(buf: ByteBuf) {
        val version = buf.readUnsignedByte().toInt()
        when (version) {
            1 -> skipBlockStorage(buf)
            8, 9 -> {
                val storageCount = buf.readUnsignedByte().toInt()
                if (version == 9) buf.readByte()
                repeat(storageCount) { skipBlockStorage(buf) }
            }
            else -> throw IllegalStateException("Unrecognized subchunk version=$version")
        }
    }

    private fun skipBlockStorage(buf: ByteBuf) {
        val header = buf.readUnsignedByte().toInt()
        val bitsPerBlock = header ushr 1
        val isPersistent = (header and 1) == 1

        if (isPersistent) {
            skipPersistentPalette(buf, bitsPerBlock)
            return
        }

        if (bitsPerBlock == 0) {

            readUnsignedVarInt(buf)
            return
        }

        val blocksPerWord = 32 / bitsPerBlock
        val wordCount = (4096 + blocksPerWord - 1) / blocksPerWord
        buf.skipBytes(wordCount * 4)

        val paletteSize = readUnsignedVarInt(buf)
        repeat(paletteSize) { readUnsignedVarInt(buf) }
    }

    private fun readUnsignedVarInt(buf: ByteBuf): Int {
        var result = 0
        var shift = 0
        while (true) {
            val b = buf.readUnsignedByte().toInt()
            result = result or ((b and 0x7F) shl shift)
            if (b and 0x80 == 0) break
            shift += 7
            if (shift > 35) throw IllegalStateException("VarInt too long")
        }
        return result
    }

    private fun skipPersistentPalette(buf: ByteBuf, bitsPerBlock: Int) {
        if (bitsPerBlock > 0) {
            val blocksPerWord = 32 / bitsPerBlock
            val wordCount = (4096 + blocksPerWord - 1) / blocksPerWord
            buf.skipBytes(wordCount * 4)
        }
        val paletteSize = readUnsignedVarInt(buf)
        if (paletteSize <= 0 || paletteSize > 8192) throw IllegalStateException("Invalid persistent palette size")

        val stream = ByteBufInputStream(buf)
        val reader = NbtUtils.createNetworkReader(stream)
        repeat(paletteSize) {
            reader.readTag()
        }
    }

    private fun tryParseCompoundsFrom(buf: ByteBuf): List<ParsedBlockEntity> {
        val result = mutableListOf<ParsedBlockEntity>()
        if (!buf.isReadable) return result
        try {
            val stream = ByteBufInputStream(buf)
            val reader = NbtUtils.createNetworkReader(stream)
            while (buf.isReadable) {
                val tag = reader.readTag() as? NbtMap ?: break
                toBlockEntity(tag)?.let { result.add(it) }
            }
        } catch (_: Exception) {

        }
        return result
    }

    private fun scanForCompounds(buf: ByteBuf): List<ParsedBlockEntity> {
        val result = mutableListOf<ParsedBlockEntity>()
        var attempts = 0
        val start = buf.readerIndex()
        val end = buf.writerIndex()
        var pos = start

        while (pos < end - 1 && attempts < MAX_SCAN_ATTEMPTS) {

            if (buf.getByte(pos) == 0x0A.toByte() && buf.getByte(pos + 1) == 0x00.toByte()) {
                attempts++
                val dup = buf.duplicate()
                dup.readerIndex(pos)
                try {
                    val tag = readOneCompound(dup)
                    if (tag != null) {
                        toBlockEntity(tag)?.let { result.add(it) }
                        pos = dup.readerIndex()
                        continue
                    }
                } catch (_: Exception) {  }
            }
            pos++
        }
        return result
    }

    private fun readOneCompound(buf: ByteBuf): NbtMap? {
        if (!buf.isReadable) return null
        val stream = ByteBufInputStream(buf)
        val reader = NbtUtils.createNetworkReader(stream)
        val tag = reader.readTag()
        return tag as? NbtMap
    }

    private fun toBlockEntity(tag: NbtMap): ParsedBlockEntity? {
        val x = tag.getInt("x", Int.MIN_VALUE)
        val y = tag.getInt("y", Int.MIN_VALUE)
        val z = tag.getInt("z", Int.MIN_VALUE)
        if (x == Int.MIN_VALUE || y == Int.MIN_VALUE || z == Int.MIN_VALUE) return null
        return ParsedBlockEntity(x, y, z, tag)
    }

    data class OreHit(val x: Int, val y: Int, val z: Int, val runtimeId: Int)

    const val OVERWORLD_MIN_SECTION = -4

    fun extractOreBlocks(
        pkt: LevelChunkPacket,
        isTarget: (Int) -> Boolean,
        minSectionIndex: Int = OVERWORLD_MIN_SECTION,
        subChunkCount: Int? = null
    ): List<OreHit> {
        val original = readDataField(pkt) ?: return emptyList()
        val buf = original.duplicate()

        val chunkX = pkt.chunkX
        val chunkZ = pkt.chunkZ
        val count = subChunkCount ?: resolveSubChunkCount(pkt) ?: return emptyList()

        val result = mutableListOf<OreHit>()
        return try {
            var sectionIndex = minSectionIndex
            repeat(count.coerceAtMost(MAX_SUBCHUNKS)) {
                if (buf.isReadable) {
                    decodeOneSubChunk(buf, chunkX, chunkZ, sectionIndex * 16, isTarget, result)
                }
                sectionIndex++
            }
            result
        } catch (e: Exception) {
            result
        }
    }

    private fun decodeOneSubChunk(
        buf: ByteBuf, chunkX: Int, chunkZ: Int, baseY: Int,
        isTarget: (Int) -> Boolean, out: MutableList<OreHit>
    ) {
        val version = buf.readUnsignedByte().toInt()
        when (version) {
            1 -> decodeBlockStorage(buf, chunkX, chunkZ, baseY, isTarget, out)
            8, 9 -> {
                val storageCount = buf.readUnsignedByte().toInt()
                if (version == 9) buf.readByte()
                repeat(storageCount) { layer ->

                    if (layer == 0) decodeBlockStorage(buf, chunkX, chunkZ, baseY, isTarget, out)
                    else skipBlockStorage(buf)
                }
            }
            else -> throw IllegalStateException("Unrecognized subchunk version=$version")
        }
    }

    private fun decodeBlockStorage(
        buf: ByteBuf, chunkX: Int, chunkZ: Int, baseY: Int,
        isTarget: (Int) -> Boolean, out: MutableList<OreHit>
    ) {
        val header = buf.readUnsignedByte().toInt()
        val bitsPerBlock = header ushr 1
        val isPersistent = (header and 1) == 1

        if (isPersistent) {
            skipPersistentPalette(buf, bitsPerBlock)
            return
        }

        if (bitsPerBlock == 0) {

            readUnsignedVarInt(buf)
            return
        }

        val blocksPerWord = 32 / bitsPerBlock
        val wordCount = (4096 + blocksPerWord - 1) / blocksPerWord
        val mask = (1 shl bitsPerBlock) - 1

        val words = IntArray(wordCount)
        for (w in 0 until wordCount) words[w] = buf.readIntLE()

        val paletteSize = readUnsignedVarInt(buf)
        val palette = IntArray(paletteSize)
        for (p in 0 until paletteSize) palette[p] = readUnsignedVarInt(buf)

        val paletteIsTarget = BooleanArray(paletteSize) { isTarget(palette[it]) }

        for (idx in 0 until 4096) {
            val w = idx / blocksPerWord
            val slot = idx % blocksPerWord
            val paletteIndex = (words[w] ushr (slot * bitsPerBlock)) and mask
            if (paletteIndex >= palette.size) continue
            if (!paletteIsTarget[paletteIndex]) continue

            val lx = idx shr 8
            val lz = (idx shr 4) and 0xF
            val ly = idx and 0xF

            out.add(OreHit(chunkX * 16 + lx, baseY + ly, chunkZ * 16 + lz, palette[paletteIndex]))
        }
    }
}

object BlockTracker {

    enum class TrackedBlockType(val displayName: String, val colorArgb: Int) {
        CHEST        ("Chest",        0xFFFF9B1A.toInt()),
        SHULKER_BOX  ("Shulker",      0xFFE040FB.toInt()),
        ENDER_CHEST  ("Ender Chest",  0xFF7C4DFF.toInt()),
        SPAWNER      ("Spawner",      0xFFFF1744.toInt()),
        HOPPER       ("Hopper",       0xFF00E5FF.toInt()),
        BARREL       ("Barrel",       0xFFFFD600.toInt()),
        TRAPPED_CHEST("Trapped Chest",0xFFFF6D00.toInt()),
        FURNACE      ("Furnace",      0xFFFF6E40.toInt()),
        BLAST_FURNACE("Blast Furnace",0xFFFF3D00.toInt()),
        SMOKER       ("Smoker",       0xFF69F0AE.toInt()),
        BREWING_STAND("Brewing Stand",0xFF40C4FF.toInt()),
        DISPENSER    ("Dispenser",    0xFF18FFFF.toInt()),
        DROPPER      ("Dropper",      0xFFFFFF00.toInt()),
    }

    data class TrackedBlock(
        val pos: Vector3i,
        val type: TrackedBlockType,
        val discoveredAt: Long = System.currentTimeMillis()
    )

    private val trackedBlocks = ConcurrentHashMap<Long, TrackedBlock>()

    private const val CELL_SHIFT = 4
    private val cellIndex = ConcurrentHashMap<Long, MutableSet<Long>>()

    private fun cellKey(x: Int, y: Int, z: Int): Long {
        val cx = x shr CELL_SHIFT
        val cy = y shr CELL_SHIFT
        val cz = z shr CELL_SHIFT
        return ((cx.toLong() and 0x1FFFFFL) shl 42) or
               ((cy.toLong() and 0xFFFL)    shl 21) or
               (cz.toLong() and 0x1FFFFFL)
    }

    fun packKey(x: Int, y: Int, z: Int): Long =
        ((x.toLong() and 0x3FFFFFFL) shl 38) or
        ((y.toLong() and 0xFFFL) shl 26) or
        (z.toLong() and 0x3FFFFFFL)

    fun add(x: Int, y: Int, z: Int, type: TrackedBlockType) {
        val key = packKey(x, y, z)
        trackedBlocks[key] = TrackedBlock(Vector3i.from(x, y, z), type)
        cellIndex.getOrPut(cellKey(x, y, z)) { ConcurrentHashMap.newKeySet() }.add(key)
    }

    fun remove(x: Int, y: Int, z: Int) {
        val key = packKey(x, y, z)
        trackedBlocks.remove(key)
        cellIndex[cellKey(x, y, z)]?.remove(key)
    }

    fun getAll(): Collection<TrackedBlock> = trackedBlocks.values

    fun getAllInRange(cx: Float, cy: Float, cz: Float, range: Float): List<TrackedBlock> {
        val r2 = range * range
        val cellRadius = (range.toInt() shr CELL_SHIFT) + 1
        val ccx = cx.toInt() shr CELL_SHIFT
        val ccy = cy.toInt() shr CELL_SHIFT
        val ccz = cz.toInt() shr CELL_SHIFT

        val result = ArrayList<TrackedBlock>(64)
        for (dx in -cellRadius..cellRadius) {
            for (dy in -cellRadius..cellRadius) {
                for (dz in -cellRadius..cellRadius) {
                    val key = ((ccx + dx).toLong() and 0x1FFFFFL shl 42) or
                              ((ccy + dy).toLong() and 0xFFFL    shl 21) or
                              ((ccz + dz).toLong() and 0x1FFFFFL)
                    val cell = cellIndex[key] ?: continue
                    for (blockKey in cell) {
                        val b = trackedBlocks[blockKey] ?: continue
                        val bdx = b.pos.x + 0.5f - cx
                        val bdy = b.pos.y + 0.5f - cy
                        val bdz = b.pos.z + 0.5f - cz
                        if (bdx*bdx + bdy*bdy + bdz*bdz <= r2) result.add(b)
                    }
                }
            }
        }
        return result
    }

    fun clear() {
        trackedBlocks.clear()
        cellIndex.clear()
    }

    fun size(): Int = trackedBlocks.size

    fun countByType(): Map<TrackedBlockType, Int> =
        trackedBlocks.values.groupingBy { it.type }.eachCount()

    private val paletteMap = ConcurrentHashMap<Int, TrackedBlockType>()
    @Volatile private var paletteLoaded = false

    fun loadPalette(startGame: StartGamePacket) {
        try {
            val paletteList = extractPaletteList(startGame)
            if (paletteList == null) {
                return
            }
            paletteMap.clear()
            var matched = 0
            paletteList.forEachIndexed { runtimeId, entry ->
                val name = extractBlockName(entry) ?: return@forEachIndexed
                val type = resolveBlockName(name) ?: return@forEachIndexed
                paletteMap[runtimeId] = type
                matched++
            }
            paletteLoaded = true
        } catch (e: Exception) {
        }
    }

    @Suppress("UNCHECKED_CAST")
    internal fun extractPaletteList(startGame: StartGamePacket): List<Any>? {
        val candidateNames = listOf(
            "getBlockPalette", "getBlockProperties", "getBlockDefinitions", "getBlockPropertiesList"
        )
        for (methodName in candidateNames) {
            try {
                val m = startGame.javaClass.getMethod(methodName)
                val result = m.invoke(startGame)
                if (result is List<*>) return result.filterNotNull()
            } catch (_: NoSuchMethodException) {
            } catch (_: Exception) {
            }
        }
        return null
    }

    internal fun extractBlockName(entry: Any): String? {
        for (methodName in listOf("getName", "getIdentifier")) {
            try {
                val m = entry.javaClass.getMethod(methodName)
                val v = m.invoke(entry)
                if (v is String) return v
            } catch (_: Exception) {}
        }
        try {
            val tagMethod = entry.javaClass.getMethod("getTag")
            val tag = tagMethod.invoke(entry)
            if (tag != null) {
                val getStringMethod = tag.javaClass.getMethod("getString", String::class.java)
                val name = getStringMethod.invoke(tag, "name") as? String
                if (!name.isNullOrEmpty()) return name
            }
        } catch (_: Exception) {}
        return null
    }

    fun resolveBlockId(runtimeId: Int): TrackedBlockType? =
        paletteMap[runtimeId] ?: BLOCK_ID_MAP[runtimeId]

    fun resolveBlockName(name: String): TrackedBlockType? {
        val lower = name.lowercase()
        return when {
            lower.contains("chest") && lower.contains("ender") -> TrackedBlockType.ENDER_CHEST
            lower.contains("chest") && lower.contains("trapped") -> TrackedBlockType.TRAPPED_CHEST
            lower.contains("chest")        -> TrackedBlockType.CHEST
            lower.contains("shulker")      -> TrackedBlockType.SHULKER_BOX
            lower.contains("spawner")      -> TrackedBlockType.SPAWNER
            lower.contains("hopper")       -> TrackedBlockType.HOPPER
            lower.contains("barrel")       -> TrackedBlockType.BARREL
            lower.contains("blast_furnace")-> TrackedBlockType.BLAST_FURNACE
            lower.contains("smoker")       -> TrackedBlockType.SMOKER
            lower.contains("furnace")      -> TrackedBlockType.FURNACE
            lower.contains("brewing")      -> TrackedBlockType.BREWING_STAND
            lower.contains("dispenser")    -> TrackedBlockType.DISPENSER
            lower.contains("dropper")      -> TrackedBlockType.DROPPER
            else -> null
        }
    }

    private val BLOCK_ID_MAP: Map<Int, TrackedBlockType> = mapOf(
        54   to TrackedBlockType.CHEST,
        146  to TrackedBlockType.TRAPPED_CHEST,
        130  to TrackedBlockType.ENDER_CHEST,
        218  to TrackedBlockType.SHULKER_BOX,
        219  to TrackedBlockType.SHULKER_BOX,
        220  to TrackedBlockType.SHULKER_BOX,
        221  to TrackedBlockType.SHULKER_BOX,
        222  to TrackedBlockType.SHULKER_BOX,
        223  to TrackedBlockType.SHULKER_BOX,
        224  to TrackedBlockType.SHULKER_BOX,
        225  to TrackedBlockType.SHULKER_BOX,
        226  to TrackedBlockType.SHULKER_BOX,
        227  to TrackedBlockType.SHULKER_BOX,
        228  to TrackedBlockType.SHULKER_BOX,
        229  to TrackedBlockType.SHULKER_BOX,
        230  to TrackedBlockType.SHULKER_BOX,
        231  to TrackedBlockType.SHULKER_BOX,
        232  to TrackedBlockType.SHULKER_BOX,
        233  to TrackedBlockType.SHULKER_BOX,
        52   to TrackedBlockType.SPAWNER,
        154  to TrackedBlockType.HOPPER,
        58   to TrackedBlockType.BARREL,
        61   to TrackedBlockType.FURNACE,
        62   to TrackedBlockType.FURNACE,
        450  to TrackedBlockType.BLAST_FURNACE,
        451  to TrackedBlockType.SMOKER,
        117  to TrackedBlockType.BREWING_STAND,
        23   to TrackedBlockType.DISPENSER,
        158  to TrackedBlockType.DROPPER,
    )
}
