package com.noxnoclient.module.movement

import com.noxnoclient.utils.CombatUtil
import com.noxnoclient.core.proxy.EntityTracker
import com.noxnoclient.core.relay.NoxNoRelaySession
import com.noxnoclient.events.PacketEvent
import com.noxnoclient.events.PacketEventBus
import com.noxnoclient.module.*
import kotlinx.coroutines.*
import org.cloudburstmc.protocol.bedrock.data.inventory.transaction.InventoryTransactionType
import org.cloudburstmc.protocol.bedrock.packet.AnimatePacket
import org.cloudburstmc.protocol.bedrock.packet.InventoryTransactionPacket
import org.cloudburstmc.protocol.bedrock.packet.MovePlayerPacket
import org.cloudburstmc.protocol.bedrock.packet.PlayerAuthInputPacket

class Timer : BaseModule(
    name        = "Timer",
    category    = ModuleCategory.MOVEMENT,
    description = "Duplicates real movement/attack packets via extra injection to make the engine appear sped up"
), PacketEventBus.PacketListener {

    private val motionMultiplier = float("Motion Multiplier", 1.0f, 1.0f, 4.0f)
    private val attackMultiplier = float("Attack Multiplier", 1.0f, 1.0f, 4.0f)
    private val stepDelayMs      = int  ("Step Delay (ms)",    12,   2,   50)
    private val minMoveThreshold = float("Min Move Threshold", 0.02f, 0f, 0.5f)

    private val pvpMode          = bool ("PvP Timer",           false)
    private val pvpMaxStepSetting = float("PvP Max Step",       0.9f,  0.3f, 2.0f)
    private val pvpStepDelay     = int  ("PvP Step Delay (ms)", 12,    2,   40)

    val pvpModeEnabled: Boolean get() = pvpMode.value
    val pvpMaxStep: Float       get() = pvpMaxStepSetting.value
    val pvpStepDelayMs: Long    get() = pvpStepDelay.value.toLong()

    @Volatile private var lastRealX    = 0f
    @Volatile private var lastRealY    = 0f
    @Volatile private var lastRealZ    = 0f
    @Volatile private var hasLastReal  = false

    override fun onEnable() {
        super.onEnable()
        hasLastReal = false
        PacketEventBus.register(this)
    }

    override fun onDisable() {
        PacketEventBus.unregister(this)
        hasLastReal = false
        super.onDisable()
    }

    override fun onPacket(event: PacketEvent) {
        if (!isEnabled) return
        if (event.direction != PacketEvent.Direction.CLIENT_TO_SERVER) return
        val session = event.session

        when (val pkt = event.effectivePacket) {
            is PlayerAuthInputPacket ->
                handleMotion(
                    session,
                    pkt.position.x, pkt.position.y, pkt.position.z,
                    pkt.rotation.y, pkt.rotation.x,
                    EntityTracker.selfOnGround
                )
            is MovePlayerPacket ->
                handleMotion(
                    session,
                    pkt.position.x, pkt.position.y, pkt.position.z,
                    pkt.rotation.y, pkt.rotation.x,
                    pkt.isOnGround
                )
            is InventoryTransactionPacket ->
                if (pkt.transactionType == InventoryTransactionType.ITEM_USE_ON_ENTITY) {
                    handleAttack(session, pkt.runtimeEntityId)
                }
            is AnimatePacket ->
                if (pkt.action == AnimatePacket.Action.SWING_ARM) {
                    handleSwing(session)
                }
        }
    }

    private fun handleMotion(
        session: NoxNoRelaySession,
        x: Float, y: Float, z: Float,
        yaw: Float, pitch: Float,
        onGround: Boolean
    ) {
        val extra = motionMultiplier.value - 1f

        if (hasLastReal && extra > 0.01f) {
            val dx = x - lastRealX
            val dy = y - lastRealY
            val dz = z - lastRealZ

            if (dx * dx + dz * dz > minMoveThreshold.value * minMoveThreshold.value) {
                val fullSteps  = extra.toInt().coerceIn(0, 3)
                val fractional = extra - fullSteps

                scope.launch {
                    var cx = x; var cy = y; var cz = z
                    repeat(fullSteps) {
                        cx += dx; cy += dy; cz += dz
                        CombatUtil.sendMove(session, cx, cy, cz, yaw, pitch, onGround)
                        EntityTracker.selfX = cx; EntityTracker.selfY = cy; EntityTracker.selfZ = cz
                        delay(stepDelayMs.value.toLong())
                    }
                    if (fractional > 0.05f) {
                        cx += dx * fractional; cy += dy * fractional; cz += dz * fractional
                        CombatUtil.sendMove(session, cx, cy, cz, yaw, pitch, onGround)
                        EntityTracker.selfX = cx; EntityTracker.selfY = cy; EntityTracker.selfZ = cz
                    }
                }
            }
        }

        lastRealX = x; lastRealY = y; lastRealZ = z
        hasLastReal = true
    }

    private fun handleAttack(session: NoxNoRelaySession, targetRid: Long) {
        val extra = (attackMultiplier.value - 1f).toInt().coerceIn(0, 3)
        if (extra <= 0 || targetRid == 0L) return
        val slot = EntityTracker.selfHotbarSlot.coerceIn(0, 8)

        scope.launch {
            repeat(extra) {
                delay(stepDelayMs.value.toLong())
                CombatUtil.sendSwing(session)
                CombatUtil.sendAttack(session, targetRid, slot)
            }
        }
    }

    private fun handleSwing(session: NoxNoRelaySession) {

        val extra = (attackMultiplier.value - 1f).toInt().coerceIn(0, 3)
        if (extra <= 0) return

        scope.launch {
            repeat(extra) {
                delay(stepDelayMs.value.toLong())
                CombatUtil.sendSwing(session)
            }
        }
    }
}
