package com.noxnoclient.ui.overlay

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Build
import android.widget.FrameLayout
import android.os.IBinder
import androidx.compose.animation.*
import androidx.compose.animation.core.tween
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.foundation.Canvas
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.ComposeView
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.app.NotificationCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.LifecycleRegistry
import androidx.lifecycle.setViewTreeLifecycleOwner
import androidx.savedstate.SavedStateRegistry
import androidx.savedstate.SavedStateRegistryController
import androidx.savedstate.SavedStateRegistryOwner
import androidx.savedstate.setViewTreeSavedStateRegistryOwner
import com.noxnoclient.R
import com.noxnoclient.config.Config
import com.noxnoclient.config.KeybindsConfig
import com.noxnoclient.config.OverlayPositions
import com.noxnoclient.config.Pos
import com.noxnoclient.core.proxy.EntityTracker
import com.noxnoclient.events.PacketEventBus
import com.noxnoclient.module.*
import com.noxnoclient.module.misc.ComboShortcut
import com.noxnoclient.module.misc.CommandHelper
import com.noxnoclient.module.keybinds.KeybindsManager
import com.noxnoclient.module.visual.Performance
import com.noxnoclient.module.social.FriendManager
import com.noxnoclient.session.SessionManager
import com.noxnoclient.core.keybinds.KeybindsService
import com.noxnoclient.ui.dashboard.OverlayUiStore
import com.noxnoclient.ui.dashboard.OverlayUiStyle
import com.noxnoclient.ui.theme.*
import com.noxnoclient.utils.InventoryUtil
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlin.math.abs
import kotlin.math.roundToInt

class OverlayService : Service(), LifecycleOwner, SavedStateRegistryOwner {

    companion object {
        private const val CHANNEL_ID = "ox_overlay"
        private const val NOTIF_ID   = 1002

        fun start(ctx: Context) {
            val i = Intent(ctx, OverlayService::class.java)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) ctx.startForegroundService(i)
            else ctx.startService(i)
        }

        fun stop(ctx: Context) = ctx.stopService(Intent(ctx, OverlayService::class.java))
    }

    private val lcReg   = LifecycleRegistry(this)
    override val lifecycle: Lifecycle get() = lcReg

    private val ssrCtrl = SavedStateRegistryController.create(this)
    override val savedStateRegistry: SavedStateRegistry get() = ssrCtrl.savedStateRegistry

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Main)

    private lateinit var wm: android.view.WindowManager
    private var isAttached = false

    private var menuView : ComposeView? = null
    private var totemView : ComposeView? = null
    private var perfHudView : ComposeView? = null
    private var fabView   : ComposeView? = null
    private var moduleToastView: ComposeView? = null
    private var visualRoot: FrameLayout? = null
    private var espView  : ESPOverlayView? = null
    private val shortcutViews = mutableMapOf<String, ComposeView>()
    private val commandShortcutViews = mutableMapOf<String, ComposeView>()

    private var volumeToggleJob: Job? = null

    override fun onCreate() {
        super.onCreate()
        ssrCtrl.performRestore(null)
        lcReg.currentState = Lifecycle.State.CREATED
        wm = getSystemService(WINDOW_SERVICE) as android.view.WindowManager
        createChannel()
        OverlayPositions.onChanged = { serviceScope.launch { applyPositionsToViews() } }
        volumeToggleJob?.cancel()
        volumeToggleJob = serviceScope.launch {
            VolumeToggleBus.events.collect { toggleMenu() }
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startForeground(NOTIF_ID, buildNotif())
        showOverlay()
        lcReg.currentState = Lifecycle.State.RESUMED
        OverlayState.setOverlayVisible(true)
        startStatsPoller()
        return START_STICKY
    }

    override fun onDestroy() {
        lcReg.currentState = Lifecycle.State.DESTROYED
        OverlayPositions.onChanged = null
        OverlayState.setOverlayVisible(false)
        volumeToggleJob?.cancel()
        removeAllOverlays()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun startStatsPoller() {
        serviceScope.launch {
            while (true) {
                OverlayState.updateActiveModuleCount(ModuleManager.enabledCount())
                val invSnapshot = EntityTracker.getInventorySnapshot()
                val totemCount = invSnapshot.count { (slot, item) ->
                    (slot in 0..35 || slot == 119) && InventoryUtil.isTotem(item)
                }
                OverlayState.updateTotemCount(totemCount)

                delay(500L)
            }
        }
    }

    private fun safeRemoveView(view: android.view.View?): Boolean {
        if (view == null) return false
        return try {
            wm.removeViewImmediate(view)
            true
        } catch (_: Exception) {
            try {
                wm.removeView(view)
                true
            } catch (_: Exception) {
                false
            }
        }
    }

    private fun overlayParams(
        w: Int, h: Int, x: Float = 0f, y: Float = 0f,
        focusable: Boolean = false, touchable: Boolean = false
    ): android.view.WindowManager.LayoutParams {
        // Accessibility overlays are trusted by Android for touch-obscuring checks.
        // Use one for the non-interactive HUD when the keybind accessibility
        // service is enabled; otherwise fall back to the normal overlay type.
        val useTrustedVisualOverlay = !touchable &&
            Build.VERSION.SDK_INT >= Build.VERSION_CODES.N &&
            KeybindsService.isEnabled(this)
        val type = when {
            useTrustedVisualOverlay && Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP_MR1 ->
                android.view.WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY
            Build.VERSION.SDK_INT >= Build.VERSION_CODES.O ->
                android.view.WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            else -> @Suppress("DEPRECATION") android.view.WindowManager.LayoutParams.TYPE_PHONE
        }

        var flags = if (focusable)
            android.view.WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
            android.view.WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
        else
            android.view.WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            android.view.WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
            android.view.WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
            android.view.WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS

        if (!touchable) flags = flags or android.view.WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE

        return android.view.WindowManager.LayoutParams(
            w, h, type, flags, PixelFormat.TRANSLUCENT
        ).apply {
            gravity = android.view.Gravity.TOP or android.view.Gravity.START
            this.x  = x.roundToInt()
            this.y  = y.roundToInt()
        }
    }

    private fun showOverlay() {
        if (isAttached) return
        try {
            // Android 12+ blocks touch-through for opaque TYPE_APPLICATION_OVERLAY
            // windows. Keep every non-interactive visual in ONE window so the
            // obscuring opacity stays below the platform limit.
            val visualParams = overlayParams(
                android.view.WindowManager.LayoutParams.MATCH_PARENT,
                android.view.WindowManager.LayoutParams.MATCH_PARENT,
                touchable = false
            ).apply {
                // Never make the visual HUD an input window. On Android 12+
                // this prevents the HUD from delaying/blocking Minecraft taps.
                // Trusted accessibility overlays can stay fully opaque; the
                // fallback remains below the platform's obscuring threshold.
                alpha = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                    if (KeybindsService.isEnabled(this@OverlayService)) 1f else 0.50f
                } else 1f
            }

            visualRoot = FrameLayout(this).apply {
                setViewTreeLifecycleOwner(this@OverlayService)
                setViewTreeSavedStateRegistryOwner(this@OverlayService)
                isClickable = false
                isFocusable = false
            }
            wm.addView(visualRoot, visualParams)

            espView = ESPOverlayView(this).apply {
                isClickable = false
                isFocusable = false
            }
            visualRoot!!.addView(
                espView,
                FrameLayout.LayoutParams(
                    android.view.ViewGroup.LayoutParams.MATCH_PARENT,
                    android.view.ViewGroup.LayoutParams.MATCH_PARENT
                )
            )
            espView?.startRenderLoop()

            moduleToastView = composeView { ModuleToastOverlay() }.apply {
                isClickable = false
                isFocusable = false
            }
            visualRoot!!.addView(
                moduleToastView,
                FrameLayout.LayoutParams(
                    android.view.ViewGroup.LayoutParams.MATCH_PARENT,
                    android.view.ViewGroup.LayoutParams.MATCH_PARENT
                )
            )

            totemView = composeView {
                TotemCounterIcon(
                    onDrag = { dx, dy ->
                        val next = Pos(OverlayPositions.totem.x + dx, OverlayPositions.totem.y + dy)
                        OverlayPositions.totem = next
                        totemView?.translationX = next.x
                        totemView?.translationY = next.y
                    }
                )
            }
            totemView?.translationX = OverlayPositions.totem.x
            totemView?.translationY = OverlayPositions.totem.y
            visualRoot!!.addView(
                totemView,
                FrameLayout.LayoutParams(
                    android.view.ViewGroup.LayoutParams.WRAP_CONTENT,
                    android.view.ViewGroup.LayoutParams.WRAP_CONTENT
                )
            )

            perfHudView = composeView {
                PerformanceHudLabel(
                    onDrag = { dx, dy ->
                        val next = Pos(OverlayPositions.perfHud.x + dx, OverlayPositions.perfHud.y + dy)
                        OverlayPositions.perfHud = next
                        perfHudView?.translationX = next.x
                        perfHudView?.translationY = next.y
                    }
                )
            }
            perfHudView?.translationX = OverlayPositions.perfHud.x
            perfHudView?.translationY = OverlayPositions.perfHud.y
            visualRoot!!.addView(
                perfHudView,
                FrameLayout.LayoutParams(
                    android.view.ViewGroup.LayoutParams.WRAP_CONTENT,
                    android.view.ViewGroup.LayoutParams.WRAP_CONTENT
                )
            )

            val fabParams = overlayParams(
                android.view.WindowManager.LayoutParams.WRAP_CONTENT,
                android.view.WindowManager.LayoutParams.WRAP_CONTENT,
                OverlayPositions.fab.x, OverlayPositions.fab.y,
                touchable = true
            )
            fabView = composeView {
                MenuFab(
                    onClick = { toggleMenu() },
                    onDrag  = { dx, dy ->
                        val next = Pos(OverlayPositions.fab.x + dx, OverlayPositions.fab.y + dy)
                        OverlayPositions.fab = next
                        fabParams.x = next.x.roundToInt()
                        fabParams.y = next.y.roundToInt()
                        safeUpdate(fabView, fabParams)
                    }
                )
            }
            wm.addView(fabView, fabParams)

            refreshShortcuts()
            refreshCommandShortcuts()
            isAttached = true
        } catch (_: Exception) {}
    }

    private fun refreshShortcuts() {
        val unlockedShortcutModules = ModuleManager.shortcutModules()
        val active = unlockedShortcutModules.map { it.name }.toSet()
        shortcutViews.entries.filter { it.key !in active }.forEach { (name, view) ->
            if (safeRemoveView(view)) shortcutViews.remove(name)
        }
        unlockedShortcutModules.forEachIndexed { idx, mod ->
            if (mod.name !in shortcutViews) {
                val pos = OverlayPositions.shortcuts.getOrPut(mod.name) { Pos(50f, 420f + idx * 50f) }
                val params = overlayParams(
                    android.view.WindowManager.LayoutParams.WRAP_CONTENT,
                    android.view.WindowManager.LayoutParams.WRAP_CONTENT,
                    pos.x, pos.y,
                    touchable = true
                )
                val view = composeView {
                    ShortcutButton(
                        module   = mod,
                        onDrag   = { dx, dy ->
                            val cur = OverlayPositions.shortcuts[mod.name] ?: Pos(0f, 0f)
                            val next = Pos(cur.x + dx, cur.y + dy)
                            OverlayPositions.shortcuts[mod.name] = next
                            params.x = next.x.roundToInt(); params.y = next.y.roundToInt()
                            safeUpdate(shortcutViews[mod.name], params)
                        },
                        onToggle = { ModuleManager.toggle(mod) }
                    )
                }
                shortcutViews[mod.name] = view
                try { wm.addView(view, params) } catch (_: Exception) {}
            }
        }
    }

    private fun refreshCommandShortcuts() {
        val helper = ModuleManager.byName("CommandHelper") as? CommandHelper
        val activeEntries = if (helper?.isEnabled == true) helper.entries.toSet() else emptySet()

        commandShortcutViews.entries.filter { it.key !in activeEntries }.forEach { (entry, view) ->
            if (safeRemoveView(view)) {
                commandShortcutViews.remove(entry)
                OverlayPositions.commandShortcuts.remove(entry)
            }
        }
        activeEntries.forEachIndexed { idx, entry ->
            if (entry !in commandShortcutViews) {
                val pos = OverlayPositions.commandShortcuts.getOrPut(entry) { Pos(50f, 620f + idx * 50f) }
                val params = overlayParams(
                    android.view.WindowManager.LayoutParams.WRAP_CONTENT,
                    android.view.WindowManager.LayoutParams.WRAP_CONTENT,
                    pos.x, pos.y,
                    touchable = true
                )
                val view = composeView {
                    CommandEntryButton(
                        text   = entry,
                        onDrag = { dx, dy ->
                            val cur = OverlayPositions.commandShortcuts[entry] ?: Pos(0f, 0f)
                            val next = Pos(cur.x + dx, cur.y + dy)
                            OverlayPositions.commandShortcuts[entry] = next
                            params.x = next.x.roundToInt(); params.y = next.y.roundToInt()
                            safeUpdate(commandShortcutViews[entry], params)
                        },
                        onTap = { helper?.send(entry) }
                    )
                }
                commandShortcutViews[entry] = view
                try { wm.addView(view, params) } catch (_: Exception) {}
            }
        }
    }

    private fun toggleMenu() { if (menuView != null) hideMenu() else showMenu() }

    private fun showMenu() {
        if (menuView != null) return
        val params = overlayParams(
            android.view.WindowManager.LayoutParams.MATCH_PARENT,
            android.view.WindowManager.LayoutParams.MATCH_PARENT,
            focusable = true,
            touchable = true
        )
        menuView = composeView {
            val moduleVersion by ModuleManager.version.collectAsState()
            val uiStyle = remember { OverlayUiStore.get(this@OverlayService) }
            Box(
                modifier = Modifier
                    .fillMaxSize()

                    .background(Color.Transparent)
                    .pointerInput(Unit) { detectTapGestures { hideMenu() } }
            ) {
                if (uiStyle == OverlayUiStyle.GRID) {
                    GridMenu(
                        onClose           = { hideMenu() },
                        moduleVersion     = moduleVersion,
                        onShortcutChanged = { refreshShortcuts(); refreshCommandShortcuts() },
                        modifier          = Modifier.fillMaxSize()
                    )
                } else {
                    HileMenu(
                        onClose               = { hideMenu() },
                        moduleVersion         = moduleVersion,
                        onShortcutChanged     = { refreshShortcuts(); refreshCommandShortcuts() },
                        modifier              = Modifier.align(Alignment.CenterStart)
                    )
                }
            }
        }
        try {
            menuView?.isFocusableInTouchMode = true
            menuView?.setOnKeyListener { _, _, event ->
                if (KeybindsManager.captureId.value != null) {
                    val captured = KeybindsManager.captureKeyEvent(event)
                    if (captured) {
                        KeybindsConfig(applicationContext).save()
                        true
                    } else event.action == android.view.KeyEvent.ACTION_DOWN
                } else {
                    false
                }
            }
            wm.addView(menuView, params)
            menuView?.requestFocus()
            OverlayState.setMenuOpen(true)
        } catch (_: Exception) {
            menuView = null
        }
    }

    private fun hideMenu() {
        val view = menuView ?: return
        if (!safeRemoveView(view)) return
        menuView = null
        OverlayState.setMenuOpen(false)
        GridSettingsPopup.close()
    }

    private fun removeAllOverlays() {
        hideMenu()
        listOfNotNull(fabView).plus(shortcutViews.values).plus(commandShortcutViews.values).forEach { v ->
            safeRemoveView(v)
        }
        safeRemoveView(visualRoot)
        visualRoot = null
        totemView = null; perfHudView = null; fabView = null; moduleToastView = null; espView = null
        shortcutViews.clear(); commandShortcutViews.clear(); isAttached = false
    }

    private fun safeUpdate(view: ComposeView?, params: android.view.WindowManager.LayoutParams) {
        view?.let { try { wm.updateViewLayout(it, params) } catch (_: Exception) {} }
    }

    private fun applyPositionsToViews() {
        fun snap(view: ComposeView?, pos: Pos) {
            view ?: return
            if (view.parent === visualRoot) {
                view.translationX = pos.x
                view.translationY = pos.y
                return
            }
            val params = view.layoutParams as? android.view.WindowManager.LayoutParams ?: return
            params.x = pos.x.roundToInt(); params.y = pos.y.roundToInt()
            safeUpdate(view, params)
        }
        snap(totemView, OverlayPositions.totem)
        snap(perfHudView, OverlayPositions.perfHud)
        snap(fabView, OverlayPositions.fab)
        shortcutViews.forEach { (name, view) -> OverlayPositions.shortcuts[name]?.let { snap(view, it) } }
        commandShortcutViews.forEach { (entry, view) -> OverlayPositions.commandShortcuts[entry]?.let { snap(view, it) } }
    }

    private fun composeView(content: @Composable () -> Unit) =
        ComposeView(this).apply {
            setViewTreeLifecycleOwner(this@OverlayService)
            setViewTreeSavedStateRegistryOwner(this@OverlayService)
            setContent(content)
        }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val ch = NotificationChannel(CHANNEL_ID, "NoxNo Client Overlay", NotificationManager.IMPORTANCE_MIN)
            getSystemService(NotificationManager::class.java).createNotificationChannel(ch)
        }
    }

    private fun buildNotif() = NotificationCompat.Builder(this, CHANNEL_ID)
        .setSmallIcon(R.mipmap.ic_noxno_logo)
        .setContentTitle("NoxNo Client Overlay")
        .setContentText("HUD aktif")
        .setOngoing(true)
        .setPriority(NotificationCompat.PRIORITY_MIN)
        .build()
}

object VolumeToggleBus {
    private val _events = kotlinx.coroutines.flow.MutableSharedFlow<Unit>(extraBufferCapacity = 1)
    val events: kotlinx.coroutines.flow.SharedFlow<Unit> = _events

    fun emitToggle() { _events.tryEmit(Unit) }
}

@Composable
private fun ModuleToastOverlay() {
    val toasts = OverlayState.toasts
    Box(modifier = Modifier.fillMaxSize()) {
        Column(
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(end = 14.dp, bottom = 92.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            toasts.takeLast(3).forEach { toast ->
                val text = when (toast.type) {
                    ToastType.MODULE_TOGGLE -> "${toast.moduleName} ${if (toast.enabled) "Enabled" else "Disabled"}"
                    else -> toast.customText
                }
                if (text.isNotBlank()) {
                    Text(
                        text = text,
                        fontSize = 12.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        color = if (toast.type == ToastType.MODULE_TOGGLE && toast.enabled) Color(0xFF39FF88) else Color.White,
                        modifier = Modifier
                            .clip(RoundedCornerShape(7.dp))
                            .background(Color(0xDD050505))
                            .border(1.dp, if (toast.enabled) Color(0xFF39FF88) else Color(0xFF303030), RoundedCornerShape(7.dp))
                            .padding(horizontal = 10.dp, vertical = 7.dp)
                    )
                }
            }
        }
    }
}

@Composable
private fun PerformanceHudLabel(onDrag: (Float, Float) -> Unit) {
    var totalDrag by remember { mutableFloatStateOf(0f) }

    val perfModule = remember { ModuleManager.byName("Performance") as? Performance }
    var hudVisible by remember { mutableStateOf(perfModule?.showPerformanceHud?.value ?: false) }

    LaunchedEffect(perfModule) {
        val mod = perfModule ?: return@LaunchedEffect
        while (isActive) {
            hudVisible = mod.showPerformanceHud.value
            delay(300L)
        }
    }

    val fps  = OverlayState.currentFps
    val ping = OverlayState.currentPingMs

    val fpsColor = when {
        fps in 1..29 -> Color(0xFFFF453A)
        fps == 0     -> Color.White.copy(alpha = 0.65f)
        else         -> Color.White.copy(alpha = 0.9f)
    }
    val pingColor = when {
        ping >= 150 -> Color(0xFFFF453A)
        ping >= 80  -> Color(0xFFFFD60A)
        else        -> Color.White.copy(alpha = 0.9f)
    }

    AnimatedVisibility(
        visible = hudVisible,
        enter   = fadeIn() + expandHorizontally(),
        exit    = fadeOut() + shrinkHorizontally()
    ) {
    Row(
        modifier = Modifier
            .wrapContentSize()
            .clip(RoundedCornerShape(8.dp))
            .background(Color(0xDD111827))
            .border(1.dp, Color(0xFF2D3F6E), RoundedCornerShape(8.dp))
            .pointerInput(Unit) {
                detectDragGestures(
                    onDragStart = { totalDrag = 0f },
                    onDragEnd   = { },
                    onDrag      = { change, offset ->
                        change.consume()
                        totalDrag += kotlin.math.abs(offset.x) + kotlin.math.abs(offset.y)
                        onDrag(offset.x, offset.y)
                    }
                )
            }
            .padding(horizontal = 10.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Text(
            text       = "$fps FPS",
            fontSize   = 13.sp,
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Bold,
            color      = fpsColor
        )
        Text(
            text       = "${ping}ms",
            fontSize   = 13.sp,
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Bold,
            color      = pingColor
        )
    }
    }
}

@Composable
private fun TotemCounterIcon(onDrag: (Float, Float) -> Unit) {
    val count      = OverlayState.totemCount
    var totalDrag  by remember { mutableFloatStateOf(0f) }

    val autoTotem  = remember { ModuleManager.byName("AutoTotem") }
    var autoTotemEnabled by remember { mutableStateOf(autoTotem?.isEnabled ?: false) }
    LaunchedEffect(autoTotem) {
        autoTotem?.enabledFlow?.collect { autoTotemEnabled = it }
    }

    AnimatedVisibility(
        visible = autoTotemEnabled,
        enter   = fadeIn() + expandHorizontally(),
        exit    = fadeOut() + shrinkHorizontally()
    ) {
    Row(
        modifier = Modifier
            .wrapContentSize()
            .clip(RoundedCornerShape(50.dp))
            .background(Color(0xDD111827))
            .border(1.dp, Color(0xFF2D3F6E), RoundedCornerShape(50.dp))
            .pointerInput(Unit) {
                detectDragGestures(
                    onDragStart = { totalDrag = 0f },
                    onDragEnd   = { },
                    onDrag      = { change, offset ->
                        change.consume()
                        totalDrag += kotlin.math.abs(offset.x) + kotlin.math.abs(offset.y)
                        onDrag(offset.x, offset.y)
                    }
                )
            }
            .padding(horizontal = 10.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        androidx.compose.foundation.Image(
            painter            = painterResource(id = R.drawable.ic_totem),
            contentDescription = "Totem",
            modifier           = Modifier.size(22.dp)
        )
        Text(
            text       = "$count",
            fontSize   = 14.sp,
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Bold,
            color      = when {
                count > 5 -> Color.White
                else      -> Color(0xFFFF453A)
            }
        )
    }
    }
}

@Composable
private fun MenuFab(onClick: () -> Unit, onDrag: (Float, Float) -> Unit) {
    var totalDrag  by remember { mutableFloatStateOf(0f) }
    var isDragging by remember { mutableStateOf(false) }

    Box(
        modifier = Modifier
            .size(46.dp)
            .clip(CircleShape)
            .background(Color(0xDD1C1C1E))
            .border(1.5.dp, Color.White.copy(alpha = 0.55f), CircleShape)
            .pointerInput(Unit) { detectTapGestures(onTap = { if (!isDragging) onClick() }) }
            .pointerInput(Unit) {
                detectDragGestures(
                    onDragStart = { isDragging = true; totalDrag = 0f },
                    onDragEnd   = { isDragging = false; if (totalDrag < 12f) onClick() },
                    onDrag      = { c, o -> c.consume(); totalDrag += abs(o.x) + abs(o.y); onDrag(o.x, o.y) }
                )
            },
        contentAlignment = Alignment.Center
    ) {
        androidx.compose.foundation.Image(
            painter            = painterResource(id = R.mipmap.ic_noxno_logo),
            contentDescription = "NoxNo",
            modifier           = Modifier
                .size(30.dp)
                .clip(CircleShape)
        )
    }
}

@Composable
private fun ShortcutButton(module: BaseModule, onDrag: (Float, Float) -> Unit, onToggle: () -> Unit) {
    var enabled    by remember { mutableStateOf(module.isEnabled) }
    var totalDrag  by remember { mutableFloatStateOf(0f) }
    var isDragging by remember { mutableStateOf(false) }
    LaunchedEffect(module) { module.enabledFlow.collect { enabled = it } }

    val bgColor = if (enabled) NoxNoSurfaceVar else NoxNoSurface
    val borderColor = if (enabled) NoxNoAccentLight.copy(0.9f) else NoxNoOutline.copy(0.5f)
    val textColor   = if (enabled) Color.White else NoxNoOnSurface.copy(0.6f)

    Box(
        modifier = Modifier
            .wrapContentSize()
            .clip(RoundedCornerShape(50.dp))
            .background(bgColor)
            .border(if (enabled) 1.5.dp else 1.dp, borderColor, RoundedCornerShape(50.dp))
            .pointerInput(Unit) { detectTapGestures(onTap = { if (!isDragging) onToggle() }) }
            .pointerInput(Unit) {
                detectDragGestures(
                    onDragStart = { isDragging = true; totalDrag = 0f },
                    onDragEnd   = { isDragging = false; if (totalDrag < 12f) onToggle() },
                    onDrag      = { c, o -> c.consume(); totalDrag += abs(o.x) + abs(o.y); onDrag(o.x, o.y) }
                )
            }
            .padding(horizontal = 16.dp, vertical = 9.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            module.name,
            fontSize = 12.sp,
            fontWeight = if (enabled) FontWeight.SemiBold else FontWeight.Normal,
            color = textColor,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
    }
}

@Composable
private fun CommandEntryButton(text: String, onDrag: (Float, Float) -> Unit, onTap: () -> Unit) {
    var totalDrag  by remember { mutableFloatStateOf(0f) }
    var isDragging by remember { mutableStateOf(false) }

    Box(
        modifier = Modifier
            .wrapContentSize()
            .clip(RoundedCornerShape(50.dp))
            .background(NoxNoSurfaceVar)
            .border(1.5.dp, NoxNoAccentLight.copy(0.9f), RoundedCornerShape(50.dp))
            .pointerInput(Unit) { detectTapGestures(onTap = { if (!isDragging) onTap() }) }
            .pointerInput(Unit) {
                detectDragGestures(
                    onDragStart = { isDragging = true; totalDrag = 0f },
                    onDragEnd   = { isDragging = false; if (totalDrag < 12f) onTap() },
                    onDrag      = { c, o -> c.consume(); totalDrag += abs(o.x) + abs(o.y); onDrag(o.x, o.y) }
                )
            }
            .padding(horizontal = 16.dp, vertical = 9.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text,
            fontSize = 12.sp,
            fontWeight = FontWeight.SemiBold,
            color = Color.White,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.widthIn(max = 96.dp)
        )
    }
}

private enum class MenuSection(val displayName: String) {
    COMBAT("Combat"), MOVEMENT("Movement"), VISUAL("Visual"), PLAYER("Player"), WORLD("World"), MISC("Misc"),
    FRIENDS("Friends"), CONFIG("Config")
}

private fun MenuSection.toModuleCategory(): ModuleCategory? = when (this) {
    MenuSection.COMBAT   -> ModuleCategory.COMBAT
    MenuSection.MOVEMENT -> ModuleCategory.MOVEMENT
    MenuSection.VISUAL   -> ModuleCategory.VISUAL
    MenuSection.PLAYER   -> ModuleCategory.PLAYER
    MenuSection.WORLD    -> ModuleCategory.WORLD
    MenuSection.MISC     -> ModuleCategory.MISC
    MenuSection.FRIENDS  -> null
    MenuSection.CONFIG   -> null
}

@Composable
private fun HileMenu(
    onClose               : () -> Unit,
    moduleVersion         : Int,
    onShortcutChanged     : () -> Unit,
    modifier              : Modifier = Modifier
) {
    var section by remember { mutableStateOf(MenuSection.COMBAT) }
    val cat  = section.toModuleCategory()
    val mods = remember(moduleVersion, cat) {
        cat?.let { ModuleManager.byCategory(it) } ?: emptyList()
    }
    val relayActive by SessionManager.isActive.collectAsState()

    Box(
        modifier = modifier
            .fillMaxHeight()
            .width(300.dp)
            .background(
                Brush.verticalGradient(
                    listOf(NoxNoBackground.copy(alpha = 0.72f), Color(0xFF141830).copy(alpha = 0.72f))
                )
            )
            .border(1.dp, NoxNoOutlineStrong, RoundedCornerShape(topEnd = 16.dp, bottomEnd = 16.dp))
            .clip(RoundedCornerShape(topEnd = 16.dp, bottomEnd = 16.dp))
            .pointerInput(Unit) { detectTapGestures { } }
    ) {
        Column(modifier = Modifier.fillMaxSize()) {

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(NoxNoSurface)
                    .padding(horizontal = 16.dp, vertical = 14.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("NoxNo Client",
                        fontSize = 18.sp, fontWeight = FontWeight.ExtraBold,
                        color = NoxNoOnBackground)
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(20.dp))
                            .background(if (relayActive) NoxNoSuccess.copy(0.2f) else NoxNoError.copy(0.15f))
                            .border(1.dp,
                                if (relayActive) NoxNoSuccess.copy(0.5f) else NoxNoError.copy(0.4f),
                                RoundedCornerShape(20.dp))
                            .padding(horizontal = 8.dp, vertical = 3.dp)
                    ) {
                        Text(if (relayActive) "Connected" else "Disconnected",
                            fontSize = 9.sp,
                            color = if (relayActive) NoxNoSuccess else NoxNoError,
                            fontWeight = FontWeight.SemiBold)
                    }
                }
                Box(
                    modifier = Modifier
                        .size(28.dp)
                        .clip(CircleShape)
                        .background(NoxNoError.copy(0.15f))
                        .border(1.dp, NoxNoError.copy(0.4f), CircleShape)
                        .clickable { onClose() },
                    contentAlignment = Alignment.Center
                ) {
                    Text("x", color = NoxNoError, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                }
            }

            HorizontalDivider(color = NoxNoOutlineStrong)

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(NoxNoSurface.copy(0.5f))
                    .horizontalScroll(rememberScrollState())
                    .padding(horizontal = 10.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                MenuSection.entries.forEach { s ->
                    val sel = s == section
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(50.dp))
                            .background(if (sel) NoxNoSurfaceVar else Color.Transparent)
                            .border(1.dp,
                                if (sel) NoxNoOutlineStrong else NoxNoOutline,
                                RoundedCornerShape(50.dp))
                            .clickable { section = s }
                            .padding(horizontal = 14.dp, vertical = 6.dp)
                    ) {
                        Text(s.displayName, fontSize = 11.sp,
                            color = if (sel) NoxNoOnBackground else NoxNoOnSurface,
                            fontWeight = if (sel) FontWeight.SemiBold else FontWeight.Normal)
                    }
                }            }

            HorizontalDivider(color = NoxNoOutlineStrong)

            Box(modifier = Modifier.fillMaxWidth().weight(1f)) {
                if (section == MenuSection.CONFIG) {
                    ConfigSection()
                } else if (section == MenuSection.FRIENDS) {
                    FriendsSection()
                } else {
                    LazyColumn(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(horizontal = 8.dp),
                        verticalArrangement = Arrangement.spacedBy(5.dp),
                        contentPadding = PaddingValues(vertical = 8.dp)
                    ) {
                        items(mods) { mod ->
                            ModuleCard(module = mod, onShortcutChanged = onShortcutChanged)
                        }
                        if (section == MenuSection.VISUAL) {
                            item {
                                KeybindsInfoCard()
                            }
                        }
                    }
                }
            }
        }
    }
}

private enum class GridCategory(val display: String, val category: ModuleCategory) {
    COMBAT("Combat", ModuleCategory.COMBAT),
    MOVEMENT("Movement", ModuleCategory.MOVEMENT),
    VISUAL("Visual", ModuleCategory.VISUAL),
    PLAYER("Player", ModuleCategory.PLAYER),
    WORLD("World", ModuleCategory.WORLD),
    MISC("Misc", ModuleCategory.MISC)
}

private val GridHeaderTop      = Color(0xFF333338)
private val GridHeaderBottom   = Color(0xFF0A0A0B)
private val GridPanelTop       = Color(0xFF1B1B1E)
private val GridPanelBottom    = Color(0xFF0C0C0E)
private val GridRowTopIdle     = Color(0xFF232326)
private val GridRowBottomIdle  = Color(0xFF141416)
private val GridRowTopOn       = Color(0xFF2E2E34)
private val GridRowBottomOn    = Color(0xFF17181B)
private val GridBorderIdle     = Color(0xFF3A3A40).copy(alpha = 0.55f)
private val GridBorderOn       = Color(0xFFD8D8DE).copy(alpha = 0.65f)
private val GridGlow           = Color(0xFFFFFFFF).copy(alpha = 0.06f)
private val GridTextOn         = Color(0xFFFFFFFF)
private val GridTextDim        = Color(0xFFE4E4E8)
private val GridPlusBg         = Color(0xFF303034)
private val GridStarOn         = Color(0xFFFFFFFF)
private val GridStarOff        = Color(0xFF6E6E74)

private object GridShortcuts {
    private val _names = MutableStateFlow(setOf<String>())
    val names: StateFlow<Set<String>> = _names.asStateFlow()

    fun isOn(name: String) = name in _names.value

    fun toggle(name: String) {
        _names.value = if (name in _names.value) _names.value - name else _names.value + name
    }
}

private object GridSettingsPopup {
    var current by mutableStateOf<BaseModule?>(null)
        private set

    fun open(module: BaseModule) { current = module }
    fun toggle(module: BaseModule) { current = if (current === module) null else module }
    fun close() { current = null }
}

private enum class GridExtraSection { CONFIG, FRIENDS }

private object GridExtraPopup {
    var current by mutableStateOf<GridExtraSection?>(null)
        private set

    fun toggle(section: GridExtraSection) {
        current = if (current == section) null else section
    }
    fun close() { current = null }
}

private val GridColumnWidth   = 112.dp
private val GridColumnGap     = 8.dp
private val GridOuterPadding  = 8.dp

@Composable
private fun GridMenu(
    onClose           : () -> Unit,
    moduleVersion     : Int,
    onShortcutChanged : () -> Unit,
    modifier          : Modifier = Modifier
) {
    Box(
        modifier = modifier
            .fillMaxSize()
    ) {
        val screenHeightDp = LocalConfiguration.current.screenHeightDp.dp

        val maxListHeight = (screenHeightDp - 96.dp - 34.dp).coerceAtLeast(120.dp)

        Column(modifier = Modifier.fillMaxSize()) {
            GridExtraHeader()

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .padding(horizontal = GridOuterPadding, vertical = 10.dp)
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(GridColumnGap)
            ) {
                GridCategory.entries.forEach { gc ->
                    val mods = remember(moduleVersion, gc) { ModuleManager.byCategory(gc.category) }
                    GridCategoryColumn(
                        title             = gc.display,
                        mods              = mods,
                        maxListHeight     = maxListHeight,
                        onShortcutChanged = onShortcutChanged,
                        onClose           = onClose
                    )
                }
            }
        }

        val popupModule = GridSettingsPopup.current
        if (popupModule != null) {
            ModuleSettingsPopup(
                module            = popupModule,
                onShortcutChanged = onShortcutChanged,
                onDismiss         = { GridSettingsPopup.close() }
            )
        }

        val extraSection = GridExtraPopup.current
        if (extraSection != null) {
            GridExtraSectionPopup(
                section   = extraSection,
                onDismiss = { GridExtraPopup.close() }
            )
        }
    }
}

@Composable
private fun GridExtraHeader() {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = GridOuterPadding, vertical = 4.dp),
        horizontalArrangement = Arrangement.End,
        verticalAlignment = Alignment.CenterVertically
    ) {
        GridExtraHeaderIcon(
            label   = "\u2699",
            active  = GridExtraPopup.current == GridExtraSection.CONFIG,
            onClick = { GridExtraPopup.toggle(GridExtraSection.CONFIG) }
        )
        Spacer(modifier = Modifier.width(6.dp))
        GridExtraHeaderIconCanvas(
            active  = GridExtraPopup.current == GridExtraSection.FRIENDS,
            onClick = { GridExtraPopup.toggle(GridExtraSection.FRIENDS) },
            draw    = { color -> drawFriendsIcon(color) }
        )
    }
}

@Composable
private fun GridExtraHeaderIcon(label: String, active: Boolean, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .size(26.dp)
            .clip(RoundedCornerShape(7.dp))
            .background(if (active) GridRowTopOn else GridRowTopIdle)
            .border(1.dp, if (active) GridBorderOn else GridBorderIdle, RoundedCornerShape(7.dp))
            .clickable { onClick() },
        contentAlignment = Alignment.Center
    ) {
        Text(label, fontSize = 13.sp, color = GridTextOn)
    }
}

@Composable
private fun GridExtraHeaderIconCanvas(active: Boolean, onClick: () -> Unit, draw: DrawScope.(Color) -> Unit) {
    Box(
        modifier = Modifier
            .size(26.dp)
            .clip(RoundedCornerShape(7.dp))
            .background(if (active) GridRowTopOn else GridRowTopIdle)
            .border(1.dp, if (active) GridBorderOn else GridBorderIdle, RoundedCornerShape(7.dp))
            .clickable { onClick() },
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.size(15.dp)) {
            draw(GridTextOn)
        }
    }
}

private fun DrawScope.drawFriendsIcon(color: Color) {
    val w = size.width
    val h = size.height
    val headR = w * 0.17f

    val backCx = w * 0.36f
    val frontCx = w * 0.64f
    val headCy = h * 0.30f

    val backColor = color.copy(alpha = 0.5f)
    drawCircle(color = backColor, radius = headR * 0.92f, center = Offset(backCx, headCy * 0.95f))
    drawArc(
        color = backColor,
        startAngle = 180f,
        sweepAngle = 180f,
        useCenter = true,
        topLeft = Offset(backCx - headR, h * 0.52f),
        size = Size(headR * 2f, h * 0.46f)
    )

    drawCircle(color = color, radius = headR, center = Offset(frontCx, headCy))
    drawArc(
        color = color,
        startAngle = 180f,
        sweepAngle = 180f,
        useCenter = true,
        topLeft = Offset(frontCx - headR * 1.15f, h * 0.56f),
        size = Size(headR * 2.3f, h * 0.44f)
    )
}

@Composable
private fun GridExtraSectionPopup(section: GridExtraSection, onDismiss: () -> Unit) {
    val screenHeightDp = LocalConfiguration.current.screenHeightDp.dp
    val maxPopupHeight = (screenHeightDp - 120.dp).coerceAtLeast(160.dp)
    val title = when (section) {
        GridExtraSection.CONFIG  -> "Config"
        GridExtraSection.FRIENDS -> "Friends"
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black.copy(alpha = 0.55f))
            .pointerInput(section) { detectTapGestures { onDismiss() } },
        contentAlignment = Alignment.Center
    ) {
        Column(
            modifier = Modifier
                .widthIn(min = 260.dp, max = 320.dp)
                .heightIn(max = maxPopupHeight)
                .shadow(10.dp, RoundedCornerShape(14.dp), ambientColor = GridGlow, spotColor = GridGlow)
                .clip(RoundedCornerShape(14.dp))
                .background(Brush.verticalGradient(listOf(GridPanelTop, GridPanelBottom)))
                .border(1.dp, GridBorderOn, RoundedCornerShape(14.dp))
                .pointerInput(section) { detectTapGestures { } }
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Brush.verticalGradient(listOf(GridHeaderTop, GridHeaderBottom)))
                    .padding(horizontal = 14.dp, vertical = 10.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    title,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Black,
                    color = GridTextOn,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f)
                )
                Text(
                    "\u2715",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = GridTextOn,
                    modifier = Modifier
                        .clickable { onDismiss() }
                        .padding(4.dp)
                )
            }

            Box(modifier = Modifier.fillMaxWidth().heightIn(max = maxPopupHeight - 44.dp)) {
                when (section) {
                    GridExtraSection.CONFIG  -> ConfigSection()
                    GridExtraSection.FRIENDS -> FriendsSection()
                }
            }
        }
    }
}

@Composable
private fun GridCategoryColumn(
    title             : String,
    mods              : List<BaseModule>,
    maxListHeight     : androidx.compose.ui.unit.Dp,
    onShortcutChanged : () -> Unit,
    onClose           : () -> Unit = {}
) {
    var dragOffset by remember { mutableStateOf(Offset.Zero) }

    Column(
        modifier = Modifier
            .width(GridColumnWidth)
            .offset { IntOffset(dragOffset.x.roundToInt(), dragOffset.y.roundToInt()) }
            .pointerInput(Unit) { detectTapGestures {  } }
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .shadow(4.dp, RoundedCornerShape(10.dp), ambientColor = GridGlow, spotColor = GridGlow)
                .clip(RoundedCornerShape(10.dp))
                .background(Brush.verticalGradient(listOf(GridHeaderTop, GridHeaderBottom)))
                .border(1.dp, GridBorderIdle, RoundedCornerShape(10.dp))
                .pointerInput(Unit) {
                    detectDragGestures { change, drag ->
                        change.consume()
                        dragOffset += Offset(drag.x, drag.y)
                    }
                }
                .padding(vertical = 7.dp, horizontal = 8.dp)
        ) {
            Text(
                title,
                fontSize = 12.sp,
                fontWeight = FontWeight.Black,
                color = GridTextOn,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.align(Alignment.Center)
            )
        }

        Spacer(modifier = Modifier.height(5.dp))

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .heightIn(max = maxListHeight)
                .shadow(5.dp, RoundedCornerShape(10.dp), ambientColor = GridGlow, spotColor = GridGlow)
                .clip(RoundedCornerShape(10.dp))
                .background(Brush.verticalGradient(listOf(GridPanelTop, GridPanelBottom)))
                .border(1.dp, GridBorderIdle, RoundedCornerShape(10.dp))
        ) {
            if (mods.isEmpty()) {
                Box(
                    modifier = Modifier.fillMaxWidth().padding(vertical = 10.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text("Empty", fontSize = 9.sp, color = GridTextDim.copy(alpha = 0.5f))
                }
            } else {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .verticalScroll(rememberScrollState())
                        .padding(5.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    mods.forEach { mod ->
                        GridModuleRow(module = mod, onShortcutChanged = onShortcutChanged)
                    }
                }
            }
        }
    }
}

@Composable
private fun GridModuleRow(module: BaseModule, onShortcutChanged: () -> Unit) {
    var enabled by remember { mutableStateOf(module.isEnabled) }
    val gridShortcutNames by GridShortcuts.names.collectAsState()
    val isGridShortcut = module.name in gridShortcutNames
    LaunchedEffect(module) { module.enabledFlow.collect { enabled = it } }

    val hasSettings = module.settings.isNotEmpty()
    val popupModule = GridSettingsPopup.current
    val isPopupOpen = popupModule === module

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .shadow(
                if (enabled) 2.dp else 0.dp,
                RoundedCornerShape(7.dp),
                ambientColor = GridGlow,
                spotColor = GridGlow
            )
            .clip(RoundedCornerShape(7.dp))
            .background(
                Brush.verticalGradient(
                    if (enabled) listOf(GridRowTopOn, GridRowBottomOn)
                    else listOf(GridRowTopIdle, GridRowBottomIdle)
                )
            )
            .border(
                1.dp,
                if (isPopupOpen) GridStarOn else if (enabled) GridBorderOn else GridBorderIdle,
                RoundedCornerShape(7.dp)
            )
            .clickable { ModuleManager.toggle(module); onShortcutChanged() }
            .padding(horizontal = 8.dp, vertical = 6.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            module.name,
            fontSize = 10.sp,
            fontWeight = FontWeight.SemiBold,
            color = GridTextOn,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.weight(1f)
        )
        Row(
            horizontalArrangement = Arrangement.spacedBy(4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                if (isGridShortcut) "\u2605" else "\u2606",
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold,
                color = if (isGridShortcut) GridStarOn else GridStarOff,
                modifier = Modifier
                    .clickable { GridShortcuts.toggle(module.name) }
                    .padding(2.dp)
            )
            Box(
                modifier = Modifier
                    .size(14.dp)
                    .then(
                        if (hasSettings)
                            Modifier.clickable { GridSettingsPopup.toggle(module) }
                        else Modifier
                    ),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    if (isPopupOpen) "\u2212" else "+",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
            }
        }
    }
}

@Composable
private fun ModuleSettingsPopup(
    module            : BaseModule,
    onShortcutChanged : () -> Unit,
    onDismiss         : () -> Unit
) {
    val screenHeightDp = LocalConfiguration.current.screenHeightDp.dp
    val maxPopupHeight = (screenHeightDp - 120.dp).coerceAtLeast(160.dp)

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black.copy(alpha = 0.55f))
            .pointerInput(module) { detectTapGestures { onDismiss() } },
        contentAlignment = Alignment.Center
    ) {
        Column(
            modifier = Modifier
                .widthIn(min = 220.dp, max = 300.dp)
                .heightIn(max = maxPopupHeight)
                .shadow(10.dp, RoundedCornerShape(14.dp), ambientColor = GridGlow, spotColor = GridGlow)
                .clip(RoundedCornerShape(14.dp))
                .background(Brush.verticalGradient(listOf(GridPanelTop, GridPanelBottom)))
                .border(1.dp, GridBorderOn, RoundedCornerShape(14.dp))

                .pointerInput(module) { detectTapGestures { } }
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Brush.verticalGradient(listOf(GridHeaderTop, GridHeaderBottom)))
                    .padding(horizontal = 14.dp, vertical = 10.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    module.name,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Black,
                    color = GridTextOn,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f)
                )
                Text(
                    "\u2715",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = GridTextOn,
                    modifier = Modifier
                        .clickable { onDismiss() }
                        .padding(4.dp)
                )
            }

            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
                    .padding(horizontal = 14.dp, vertical = 12.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                if (module.settings.isEmpty()) {
                    Text("There's nothing to configure in this module", fontSize = 11.sp, color = GridTextDim)
                } else {
                    module.settings.forEach { s ->
                        if (module is ComboShortcut && s.name == "Modules") return@forEach
                        SettingRow(setting = s, onShortcutChanged = onShortcutChanged)
                    }
                    if (module is ComboShortcut) ComboShortcutPanel(module = module)
                    if (module is CommandHelper) CommandHelperPanel(module = module, onShortcutChanged = onShortcutChanged)
                    if (module.name == "Keybinds") KeybindEditorPanel(onShortcutChanged = onShortcutChanged)
                }
            }
        }
    }
}

private val HorionBg            = Color(0xFF07090E)
private val HorionSurface       = Color(0xFF0D111B)
private val HorionSurfaceRaised = Color(0xFF141A28)
private val HorionCardActive    = Color(0xFF122036)
private val HorionOutline       = Color(0xFF1B2233)
private val HorionOutlineStrong = Color(0xFF232B41)
private val HorionAccent        = Color(0xFF4C9BFF)
private val HorionAccentDim     = Color(0xFF4C9BFF).copy(alpha = 0.16f)
private val HorionOnBg          = Color(0xFFE9EEFC)
private val HorionOnBgDim       = Color(0xFF7E8AAD)
private val HorionSuccess       = Color(0xFF3DDC84)
private val HorionError         = Color(0xFFFF5C6C)

@Composable
private fun ConfigSection() {
    val scope = rememberCoroutineScope()
    val profiles      by Config.profiles.collectAsState(initial = emptyList())
    val activeProfile by Config.activeProfile.collectAsState(initial = null)
    var newName by remember { mutableStateOf("") }

    Column(
        modifier = Modifier.fillMaxSize().padding(horizontal = 10.dp, vertical = 10.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            OutlinedTextField(
                value = newName,
                onValueChange = { newName = it },
                singleLine = true,
                placeholder = { Text("Profile name", fontSize = 11.sp, color = NoxNoOnSurfaceDim) },
                modifier = Modifier.weight(1f),
                textStyle = androidx.compose.ui.text.TextStyle(fontSize = 12.sp, color = NoxNoOnSurface),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor   = NoxNoAccent,
                    unfocusedBorderColor = NoxNoOutline
                )
            )
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(8.dp))
                    .background(NoxNoAccent)
                    .clickable {
                        val trimmed = newName.trim()
                        if (trimmed.isNotEmpty()) {
                            scope.launch { Config.save(trimmed) }
                            newName = ""
                        }
                    }
                    .padding(horizontal = 14.dp, vertical = 12.dp)
            ) {
                Text("Save", fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = Color.White)
            }
        }

        HorizontalDivider(color = NoxNoOutlineStrong)

        if (profiles.isEmpty()) {
            Box(modifier = Modifier.fillMaxWidth().weight(1f), contentAlignment = Alignment.Center) {
                Text("No saved profiles yet.", fontSize = 12.sp, color = NoxNoOnSurfaceDim)
            }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxWidth().weight(1f),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                items(profiles) { profile ->
                    ConfigProfileRow(
                        name     = profile.name,
                        active   = profile.name == activeProfile,
                        onLoad   = { scope.launch { Config.load(profile.name) } },
                        onDelete = { scope.launch { Config.delete(profile.name) } }
                    )
                }
            }
        }
    }
}

@Composable
private fun ConfigProfileRow(
    name    : String,
    active  : Boolean,
    onLoad  : () -> Unit,
    onDelete: () -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth()
            .clip(RoundedCornerShape(10.dp))
            .background(if (active) NoxNoSurfaceVar else NoxNoSurface)
            .border(1.dp,
                if (active) NoxNoAccentLight.copy(0.6f) else NoxNoOutline,
                RoundedCornerShape(10.dp))
            .padding(horizontal = 12.dp, vertical = 10.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            name,
            fontSize = 13.sp,
            color = NoxNoOnBackground,
            fontWeight = if (active) FontWeight.SemiBold else FontWeight.Normal,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.weight(1f)
        )
        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            TextButton(onClick = onLoad, colors = ButtonDefaults.textButtonColors(contentColor = NoxNoAccentLight)) {
                Text("Load", fontSize = 11.sp)
            }
            TextButton(onClick = onDelete, colors = ButtonDefaults.textButtonColors(contentColor = NoxNoError)) {
                Text("Del", fontSize = 11.sp)
            }
        }
    }
}

@Composable
private fun FriendsSection() {
    var newName by remember { mutableStateOf("") }
    var friends by remember { mutableStateOf(FriendManager.getAll()) }

    fun refresh() { friends = FriendManager.getAll() }

    Column(
        modifier = Modifier.fillMaxSize().padding(horizontal = 10.dp, vertical = 10.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            OutlinedTextField(
                value = newName,
                onValueChange = { newName = it },
                singleLine = true,
                placeholder = { Text("Player name", fontSize = 11.sp, color = NoxNoOnSurfaceDim) },
                modifier = Modifier.weight(1f),
                textStyle = androidx.compose.ui.text.TextStyle(fontSize = 12.sp, color = NoxNoOnSurface),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor   = NoxNoAccent,
                    unfocusedBorderColor = NoxNoOutline
                )
            )
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(8.dp))
                    .background(NoxNoAccent)
                    .clickable {
                        val trimmed = newName.trim()
                        if (trimmed.isNotEmpty()) {
                            FriendManager.addFriend(trimmed)
                            newName = ""
                            refresh()
                        }
                    }
                    .padding(horizontal = 14.dp, vertical = 12.dp)
            ) {
                Text("Add", fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = Color.White)
            }
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                "${friends.size} friends • ignored by combat/movement modules",
                fontSize = 10.sp,
                color = NoxNoOnSurfaceDim
            )
            if (friends.isNotEmpty()) {
                TextButton(
                    onClick = { FriendManager.clear(); refresh() },
                    colors = ButtonDefaults.textButtonColors(contentColor = NoxNoError)
                ) {
                    Text("Clear all", fontSize = 11.sp)
                }
            }
        }

        HorizontalDivider(color = NoxNoOutlineStrong)

        Text("Nearby players • 150m", fontSize = 11.sp, fontWeight = FontWeight.SemiBold, color = NoxNoOnSurface)
        val nearby = com.noxnoclient.core.proxy.EntityTracker.getPlayers(150f)
            .filter { it.runtimeId != com.noxnoclient.core.proxy.EntityTracker.selfRuntimeId && it.name.isNotBlank() }
            .sortedBy { com.noxnoclient.utils.MathUtil.dist3sq(it.x, it.y, it.z, com.noxnoclient.core.proxy.EntityTracker.selfX, com.noxnoclient.core.proxy.EntityTracker.selfY, com.noxnoclient.core.proxy.EntityTracker.selfZ) }
            .take(12)
        if (nearby.isNotEmpty()) {
            LazyColumn(
                modifier = Modifier.fillMaxWidth().heightIn(max = 180.dp),
                verticalArrangement = Arrangement.spacedBy(5.dp)
            ) {
                items(nearby, key = { it.runtimeId }) { player ->
                    val isFriend = FriendManager.isFriend(player.name)
                    Row(
                        modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(8.dp)).background(NoxNoSurface).padding(horizontal = 10.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(player.name, modifier = Modifier.weight(1f), fontSize = 12.sp, color = if (isFriend) Color(0xFF39FF88) else NoxNoOnBackground)
                        TextButton(onClick = { if (isFriend) FriendManager.removeFriend(player.name) else FriendManager.addFriend(player.name); refresh() }) {
                            Text(if (isFriend) "Remove" else "Add", fontSize = 10.sp)
                        }
                    }
                }
            }
        }

        if (friends.isEmpty()) {
            Box(modifier = Modifier.fillMaxWidth().weight(1f), contentAlignment = Alignment.Center) {
                Text("No friends added yet.", fontSize = 12.sp, color = NoxNoOnSurfaceDim)
            }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxWidth().weight(1f),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                items(friends) { name ->
                    FriendRow(
                        name     = name,
                        onRemove = { FriendManager.removeFriend(name); refresh() }
                    )
                }
            }
        }
    }
}

@Composable
private fun FriendRow(name: String, onRemove: () -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth()
            .clip(RoundedCornerShape(10.dp))
            .background(NoxNoSurface)
            .border(1.dp, NoxNoOutline, RoundedCornerShape(10.dp))
            .padding(horizontal = 12.dp, vertical = 10.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            name,
            fontSize = 13.sp,
            color = NoxNoOnBackground,
            fontWeight = FontWeight.Normal,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.weight(1f)
        )
        TextButton(onClick = onRemove, colors = ButtonDefaults.textButtonColors(contentColor = NoxNoError)) {
            Text("Remove", fontSize = 11.sp)
        }
    }
}

@Composable
private fun ModuleCard(module: BaseModule, onShortcutChanged: () -> Unit) {
    var enabled  by remember { mutableStateOf(module.isEnabled) }
    var expanded by remember { mutableStateOf(false) }
    LaunchedEffect(module) { module.enabledFlow.collect { enabled = it } }

    val cardBg = when {
        expanded -> NoxNoModuleExpanded
        enabled  -> NoxNoModuleActive
        else     -> NoxNoSurface
    }
    val borderColor = when {
        enabled -> NoxNoModuleActiveBorder
        else    -> NoxNoOutline.copy(0.6f)
    }
    val textColor = if (enabled) NoxNoModuleActiveText else NoxNoOnSurface

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .animateContentSize(animationSpec = tween(280, easing = FastOutSlowInEasing))
            .clip(RoundedCornerShape(11.dp))
            .background(cardBg)
            .border(if (enabled) 1.5.dp else 1.dp, borderColor, RoundedCornerShape(11.dp))
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clickable {
                    if (module.settings.isNotEmpty()) expanded = !expanded
                    else ModuleManager.toggle(module)
                }
                .padding(horizontal = 14.dp, vertical = 11.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                module.name,
                fontSize = 13.sp,
                fontWeight = if (enabled) FontWeight.Bold else FontWeight.Medium,
                color = textColor,
                modifier = Modifier.weight(1f)
            )
            Switch(
                checked = enabled,
                onCheckedChange = { ModuleManager.toggle(module); onShortcutChanged() },
                colors = SwitchDefaults.colors(
                    checkedTrackColor   = NoxNoModuleActiveBorder,
                    checkedThumbColor   = Color.White,
                    uncheckedTrackColor = NoxNoOutlineStrong,
                    uncheckedThumbColor = NoxNoOnSurfaceDim
                ),
                modifier = Modifier
                    .scale(0.8f)
                    .height(18.dp)
            )
        }

        AnimatedVisibility(
            visible = expanded && module.settings.isNotEmpty(),
            enter   = expandVertically(
                          animationSpec = tween(320, easing = FastOutSlowInEasing),
                          expandFrom    = Alignment.Top
                      ) + fadeIn(animationSpec = tween(280, delayMillis = 40, easing = LinearOutSlowInEasing)),
            exit    = shrinkVertically(
                          animationSpec = tween(260, easing = FastOutSlowInEasing),
                          shrinkTowards = Alignment.Top
                      ) + fadeOut(animationSpec = tween(160, easing = LinearEasing))
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color(0x22000000))
                    .padding(horizontal = 14.dp, vertical = 11.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                module.settings.forEach { s ->
                    if (module is ComboShortcut && s.name == "Modules") return@forEach
                    SettingRow(setting = s, onShortcutChanged = onShortcutChanged)
                }
                if (module is ComboShortcut) {
                    ComboShortcutPanel(module = module)
                }
                if (module is CommandHelper) {
                    CommandHelperPanel(module = module, onShortcutChanged = onShortcutChanged)
                }
                if (module.name == "Keybinds") {
                    KeybindEditorPanel(onShortcutChanged = onShortcutChanged)
                }
            }
        }
    }
}

@Composable
private fun SettingRow(setting: ModuleSetting<*>, onShortcutChanged: () -> Unit) {
    when (setting) {
        is FloatSetting -> {
            var v by remember { mutableFloatStateOf(setting.value) }
            Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text(setting.name, fontSize = 12.sp, color = NoxNoOnSurface)
                    Text("%.2f".format(v), fontSize = 12.sp, color = NoxNoAccentLight,
                        fontWeight = FontWeight.SemiBold)
                }
                Slider(
                    value = v,
                    onValueChange = { v = it; setting.value = it },
                    valueRange = setting.min..setting.max,
                    modifier = Modifier.height(24.dp),
                    colors = SliderDefaults.colors(
                        thumbColor         = NoxNoAccentLight,
                        activeTrackColor   = NoxNoAccent,
                        inactiveTrackColor = NoxNoOutlineStrong
                    )
                )
            }
        }
        is IntSetting -> {
            var v by remember { mutableFloatStateOf(setting.value.toFloat()) }
            Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text(setting.name, fontSize = 12.sp, color = NoxNoOnSurface)
                    Text(v.roundToInt().toString(), fontSize = 12.sp, color = NoxNoAccentLight,
                        fontWeight = FontWeight.SemiBold)
                }

                val rawSteps = setting.max - setting.min - 1
                val steps = if (rawSteps in 1..100) rawSteps else 0
                Slider(
                    value = v,
                    onValueChange = { v = it; setting.value = it.roundToInt() },
                    valueRange = setting.min.toFloat()..setting.max.toFloat(),
                    steps = steps,
                    modifier = Modifier.height(24.dp),
                    colors = SliderDefaults.colors(
                        thumbColor         = NoxNoAccentLight,
                        activeTrackColor   = NoxNoAccent,
                        inactiveTrackColor = NoxNoOutlineStrong
                    )
                )
            }
        }
        is BoolSetting -> {
            var v by remember { mutableStateOf(setting.value) }
            val isShortcut = setting.name == "Shortcut"
            Row(
                Modifier.fillMaxWidth().padding(vertical = 2.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(setting.name, fontSize = 12.sp, color = NoxNoOnSurface)
                if (isShortcut) {
                    ShortcutToggle(checked = v) {
                        v = it; setting.value = it; onShortcutChanged()
                    }
                } else {
                    Switch(
                        checked = v,
                        onCheckedChange = { v = it; setting.value = it },
                        colors = SwitchDefaults.colors(
                            checkedTrackColor   = NoxNoAccent,
                            checkedThumbColor   = Color.White,
                            uncheckedTrackColor = NoxNoOutlineStrong,
                            uncheckedThumbColor = NoxNoOnSurfaceDim
                        )
                    )
                }
            }
        }
        is EnumSetting<*> -> {
            @Suppress("UNCHECKED_CAST")
            val es = setting as EnumSetting<Enum<*>>
            var sel by remember { mutableStateOf(es.value) }
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text(es.name, fontSize = 12.sp, color = NoxNoOnSurface)
                Row(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    modifier = Modifier.horizontalScroll(rememberScrollState())
                ) {
                    es.values.forEach { opt ->
                        val isSel = sel == opt
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(50.dp))
                                .background(if (isSel) NoxNoSurfaceRaised else NoxNoSurface)
                                .border(1.dp,
                                    if (isSel) NoxNoOutlineStrong else NoxNoOutline,
                                    RoundedCornerShape(50.dp))
                                .clickable { sel = opt; es.value = opt }
                                .padding(horizontal = 14.dp, vertical = 6.dp)
                        ) {
                            Text(
                                opt.name.lowercase().replaceFirstChar { it.uppercase() },
                                fontSize = 11.sp,
                                color = if (isSel) NoxNoOnBackground else NoxNoOnSurface,
                                fontWeight = if (isSel) FontWeight.SemiBold else FontWeight.Normal
                            )
                        }
                    }
                }
            }
        }
        is StringSetting -> {
            var v by remember { mutableStateOf(setting.value) }
            Row(
                Modifier.fillMaxWidth().padding(vertical = 2.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(setting.name, fontSize = 12.sp, color = NoxNoOnSurface,
                    modifier = Modifier.weight(0.4f))
                OutlinedTextField(
                    value = v,
                    onValueChange = { v = it; setting.value = it },
                    singleLine = true,
                    modifier = Modifier.weight(0.6f).height(40.dp),
                    textStyle = androidx.compose.ui.text.TextStyle(fontSize = 11.sp, color = NoxNoOnSurface),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor   = NoxNoAccent,
                        unfocusedBorderColor = NoxNoOutline
                    )
                )
            }
        }
        else -> {}
    }
}

@Composable
private fun KeybindsInfoCard() {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(10.dp))
            .background(NoxNoSurface.copy(alpha = 0.75f))
            .border(1.dp, NoxNoOutline.copy(alpha = 0.5f), RoundedCornerShape(10.dp))
            .padding(12.dp)
    ) {
        Text("KEYBINDS", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = NoxNoAccentLight)
        Spacer(Modifier.height(4.dp))
        Text(
            "Visual > Keybinds içinden istediğin modüle tuş ata. Global kullanım için Dashboard > Settings > Keyboard Keybinds bölümünden erişim hizmetini bir kez aç.",
            fontSize = 10.sp,
            color = NoxNoOnSurfaceDim
        )
    }
}

private fun keyName(keyCode: Int): String {
    val raw = android.view.KeyEvent.keyCodeToString(keyCode)
        .removePrefix("KEYCODE_")
        .replace('_', ' ')
    return raw.ifBlank { "UNKNOWN" }
}

@Composable
private fun KeybindEditorPanel(onShortcutChanged: () -> Unit) {
    val captureId by KeybindsManager.captureId.collectAsState()
    val entries = remember(KeybindsManager.getAllKeybinds()) {
        KeybindsManager.getAllKeybinds().values.sortedBy { it.module.name }
    }

    Column(verticalArrangement = Arrangement.spacedBy(7.dp)) {
        Text("Assign keys", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = NoxNoOnSurface)
        entries.forEach { bind ->
            val isCapturing = captureId == bind.id
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(if (isCapturing) NoxNoAccentDark.copy(0.28f) else NoxNoBackground.copy(0.35f))
                    .border(1.dp, if (isCapturing) NoxNoAccent else NoxNoOutline, RoundedCornerShape(8.dp))
                    .padding(horizontal = 9.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(bind.module.name, fontSize = 11.sp, color = NoxNoOnSurface, fontWeight = FontWeight.SemiBold)
                    val mods = buildList {
                        if (bind.requiresCtrl) add("CTRL")
                        if (bind.requiresShift) add("SHIFT")
                        if (bind.requiresAlt) add("ALT")
                    }
                    Text(
                        if (mods.isEmpty()) keyName(bind.keyCode) else mods.joinToString("+") + "+" + keyName(bind.keyCode),
                        fontSize = 10.sp,
                        color = NoxNoAccentLight
                    )
                }
                TextButton(
                    onClick = {
                        if (isCapturing) KeybindsManager.cancelCapture()
                        else KeybindsManager.beginCapture(bind.id)
                    },
                    colors = ButtonDefaults.textButtonColors(contentColor = if (isCapturing) NoxNoError else NoxNoAccentLight)
                ) {
                    Text(if (isCapturing) "CANCEL" else "SET", fontSize = 10.sp)
                }
            }
        }
        if (captureId != null) {
            Text(
                "Bastığın tuş kaydedilecek. ESC ile iptal edebilirsin.",
                fontSize = 9.sp,
                color = NoxNoOnSurfaceDim
            )
        }
    }
}

@Composable
private fun ComboShortcutPanel(module: ComboShortcut) {
    var selected by remember(module) {
        mutableStateOf(
            module.targets.value.split(",").map { it.trim() }.filter { it.isNotEmpty() }.toSet()
        )
    }

    val allModules = remember(module) {
        ModuleCategory.values()
            .flatMap { ModuleManager.byCategory(it) }
            .distinctBy { it.name }
            .filter { it.name != module.name }
    }

    HorizontalDivider(color = NoxNoOutline.copy(0.5f), modifier = Modifier.padding(vertical = 2.dp))
    Text("Select modules", fontSize = 11.sp, color = NoxNoOnSurfaceDim)

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .heightIn(max = 220.dp)
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(2.dp)
    ) {
        allModules.forEach { mod ->
            val isChecked = mod.name in selected
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(6.dp))
                    .background(if (isChecked) NoxNoSurface else Color.Transparent)
                    .clickable {
                        selected = if (isChecked) selected - mod.name else selected + mod.name
                        module.targets.value = selected.joinToString(", ")
                    }
                    .padding(horizontal = 6.dp, vertical = 5.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(14.dp)
                        .clip(RoundedCornerShape(3.dp))
                        .background(if (isChecked) NoxNoAccent else Color.Transparent)
                        .border(
                            1.dp,
                            if (isChecked) NoxNoAccent else NoxNoOutlineStrong,
                            RoundedCornerShape(3.dp)
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    if (isChecked) {
                        Text("✓", fontSize = 9.sp, color = Color.White, fontWeight = FontWeight.Bold)
                    }
                }
                Text(
                    mod.name,
                    fontSize = 11.sp,
                    color = NoxNoOnSurface.copy(alpha = if (isChecked) 1f else 0.7f),
                    modifier = Modifier.weight(1f)
                )
            }
        }
    }

    if (selected.isNotEmpty()) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(8.dp))
                .background(NoxNoAccent)
                .clickable {
                    selected.forEach { name ->
                        ModuleManager.byName(name)?.let { ModuleManager.enable(it) }
                    }
                }
                .padding(vertical = 8.dp),
            contentAlignment = Alignment.Center
        ) {
            Text(
                module.comboName.value.ifBlank { "Combo" },
                fontSize = 12.sp,
                fontWeight = FontWeight.SemiBold,
                color = NoxNoOnBackground
            )
        }
    }
}

@Composable
private fun CommandHelperPanel(module: CommandHelper, onShortcutChanged: () -> Unit) {
    var entries by remember(module) { mutableStateOf(module.entries) }
    var adding by remember(module) { mutableStateOf(false) }
    var newEntry by remember(module) { mutableStateOf("") }

    HorizontalDivider(color = NoxNoOutline.copy(0.5f), modifier = Modifier.padding(vertical = 2.dp))

    Row(
        Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text("Saved commands", fontSize = 11.sp, color = NoxNoOnSurfaceDim)
        Box(
            modifier = Modifier
                .clip(RoundedCornerShape(6.dp))
                .background(NoxNoSurfaceRaised)
                .border(1.dp, NoxNoOutlineStrong, RoundedCornerShape(6.dp))
                .clickable { adding = !adding }
                .padding(horizontal = 10.dp, vertical = 4.dp)
        ) {
            Text(
                if (adding) "×" else "+",
                fontSize = 13.sp,
                color = NoxNoAccentLight,
                fontWeight = FontWeight.Bold
            )
        }
    }

    if (adding) {
        Row(
            Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            OutlinedTextField(
                value = newEntry,
                onValueChange = { newEntry = it },
                singleLine = true,
                placeholder = { Text("/gamemode creative or a chat message", fontSize = 10.sp) },
                modifier = Modifier.weight(1f).height(40.dp),
                textStyle = androidx.compose.ui.text.TextStyle(fontSize = 11.sp, color = NoxNoOnSurface),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor   = NoxNoAccent,
                    unfocusedBorderColor = NoxNoOutline
                )
            )
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(6.dp))
                    .background(NoxNoAccent)
                    .clickable {
                        if (newEntry.isNotBlank()) {
                            module.addEntry(newEntry)
                            entries = module.entries
                            newEntry = ""
                            adding = false
                            onShortcutChanged()
                        }
                    }
                    .padding(horizontal = 12.dp, vertical = 10.dp)
            ) {
                Text("Add", fontSize = 11.sp, color = NoxNoOnBackground, fontWeight = FontWeight.SemiBold)
            }
        }
    }

    if (entries.isNotEmpty()) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .heightIn(max = 200.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            entries.forEach { entry ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(6.dp))
                        .background(NoxNoSurface)
                        .padding(horizontal = 8.dp, vertical = 8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        entry,
                        fontSize = 11.sp,
                        color = NoxNoOnSurface,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier
                            .weight(1f)
                            .clickable { module.send(entry) }
                    )
                    Text(
                        "×",
                        fontSize = 13.sp,
                        color = NoxNoOnSurfaceDim,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier
                            .clickable {
                                module.removeEntry(entry)
                                entries = module.entries
                                onShortcutChanged()
                            }
                            .padding(start = 8.dp)
                    )
                }
            }
        }
    } else if (!adding) {
        Text("No saved commands yet", fontSize = 10.sp, color = NoxNoOnSurfaceDim)
    }
}

@Composable
private fun ShortcutToggle(checked: Boolean, onCheckedChange: (Boolean) -> Unit) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(50.dp))
            .background(if (checked) NoxNoSurfaceRaised else Color.Transparent)
            .border(1.5.dp,
                if (checked) NoxNoOutlineStrong else NoxNoOutline,
                RoundedCornerShape(50.dp))
            .clickable { onCheckedChange(!checked) }
            .padding(horizontal = 14.dp, vertical = 6.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            if (checked) "On" else "Off",
            fontSize = 11.sp,
            color = if (checked) NoxNoOnBackground else NoxNoOnSurfaceDim,
            fontWeight = if (checked) FontWeight.SemiBold else FontWeight.Normal
        )
    }
}
