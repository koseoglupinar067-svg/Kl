
package com.noxnoclient.module.movement

import com.noxnoclient.core.proxy.EntityTracker
import com.noxnoclient.events.PacketEvent
import com.noxnoclient.module.*
import org.cloudburstmc.math.vector.Vector3f
import org.cloudburstmc.protocol.bedrock.data.PlayerAuthInputData
import org.cloudburstmc.protocol.bedrock.packet.PlayerAuthInputPacket
import org.cloudburstmc.protocol.bedrock.packet.SetEntityMotionPacket

class AirJump : BaseModule(
    name        = "AirJump",
    category    = ModuleCategory.MOVEMENT,
    description = "Applies extra upward push when pressing jump while airborne"
) {
    private val jumpPower     = float("Jump Power",      0.42f, 0.1f, 1.2f)
    private val maxAirJumps   = int  ("Max Air Jumps",    1,     1,   10)
    private val infinite      = bool ("Infinite",         false)
    private val cooldownMs    = int  ("Cooldown",         250,   50,  1000)
    private val resetOnGround = bool ("Reset On Ground",  true)

    @Volatile private var jumpsUsed      = 0
    @Volatile private var wasJumpPressed = false
    @Volatile private var lastJumpMs     = 0L
    @Volatile private var wasOnGround    = true

    override fun onEnable() {
        super.onEnable()
        jumpsUsed = 0
        wasJumpPressed = false
        lastJumpMs = 0L
        wasOnGround = EntityTracker.selfOnGround
    }

    override fun onPacket(event: PacketEvent) {
        if (!isEnabled) return
        if (event.direction != PacketEvent.Direction.CLIENT_TO_SERVER) return
        val pkt = event.packet as? PlayerAuthInputPacket ?: return

        val onGround = EntityTracker.selfOnGround
        if (resetOnGround.value && onGround && !wasOnGround) {
            jumpsUsed = 0
        }
        wasOnGround = onGround

        val jumpPressed = pkt.inputData.contains(PlayerAuthInputData.JUMPING)

        val justPressed = jumpPressed && !wasJumpPressed
        wasJumpPressed = jumpPressed

        if (!justPressed) return
        if (onGround) return

        val now = System.currentTimeMillis()
        if (now - lastJumpMs < cooldownMs.value) return

        if (!infinite.value && jumpsUsed >= maxAirJumps.value) return

        lastJumpMs = now
        jumpsUsed++

        event.session.clientBound(SetEntityMotionPacket().apply {
            runtimeEntityId = EntityTracker.selfRuntimeId
            motion = Vector3f.from(0f, jumpPower.value, 0f)
        })
    }
}
