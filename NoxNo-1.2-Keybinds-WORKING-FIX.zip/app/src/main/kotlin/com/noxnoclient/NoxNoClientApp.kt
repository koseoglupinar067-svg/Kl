package com.noxnoclient

import android.app.Application
import android.content.ContentValues
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.util.Log
import java.io.File
import com.noxnoclient.auth.AccountManager
import com.noxnoclient.auth.MicrosoftAuthManager
import com.noxnoclient.config.Config
import com.noxnoclient.config.ServerConfig
import com.noxnoclient.core.relay.Definitions
import com.noxnoclient.module.ModuleManager
import com.noxnoclient.module.social.FriendManager
import com.noxnoclient.module.keybinds.DefaultKeybinds

import com.noxnoclient.module.combat.AnchorAura
import com.noxnoclient.module.combat.AntiBed
import com.noxnoclient.module.combat.AntiCrystal
import com.noxnoclient.module.combat.AutoArmor
import com.noxnoclient.module.combat.AutoTotem
import com.noxnoclient.module.combat.AutoGap
import com.noxnoclient.module.combat.GappleSwitch

import com.noxnoclient.module.combat.AutoTrapModule
import com.noxnoclient.module.combat.BedAura
import com.noxnoclient.module.combat.CTrapModule
import com.noxnoclient.module.combat.ObsidianMinerModule
import com.noxnoclient.module.combat.Criticals
import com.noxnoclient.module.combat.CrystalAura
import com.noxnoclient.module.combat.HitboxModule
import com.noxnoclient.module.combat.HotbarSwitcherModule
import com.noxnoclient.module.combat.KillAura
import com.noxnoclient.module.combat.KillAuraV3
import com.noxnoclient.module.combat.SCRFighter
import com.noxnoclient.module.combat.SelfTrapModule
import com.noxnoclient.module.combat.TPAura
import com.noxnoclient.module.combat.TriggerBotModule

import com.noxnoclient.module.misc.ComboShortcut
import com.noxnoclient.module.misc.CommandHelper
import com.noxnoclient.module.misc.ChatAdvertiser
import com.noxnoclient.module.misc.ChatSpammer
import com.noxnoclient.module.player.AutoDisconnect
import com.noxnoclient.module.visual.Performance
import com.noxnoclient.module.misc.PopCounter

import com.noxnoclient.module.movement.AirJump
import com.noxnoclient.module.movement.AntiKnockback
import com.noxnoclient.module.movement.BypassFly
import com.noxnoclient.module.movement.ElytraFly
import com.noxnoclient.module.movement.Jetpack
import com.noxnoclient.module.movement.MotionFly
import com.noxnoclient.module.movement.NoClipModule
import com.noxnoclient.module.movement.NoFallDamage
import com.noxnoclient.module.movement.Speed
import com.noxnoclient.module.movement.Timer

import com.noxnoclient.module.visual.FlatArrayModule
import com.noxnoclient.module.visual.FOVChanger
import com.noxnoclient.module.visual.FullBright
import com.noxnoclient.module.visual.NoHurtCam
import com.noxnoclient.module.visual.NoFire
import com.noxnoclient.module.visual.TargetCircle
import com.noxnoclient.module.visual.S4Switch
import com.noxnoclient.module.visual.TargetESP
import com.noxnoclient.module.visual.WatermarkModule
import com.noxnoclient.module.visual.KeybindsModule

import com.noxnoclient.module.player.AntiLagModule

import com.noxnoclient.utils.UiUtil
import com.noxnoclient.utils.WorldBlockTracker

class NoxNoClientApp : Application() {

    companion object {
        private const val TAG = "NoxNoClientApp"
        lateinit var instance: NoxNoClientApp
            private set
    }

    override fun onCreate() {
        super.onCreate()
        instance = this

        installCrashLogger()

        ServerConfig.init(applicationContext)
        Config.init(applicationContext)
        AccountManager.init(applicationContext)
        MicrosoftAuthManager.init(applicationContext)
        FriendManager.init(applicationContext)

        Thread({
            try {
                Definitions.init(applicationContext)
            } catch (e: Exception) {
                Log.e(TAG, "Definitions load error: ${e.message}", e)
            }
        }, "NoxNoDefinitionsLoader").apply {
            isDaemon = true
            start()
        }

        WorldBlockTracker.init()
        UiUtil.initIcons(applicationContext)
        registerModules()
        DefaultKeybinds.init(applicationContext)
    }

    private fun installCrashLogger() {
        val defaultHandler = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { thread, throwable ->
            try {
                val content = "${java.util.Date()}\n\n${Log.getStackTraceString(throwable)}"
                writeCrashToDownloads(content)
            } catch (e: Exception) {
                Log.e(TAG, "Failed to write crash log: ${e.message}", e)
            }
            defaultHandler?.uncaughtException(thread, throwable)
        }
    }

    private fun writeCrashToDownloads(content: String) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val resolver = applicationContext.contentResolver
            val values = ContentValues().apply {
                put(MediaStore.Downloads.DISPLAY_NAME, "baba.txt")
                put(MediaStore.Downloads.MIME_TYPE, "text/plain")
                put(MediaStore.Downloads.IS_PENDING, 1)
            }
            val uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values) ?: return
            resolver.openOutputStream(uri)?.use { it.write(content.toByteArray()) }
            values.clear()
            values.put(MediaStore.Downloads.IS_PENDING, 0)
            resolver.update(uri, values, null, null)
        } else {
            @Suppress("DEPRECATION")
            val downloadsDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
            File(downloadsDir, "baba.txt").writeText(content)
        }
    }

    private fun registerModules() {
        ModuleManager.registerAll(

            KillAura(),
            KillAuraV3(),
            TPAura(),
            SCRFighter(),
            TriggerBotModule(),
            HitboxModule(),
            HotbarSwitcherModule(),
            Criticals(),
            CrystalAura(),
            AntiCrystal(),
            AnchorAura(),
            BedAura(),
            AutoGap(),
            AntiBed(),
            AutoTrapModule(),
            SelfTrapModule(),
            CTrapModule(),
            ObsidianMinerModule(),
            AutoTotem(),
            AutoArmor(),

            Speed(),
            MotionFly(),
            BypassFly(),
            ElytraFly(),
            Jetpack(),
            AirJump(),
            NoFallDamage(),
            AntiKnockback(),
            NoClipModule(),
            Timer(),

            TargetESP(),
            TargetCircle(),
            S4Switch(),
            NoFire(),
            FullBright(),
            NoHurtCam(),
            FOVChanger(),
            FlatArrayModule(),
            WatermarkModule(),
            KeybindsModule(),

            AntiLagModule(),

            PopCounter(),
            ChatAdvertiser(),
            ChatSpammer(),
            ComboShortcut(1),
            ComboShortcut(2),
            AutoDisconnect(),
            Performance(),
            CommandHelper()
        )
    }
}
