package com.noxnoclient.utils

import com.noxnoclient.core.proxy.EntityTracker
import kotlin.math.atan2
import kotlin.math.hypot
import kotlin.random.Random

object RotationEngine {

    enum class Mode { Linear, Predictive, GCD }

    data class Rotation(val yaw: Float, val pitch: Float)

    private const val GCD_MIN_FACTOR = 0.12f
    private const val GCD_MAX_FACTOR = 0.55f
    private const val GCD_JITTER_DEG = 0.35f

    fun rotationTo(
        selfX: Float, selfY: Float, selfZ: Float,
        target: EntityTracker.TrackedEntity,
        mode: Mode,
        leadSeconds: Float = 0.12f
    ): Rotation {
        val (tx, ty, tz) = when (mode) {
            Mode.Predictive -> Triple(
                target.x + target.velX * leadSeconds,
                target.y + target.velY * leadSeconds,
                target.z + target.velZ * leadSeconds
            )
            else -> Triple(target.x, target.y, target.z)
        }

        val dx = tx - selfX
        val dz = tz - selfZ
        val dy = (ty + 1.2f) - (selfY + 1.62f)
        val horizDist = hypot(dx.toDouble(), dz.toDouble()).toFloat()

        val yaw = Math.toDegrees(atan2(dx.toDouble(), dz.toDouble())).toFloat().let { if (it < 0) it + 360f else it }
        val pitch = -Math.toDegrees(atan2(dy.toDouble(), horizDist.toDouble())).toFloat()

        return Rotation(yaw, pitch.coerceIn(-90f, 90f))
    }

    fun step(
        curYaw: Float, curPitch: Float,
        target: Rotation,
        mode: Mode,
        baseFactor: Float
    ): Rotation {
        return when (mode) {
            Mode.Linear, Mode.Predictive -> Rotation(
                smoothAngle(curYaw, target.yaw, baseFactor),
                smoothPitch(curPitch, target.pitch, baseFactor)
            )
            Mode.GCD -> gcdStep(curYaw, curPitch, target)
        }
    }

    private fun gcdStep(curYaw: Float, curPitch: Float, target: Rotation): Rotation {
        var dYaw = target.yaw - curYaw
        if (dYaw > 180f) dYaw -= 360f
        if (dYaw < -180f) dYaw += 360f
        val dPitch = target.pitch - curPitch

        val errorMag = hypot(dYaw.toDouble(), dPitch.toDouble()).toFloat()
        val dynamicFactor = GCD_MIN_FACTOR + (GCD_MAX_FACTOR - GCD_MIN_FACTOR) *
            (errorMag / (errorMag + 8f)).coerceIn(0f, 1f)

        val jitterYaw = (Random.nextFloat() - 0.5f) * GCD_JITTER_DEG
        val jitterPitch = (Random.nextFloat() - 0.5f) * GCD_JITTER_DEG

        var newYaw = curYaw + dYaw * dynamicFactor + jitterYaw
        newYaw %= 360f
        if (newYaw > 180f) newYaw -= 360f
        if (newYaw < -180f) newYaw += 360f

        val newPitch = (curPitch + dPitch * dynamicFactor + jitterPitch).coerceIn(-90f, 90f)

        return Rotation(newYaw, newPitch)
    }

    private fun smoothAngle(cur: Float, tgt: Float, f: Float): Float {
        var d = tgt - cur
        if (d > 180f) d -= 360f
        if (d < -180f) d += 360f
        var r = (cur + d * f) % 360f
        if (r > 180f) r -= 360f
        if (r < -180f) r += 360f
        return r
    }

    private fun smoothPitch(cur: Float, tgt: Float, f: Float) =
        (cur + (tgt - cur) * f).coerceIn(-90f, 90f)
}
