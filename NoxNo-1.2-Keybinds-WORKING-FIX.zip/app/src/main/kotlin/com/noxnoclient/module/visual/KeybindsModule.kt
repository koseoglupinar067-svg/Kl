package com.noxnoclient.module.visual

import com.noxnoclient.module.BaseModule
import com.noxnoclient.module.ModuleCategory

/**
 * Global keyboard/gamepad keybind controller. The actual global key capture is
 * performed by NoxNoKeybindAccessibilityService; this module is the in-client
 * switch and configuration entry for it.
 */
class KeybindsModule : BaseModule(
    name = "Keybinds",
    category = ModuleCategory.VISUAL,
    description = "Global module keybinds with chat-safe text input handling"
) {
    val captureEnabled = bool("Global Keybinds", true)
    val ignoreTextInput = bool("Ignore Text Input", true)
    val shortcut = bool("Shortcut", false)

    init {
        // Keybinds are a controller, so they are enabled by default.
        setEnabled(true)
    }
}
