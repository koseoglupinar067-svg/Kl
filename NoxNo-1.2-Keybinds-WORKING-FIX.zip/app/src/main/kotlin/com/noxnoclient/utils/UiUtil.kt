package com.noxnoclient.utils

import android.content.Context
import android.content.res.Resources
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import java.util.concurrent.ConcurrentHashMap

object UiUtil {

    // ---- Overlay FOV state ----

    const val VANILLA_FOV_DEFAULT = 110f

    @Volatile
    var currentFov: Float = VANILLA_FOV_DEFAULT
        private set

    fun setFov(value: Float) {
        currentFov = value
    }

    fun resetFov() {
        currentFov = VANILLA_FOV_DEFAULT
    }

    // ---- Item icon cache ----

    private var iconResources: Resources? = null
    private var iconPackageName: String? = null
    private val iconCache = ConcurrentHashMap<String, Bitmap?>()

    fun initIcons(context: Context) {
        iconResources   = context.resources
        iconPackageName = context.packageName
    }

    fun getIcon(identifier: String?): Bitmap? {
        if (identifier.isNullOrBlank()) return null
        val name = identifier.removePrefix("minecraft:")
        return iconCache.getOrPut(name) { loadIcon(name) }
    }

    private fun loadIcon(name: String): Bitmap? {
        val res = iconResources ?: return null
        val pkg = iconPackageName ?: return null
        return try {
            val resId = res.getIdentifier("item_$name", "drawable", pkg)
            if (resId == 0) null else BitmapFactory.decodeResource(res, resId)
        } catch (_: Exception) {
            null
        }
    }
}
