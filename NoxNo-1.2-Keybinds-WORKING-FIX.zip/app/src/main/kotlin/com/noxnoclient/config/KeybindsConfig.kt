package com.noxnoclient.config

import android.content.Context
import android.content.SharedPreferences
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import com.noxnoclient.module.keybinds.Keybind
import com.noxnoclient.module.keybinds.KeybindsManager
import com.noxnoclient.module.ModuleManager

/**
 * Keybinds configuration storage and persistence
 */
class KeybindsConfig(private val context: Context) {

    companion object {
        private const val PREFS_NAME = "noxno_keybinds_config"
        private const val KEY_KEYBINDS = "keybinds_data"
    }

    private val sharedPreferences: SharedPreferences =
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    private val gson = Gson()

    /**
     * Save all keybinds to storage
     */
    fun saveKeybinds() {
        val allKeybinds = KeybindsManager.getAllKeybinds()
        val json = gson.toJson(allKeybinds.values.map {
            KeybindData(it.id, it.keyCode, it.requiresCtrl, it.requiresShift, it.requiresAlt, it.isActive, it.module.name)
        })

        sharedPreferences.edit().apply {
            putString(KEY_KEYBINDS, json)
            apply()
        }
    }

    /**
     * Load all keybinds from storage
     */
    fun loadKeybinds() {
        val json = sharedPreferences.getString(KEY_KEYBINDS, null) ?: return

        try {
            val type = object : TypeToken<List<KeybindData>>() {}.type
            val keybindsList: List<KeybindData> = gson.fromJson(json, type)

            keybindsList.forEach { data ->
                val module = ModuleManager.byName(data.moduleName) ?: return@forEach
                if (!KeybindsManager.updateKeybind(
                        keybindId = data.id,
                        keyCode = data.keyCode,
                        requiresCtrl = data.requiresCtrl,
                        requiresShift = data.requiresShift,
                        requiresAlt = data.requiresAlt
                    )) {
                    KeybindsManager.registerKeybind(
                        keybindId = data.id,
                        module = module,
                        keyCode = data.keyCode,
                        requiresCtrl = data.requiresCtrl,
                        requiresShift = data.requiresShift,
                        requiresAlt = data.requiresAlt
                    )
                }
                KeybindsManager.setKeybindActive(data.id, data.isActive)
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    /**
     * Save a single keybind
     */
    fun saveKeybind(keybindId: String) {
        val keybind = KeybindsManager.getKeybind(keybindId) ?: return
        
        val allKeybinds = KeybindsManager.getAllKeybinds().toMutableMap()
        val json = gson.toJson(allKeybinds.values.map {
            KeybindData(it.id, it.keyCode, it.requiresCtrl, it.requiresShift, it.requiresAlt, it.isActive, it.module.name)
        })

        sharedPreferences.edit().apply {
            putString(KEY_KEYBINDS, json)
            apply()
        }
    }

    /**
     * Clear all saved keybinds
     */
    fun clearAllKeybinds() {
        sharedPreferences.edit().apply {
            remove(KEY_KEYBINDS)
            apply()
        }
    }

    /**
     * Export keybinds to JSON string
     */
    fun exportKeybindsToJson(): String {
        val allKeybinds = KeybindsManager.getAllKeybinds()
        return gson.toJson(allKeybinds.values.toList())
    }

    /**
     * Import keybinds from JSON string
     */
    fun importKeybindsFromJson(json: String): Boolean {
        return try {
            val type = object : TypeToken<List<KeybindData>>() {}.type
            val keybindsList: List<KeybindData> = gson.fromJson(json, type)

            KeybindsManager.clearAllKeybinds()

            keybindsList.forEach { data ->
                val module = ModuleManager.byName(data.moduleName) ?: return@forEach
                KeybindsManager.registerKeybind(
                    keybindId = data.id,
                    module = module,
                    keyCode = data.keyCode,
                    requiresCtrl = data.requiresCtrl,
                    requiresShift = data.requiresShift,
                    requiresAlt = data.requiresAlt
                )

                if (!data.isActive) {
                    KeybindsManager.setKeybindActive(data.id, false)
                }
            }

            saveKeybinds()
            true
        } catch (e: Exception) {
            e.printStackTrace()
            false
        }
    }

    /**
     * Data class for serialization
     */
    data class KeybindData(
        val id: String,
        val keyCode: Int,
        val requiresCtrl: Boolean,
        val requiresShift: Boolean,
        val requiresAlt: Boolean,
        val isActive: Boolean,
        val moduleName: String = ""
    )
    fun save() = saveKeybinds()
    fun load() = loadKeybinds()
}

