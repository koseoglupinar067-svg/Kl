package com.noxnoclient.module.combat

import com.noxnoclient.core.proxy.EntityTracker
import com.noxnoclient.events.PacketEvent
import com.noxnoclient.events.PacketEventBus
import com.noxnoclient.module.*
import com.noxnoclient.utils.InventoryUtil
import com.noxnoclient.utils.WorldBlockTracker
import org.cloudburstmc.protocol.bedrock.packet.InventoryTransactionPacket
import org.cloudburstmc.protocol.bedrock.packet.MobEquipmentPacket

class GappleSwitch : BaseModule(
    name        = "GappleSwitch",
    category    = ModuleCategory.COMBAT,
    description = "While holding a gapple, auto-switches to trident (water/rain/snow) or sword (air/block). Switches back to gapple on release."
) {
    private val tridentId  = string("Trident ID",  "minecraft:trident")
    private val swordId    = string("Sword ID",    "")
    private val switchBack = bool  ("Switch Back", true)
    private val shortcut   = bool  ("Shortcut",    false)

    private val NON_SOLID = setOf(
        "minecraft:air", "minecraft:void_air", "minecraft:cave_air",
        "minecraft:water", "minecraft:flowing_water",
        "minecraft:lava", "minecraft:flowing_lava"
    )

    @Volatile private var gappleSlot    = -1
    @Volatile private var switchedSlot  = -1
    @Volatile private var wasHoldingGapple = false
    @Volatile private var lastSwitchMs  = 0L

    private fun isGapple(slot: Int): Boolean {
        val item = EntityTracker.getInventoryItem(slot) ?: return false
        val id   = InventoryUtil.resolveIdentifier(item) ?: return false
        return id == "minecraft:enchanted_golden_apple" || id == "minecraft:golden_apple"
    }

    private fun isCurrentlyInsideBlock(): Boolean {
        val x = EntityTracker.selfX.toInt()
        val y = (EntityTracker.selfY + 1.5f).toInt()
        val z = EntityTracker.selfZ.toInt()
        if (!WorldBlockTracker.hasData(x, y, z)) return false
        val id = WorldBlockTracker.getBlockIdentifier(x, y, z) ?: return false
        return id !in NON_SOLID
    }

    private fun findHotbarSlot(targetId: String): Int {
        if (targetId.isBlank()) {
            for (s in 0..8) {
                val id = InventoryUtil.resolveIdentifier(EntityTracker.getInventoryItem(s) ?: continue) ?: continue
                if (id.contains("sword") || id.contains("axe")) return s
            }
            return -1
        }
        for (s in 0..8) {
            val id = InventoryUtil.resolveIdentifier(EntityTracker.getInventoryItem(s) ?: continue) ?: continue
            if (id == targetId) return s
        }
        return -1
    }

    private fun switchTo(slot: Int) {
        val session = PacketEventBus.currentSession ?: return
        lastSwitchMs = System.currentTimeMillis()
        session.serverBound(MobEquipmentPacket().apply {
            runtimeEntityId = EntityTracker.selfRuntimeId
            containerId     = 0
            hotbarSlot      = slot
            inventorySlot   = slot
            item            = EntityTracker.getInventoryItem(slot) ?: org.cloudburstmc.protocol.bedrock.data.inventory.ItemData.AIR
        })
        session.clientBound(MobEquipmentPacket().apply {
            runtimeEntityId = EntityTracker.selfRuntimeId
            containerId     = 0
            hotbarSlot      = slot
            inventorySlot   = slot
            item            = EntityTracker.getInventoryItem(slot) ?: org.cloudburstmc.protocol.bedrock.data.inventory.ItemData.AIR
        })
    }

    override fun onPacket(event: PacketEvent) {
        if (!isEnabled) return

        val hotbar = EntityTracker.selfHotbarSlot
        val holdingGapple = isGapple(hotbar)

        if (!holdingGapple && wasHoldingGapple) {
            // Switched away from gapple manually — reset
            wasHoldingGapple = false
            switchedSlot     = -1
            gappleSlot       = -1
            return
        }

        if (!holdingGapple) return

        wasHoldingGapple = true
        gappleSlot       = hotbar

        val now = System.currentTimeMillis()
        if (now - lastSwitchMs < 150L) return

        val inWater    = EntityTracker.selfInWater
        val isRaining  = EntityTracker.selfIsRaining
        val inBlock    = isCurrentlyInsideBlock()
        val wantTrident = inWater || isRaining
        val wantSword  = inBlock || (!inWater && !isRaining)

        val targetSlot = when {
            wantTrident -> findHotbarSlot(tridentId.value)
            wantSword   -> findHotbarSlot(swordId.value)
            else        -> -1
        }

        if (targetSlot != -1 && targetSlot != hotbar) {
            switchedSlot = targetSlot
            switchTo(targetSlot)
        }
    }
}
