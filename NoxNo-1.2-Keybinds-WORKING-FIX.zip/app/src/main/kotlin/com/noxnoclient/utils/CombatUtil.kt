package com.noxnoclient.utils

import com.noxnoclient.core.proxy.EntityTracker
import com.noxnoclient.core.relay.NoxNoRelaySession
import com.noxnoclient.events.PacketEvent
import com.noxnoclient.module.ModuleManager
import com.noxnoclient.module.combat.TPAura
import com.noxnoclient.module.movement.Timer
import kotlinx.coroutines.delay
import kotlinx.coroutines.sync.Mutex
import org.cloudburstmc.math.vector.Vector3f
import org.cloudburstmc.protocol.bedrock.data.inventory.ItemData
import org.cloudburstmc.protocol.bedrock.data.inventory.transaction.InventoryTransactionType
import org.cloudburstmc.protocol.bedrock.data.inventory.transaction.InventoryActionData
import org.cloudburstmc.protocol.bedrock.data.inventory.transaction.InventorySource
import org.cloudburstmc.protocol.bedrock.data.inventory.ContainerId
import org.cloudburstmc.protocol.bedrock.packet.AnimatePacket
import org.cloudburstmc.protocol.bedrock.packet.InventoryTransactionPacket
import org.cloudburstmc.protocol.bedrock.packet.MovePlayerPacket
import org.cloudburstmc.protocol.bedrock.packet.PlayerAuthInputPacket
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.math.*

object CombatUtil {

    // ---- Attack / swing packets ----

    fun sendSwing(session: NoxNoRelaySession) {
        session.serverBound(AnimatePacket().apply {
            action = AnimatePacket.Action.SWING_ARM
            runtimeEntityId = EntityTracker.selfRuntimeId
        })
    }

    fun sendAttack(
        session: NoxNoRelaySession,
        targetRid: Long,
        hotbarSlot: Int = EntityTracker.selfHotbarSlot,
        clickPos: Vector3f? = null
    ) {
        val heldItem = EntityTracker.getInventoryItem(hotbarSlot) ?: ItemData.AIR
        val target = EntityTracker.getById(targetRid)

        val playerPos = Vector3f.from(EntityTracker.selfX, EntityTracker.selfY, EntityTracker.selfZ)

        val finalClickPos = clickPos ?: if (target != null) {
            val heightOffset = if (target.isPlayer) 1.62f else 0.5f
            Vector3f.from(target.x, target.y + heightOffset, target.z)
        } else {
            playerPos
        }

        session.serverBound(InventoryTransactionPacket().apply {
            transactionType = InventoryTransactionType.ITEM_USE_ON_ENTITY
            runtimeEntityId = targetRid
            actionType = 1
            this.hotbarSlot = hotbarSlot
            itemInHand = heldItem
            playerPosition = playerPos
            clickPosition = finalClickPos

            actions.add(InventoryActionData(
                InventorySource.fromContainerWindowId(ContainerId.INVENTORY),
                hotbarSlot,
                heldItem,
                heldItem
            ))
        })
    }

    fun sendSwingAndAttack(session: NoxNoRelaySession, targetRid: Long, hotbarSlot: Int = EntityTracker.selfHotbarSlot) {
        sendSwing(session)
        sendAttack(session, targetRid, hotbarSlot)
    }

    // ---- Movement packets ----

    fun sendMove(
        session: NoxNoRelaySession,
        x: Float,
        y: Float,
        z: Float,
        yaw: Float,
        pitch: Float,
        onGround: Boolean = true,
        teleport: Boolean = false,
        mirrorToClient: Boolean = false
    ) {
        val movePacket = MovePlayerPacket().apply {
            runtimeEntityId = EntityTracker.selfRuntimeId
            position = Vector3f.from(x, y, z)
            rotation = Vector3f.from(pitch, yaw, yaw)
            mode = if (teleport) MovePlayerPacket.Mode.TELEPORT
                   else MovePlayerPacket.Mode.NORMAL
            isOnGround = onGround
            ridingRuntimeEntityId = 0L
        }
        session.serverBound(movePacket)
        if (mirrorToClient) session.clientBound(movePacket)
    }

    fun sendMoveAtSelf(
        session: NoxNoRelaySession,
        yaw: Float = EntityTracker.selfYaw,
        pitch: Float = EntityTracker.selfPitch,
        dyOffset: Float = 0f,
        onGround: Boolean = true,
        teleport: Boolean = false,
        mirrorToClient: Boolean = false
    ) = sendMove(
        session,
        EntityTracker.selfX,
        EntityTracker.selfY + dyOffset,
        EntityTracker.selfZ,
        yaw, pitch, onGround, teleport, mirrorToClient
    )

    private fun sendMoveAndTrack(
        session: NoxNoRelaySession,
        x: Float, y: Float, z: Float,
        yaw: Float, pitch: Float,
        onGround: Boolean,
        mirrorToClient: Boolean
    ) {
        sendMove(session, x, y, z, yaw, pitch, onGround, teleport = false, mirrorToClient = mirrorToClient)
        EntityTracker.selfX = x; EntityTracker.selfY = y; EntityTracker.selfZ = z
    }

    internal suspend fun dispatchStepped(
        session: NoxNoRelaySession,
        fromX: Float, fromY: Float, fromZ: Float,
        toX: Float, toY: Float, toZ: Float,
        yaw: Float, pitch: Float,
        onGround: Boolean,
        maxStep: Float,
        stepDelayMs: Long,
        onStep: ((Float, Float, Float, Boolean) -> Unit)? = null
    ) {
        val dx = toX - fromX; val dy = toY - fromY; val dz = toZ - fromZ
        val dist = sqrt(dx * dx + dy * dy + dz * dz)
        val step = maxStep.coerceAtLeast(0.1f)

        if (dist <= step) {
            sendMoveAndTrack(session, toX, toY, toZ, yaw, pitch, onGround, mirrorToClient = true)
            onStep?.invoke(toX, toY, toZ, true)
            return
        }

        val steps = ceil(dist / step).toInt().coerceIn(1, 10)
        val delayMs = stepDelayMs.coerceIn(1L, 100L)

        for (i in 1..steps) {
            val t = i.toFloat() / steps
            val cx = fromX + dx * t
            val cy = fromY + dy * t
            val cz = fromZ + dz * t
            val isFinal = i == steps
            sendMoveAndTrack(session, cx, cy, cz, yaw, pitch, onGround, mirrorToClient = isFinal)
            onStep?.invoke(cx, cy, cz, isFinal)
            if (!isFinal) delay(delayMs)
        }
    }

    // ---- Aim / rotation ----

    data class Rotation(val yaw: Float, val pitch: Float)

    fun toEntity(e: EntityTracker.TrackedEntity): Rotation =
        toPoint(e.x, e.y + 1.62f, e.z)

    fun toPoint(tx: Float, ty: Float, tz: Float): Rotation {
        val dx = tx - EntityTracker.selfX
        val dy = ty - (EntityTracker.selfY + 1.62f)
        val dz = tz - EntityTracker.selfZ
        val dist = sqrt(dx * dx + dz * dz).toDouble()
        val yaw = Math.toDegrees(atan2(-dx.toDouble(), dz.toDouble())).toFloat()
        val pitch = Math.toDegrees(-atan2(dy.toDouble(), dist)).toFloat()
        return Rotation(yaw, pitch)
    }

    fun approximate(r: Rotation, yawJitter: Float = 2f, pitchJitter: Float = 1f): Rotation {
        val y = r.yaw + (Math.random() * yawJitter * 2 - yawJitter).toFloat()
        val p = r.pitch + (Math.random() * pitchJitter * 2 - pitchJitter).toFloat()
        return Rotation(y.coerceIn(-180f, 180f), p.coerceIn(-90f, 90f))
    }

    fun smoothTo(
        currentYaw: Float, currentPitch: Float,
        target: Rotation,
        baseFactor: Float = 0.25f,
        speedJitter: Float = 0.08f,
        yawJitter: Float = 0.6f,
        pitchJitter: Float = 0.3f
    ): Rotation {
        val factor = (baseFactor + (Math.random() * speedJitter * 2 - speedJitter).toFloat())
            .coerceIn(0.02f, 1f)

        var diff = target.yaw - currentYaw
        if (diff > 180f) diff -= 360f
        if (diff < -180f) diff += 360f
        val rawYaw = currentYaw + diff * factor
        val rawPitch = currentPitch + (target.pitch - currentPitch) * factor

        val jitteredYaw = rawYaw + (Math.random() * yawJitter * 2 - yawJitter).toFloat()
        val jitteredPitch = rawPitch + (Math.random() * pitchJitter * 2 - pitchJitter).toFloat()

        return Rotation(normalize(jitteredYaw), jitteredPitch.coerceIn(-90f, 90f))
    }

    fun normalize(yaw: Float): Float {
        var y = yaw % 360f
        if (y > 180f) y -= 360f
        if (y < -180f) y += 360f
        return y
    }

    fun angleDiff(a: Float, b: Float): Float = abs(normalize(a - b))

    fun fovCheck(e: EntityTracker.TrackedEntity, fovDeg: Float): Boolean {
        if (fovDeg >= 360f) return true
        val r = toEntity(e)
        return angleDiff(r.yaw, EntityTracker.selfYaw) <= fovDeg / 2f
    }

    fun buildMovePacket(
        yaw: Float,
        pitch: Float,
        teleport: Boolean = false,
        onGround: Boolean = true
    ): MovePlayerPacket =
        MovePlayerPacket().apply {
            runtimeEntityId = EntityTracker.selfRuntimeId
            position = Vector3f.from(EntityTracker.selfX, EntityTracker.selfY, EntityTracker.selfZ)
            rotation = Vector3f.from(pitch, yaw, yaw)
            mode = if (teleport) MovePlayerPacket.Mode.TELEPORT
                   else MovePlayerPacket.Mode.NORMAL
            isOnGround = onGround
            ridingRuntimeEntityId = 0L
        }

    // ---- Crit-window exclusive lock ----

    private val perKeyLocks = ConcurrentHashMap<String, AtomicBoolean>()
    private val moduleLocks = ConcurrentHashMap<String, Mutex>()

    fun tryAcquire(key: String): Boolean {
        val lock = perKeyLocks.computeIfAbsent(key) { AtomicBoolean(false) }
        return lock.compareAndSet(false, true)
    }

    fun release(key: String) {
        perKeyLocks[key]?.set(false)
    }

    suspend fun tryRunWait(key: String, timeoutMs: Long, block: suspend () -> Unit): Boolean {
        val lock = moduleLocks.computeIfAbsent(key) { Mutex() }
        val acquired = kotlinx.coroutines.withTimeoutOrNull(timeoutMs) {
            lock.lock()
            true
        } ?: false
        if (!acquired) return false
        try {
            block()
        } finally {
            lock.unlock()
        }
        return true
    }

    suspend fun tryRun(moduleName: String, block: suspend () -> Unit) {
        val lock = moduleLocks.computeIfAbsent(moduleName) { Mutex() }
        if (!lock.tryLock()) return
        try {
            block()
        } finally {
            lock.unlock()
        }
    }

    // ---- PvP-timer stepped move dispatch ----

    object TimerPvP {

        private val timerModule: Timer? get() = ModuleManager.byName("Timer") as? Timer

        val enabled: Boolean get() = timerModule?.let { it.isEnabled && it.pvpModeEnabled } == true
        val maxStep: Float   get() = timerModule?.pvpMaxStep ?: 0.9f
        val stepDelayMs: Long get() = timerModule?.pvpStepDelayMs ?: 12L

        suspend fun dispatch(
            session        : NoxNoRelaySession,
            fromX: Float, fromY: Float, fromZ: Float,
            toX: Float, toY: Float, toZ: Float,
            yaw: Float, pitch: Float,
            onGround       : Boolean,
            mirrorToClient : Boolean = true
        ) {
            if (!enabled) {
                sendMoveAndTrack(session, toX, toY, toZ, yaw, pitch, onGround, mirrorToClient)
                TPAura.notifyExternalPositionOverride()
                return
            }

            dispatchStepped(
                session, fromX, fromY, fromZ, toX, toY, toZ,
                yaw, pitch, onGround, maxStep, stepDelayMs
            ) { _, _, _, _ -> TPAura.notifyExternalPositionOverride() }
        }
    }
}
