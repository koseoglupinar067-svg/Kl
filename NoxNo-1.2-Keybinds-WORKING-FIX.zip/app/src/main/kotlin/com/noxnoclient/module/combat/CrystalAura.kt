package com.noxnoclient.module.combat

import com.noxnoclient.utils.CombatUtil
import com.noxnoclient.core.proxy.EntityTracker
import com.noxnoclient.core.relay.NoxNoRelaySession
import com.noxnoclient.events.PacketEvent
import com.noxnoclient.events.PacketEventBus
import com.noxnoclient.module.*
import com.noxnoclient.utils.InventoryUtil
import com.noxnoclient.utils.MathUtil
import com.noxnoclient.utils.WorldBlockTracker
import kotlinx.coroutines.*
import org.cloudburstmc.math.vector.Vector3i
import org.cloudburstmc.protocol.bedrock.data.LevelEvent
import org.cloudburstmc.protocol.bedrock.packet.*
import kotlin.math.floor

class CrystalAura : BaseModule(
    name        = "CrystalAura",
    category    = ModuleCategory.COMBAT,
    description = "Places/breaks crystals at the best spot based on damage simulation"
) {

    companion object {
        private const val EXPLOSION_SIZE   = 6f
        private const val TICK_INTERVAL_MS = 25L
        private const val CRYSTAL_ID       = "minecraft:end_crystal"
        private const val PENDING_TIMEOUT_MS = 450L
        private const val PENDING_MATCH_RADIUS = 1.5f
        private const val BASE_VERTICAL_RANGE = 3

        private val NON_SOLID = setOf(
            "minecraft:air", "minecraft:water", "minecraft:flowing_water",
            "minecraft:lava", "minecraft:flowing_lava",
            "minecraft:void_air", "minecraft:cave_air"
        )
    }

    private val range           = float("Range",           10f,  3f,  10f)
    private val suicide         = bool ("Suicide",         false)
    private val place           = bool ("Place",           true)
    private val placeCount      = int  ("PlaceCount",      8,    1,   8)
    private val placeDelayMs    = int  ("PlaceDelay",      20,   20,  500)
    private val explodeDelayMs  = int  ("ExplodeDelay",    10,   10,  300)
    private val removeParticles = bool ("RemoveParticles", true)
    private val shortcut        = bool ("Shortcut",        false)

    @Volatile private var lastExplodeMs = 0L
    @Volatile private var lastPlaceMs   = 0L

    private var tickJob: Job? = null

    private data class PendingPlace(
        val x: Float, val y: Float, val z: Float,
        val sentAt: Long,
        val blockId: String,
        val itemNetId: Int,
        val hotbarSlot: Int
    )

    private val pendingPlaces = java.util.concurrent.CopyOnWriteArrayList<PendingPlace>()

    private data class ExplosionResult(val mostDamage: Float, val selfDamage: Float)

    override fun onEnable() {
        super.onEnable()
        lastExplodeMs = 0L
        lastPlaceMs   = 0L
        PacketEventBus.register(this)
        tickJob = scope.launch { tickLoop() }
    }

    override fun onDisable() {
        tickJob?.cancel()
        PacketEventBus.unregister(this)
        placeQueue.clear()
        pendingPlaces.clear()
        super.onDisable()
    }

    override fun onPacket(event: PacketEvent) {
        if (!isEnabled) return
        when (val pkt = event.packet) {
            is AddEntityPacket -> {
                if (!pkt.identifier.contains("crystal", ignoreCase = true)) return
                val now = System.currentTimeMillis()
                val cx = pkt.position.x; val cy = pkt.position.y; val cz = pkt.position.z

                val matched = pendingPlaces.filter {
                    MathUtil.dist3(it.x, it.y, it.z, cx, cy, cz) <= PENDING_MATCH_RADIUS
                }
                if (matched.isNotEmpty()) {
                    pendingPlaces.removeAll(matched)
                }

                val distToSelf = MathUtil.dist3(cx, cy, cz, EntityTracker.selfX, EntityTracker.selfY, EntityTracker.selfZ)
                if (now - lastExplodeMs < explodeDelayMs.value) {
                    return
                }
                if (distToSelf > range.value) {
                    return
                }

                val dmg = simulateExplosionDamage(cx, cy, cz)
                val hasRealTarget = dmg.mostDamage > 0f
                if ((hasRealTarget && dmg.selfDamage <= dmg.mostDamage) || suicide.value) {
                    val session = PacketEventBus.currentSession ?: return
                    explodeCrystal(session, pkt.runtimeEntityId)
                    lastExplodeMs = now
                }
            }
            is LevelEventPacket -> {
                if (removeParticles.value && pkt.type == LevelEvent.PARTICLE_EXPLOSION) event.cancel()
            }
            else -> {}
        }
    }

    private suspend fun tickLoop() {
        while (currentCoroutineContext().isActive) {
            if (isEnabled) tick()
            delay(TICK_INTERVAL_MS)
        }
    }

    private fun tick() {
        val session = PacketEventBus.currentSession ?: return
        val now = System.currentTimeMillis()
        checkTimedOutPlacements(session, now)
        if (now - lastExplodeMs >= explodeDelayMs.value) tryExplodeBest(session, now)
        if (place.value && now - lastPlaceMs >= placeDelayMs.value) tryPlaceBest(session, now)
    }

    private fun checkTimedOutPlacements(session: NoxNoRelaySession, now: Long) {
        if (pendingPlaces.isEmpty()) return
        val timedOut = pendingPlaces.filter { now - it.sentAt > PENDING_TIMEOUT_MS }
        if (timedOut.isEmpty()) return
        pendingPlaces.removeAll(timedOut)
    }

    private fun tryExplodeBest(session: NoxNoRelaySession, now: Long) {
        val crystals = EntityTracker.getCrystals(range.value)
        if (crystals.isEmpty()) return

        var bestId: Long? = null
        var bestDamage = -1f
        for (c in crystals) {
            val dmg = simulateExplosionDamage(c.x, c.y, c.z)
            val effective = if (dmg.selfDamage > dmg.mostDamage && !suicide.value) -1f else dmg.mostDamage
            if (effective > bestDamage) { bestDamage = effective; bestId = c.runtimeId }
        }

        if (bestId != null && bestDamage > 0f) {
            explodeCrystal(session, bestId)
            lastExplodeMs = now
        }
    }

    private var placeQueue: MutableList<Triple<Int, Int, Int>> = mutableListOf()

    private fun tryPlaceBest(session: NoxNoRelaySession, now: Long) {
        if (placeQueue.isEmpty()) {
            placeQueue = buildPlaceQueue()
            if (placeQueue.isEmpty()) {
                return
            }
        }

        val pos = placeQueue.removeAt(0)
        val placeDist = MathUtil.dist3(
            EntityTracker.selfX, EntityTracker.selfY, EntityTracker.selfZ,
            pos.first + 0.5f, pos.second + 1f, pos.third + 0.5f
        )
        if (placeDist > range.value) {
            return
        }

        val prepared = InventoryUtil.prepareItemForUse(session, CRYSTAL_ID) ?: run {
            placeQueue.clear()
            return
        }

        val blockPos = Vector3i.from(pos.first, pos.second, pos.third)
        val blockId = WorldBlockTracker.getBlockIdentifier(pos.first, pos.second, pos.third)
        if (blockId == null) {
            InventoryUtil.revert(session, prepared)
            return
        }

        val ok = InventoryUtil.sendPlacementUseRaw(
            session   = session,
            prepared  = prepared,
            blockPos  = blockPos,
            blockId   = blockId,
            blockFace = 1
        )
        InventoryUtil.revert(session, prepared)

        if (ok) {
            pendingPlaces.add(PendingPlace(
                x = pos.first + 0.5f, y = pos.second + 1f, z = pos.third + 0.5f,
                sentAt = now,
                blockId = blockId,
                itemNetId = prepared.item.netId,
                hotbarSlot = prepared.slot
            ))
            lastPlaceMs = now
        }
    }

    private fun buildPlaceQueue(): MutableList<Triple<Int, Int, Int>> {
        if (!WorldBlockTracker.hasAnyTerrainData()) return mutableListOf()

        val bases = LinkedHashSet<Triple<Int, Int, Int>>()
        bases.addAll(searchPlaceBase())

        val players = EntityTracker.getPlayers(range.value)
        for (target in players) {
            val tx = floor(target.x).toInt()
            val ty = floor(target.y).toInt() - 1
            val tz = floor(target.z).toInt()
            for ((dx, dz) in listOf(0 to 1, 0 to -1, 1 to 0, -1 to 0, 1 to 1, 1 to -1, -1 to 1, -1 to -1)) {
                val bx = tx + dx
                val bz = tz + dz
                val id = WorldBlockTracker.getBlockIdentifier(bx, ty, bz) ?: continue
                if (id != "minecraft:obsidian" && id != "minecraft:bedrock") continue
                val above = WorldBlockTracker.getBlockIdentifier(bx, ty + 1, bz)
                if (above != null && above !in NON_SOLID) continue
                bases.add(Triple(bx, ty, bz))
            }
        }

        if (bases.isEmpty()) return mutableListOf()

        val scored = bases.mapNotNull { pos ->
            val cx = pos.first + 0.5f
            val cy = pos.second + 2f
            val cz = pos.third + 0.5f
            val dmg = simulateExplosionDamage(cx, cy, cz)
            val eff = if (dmg.selfDamage > dmg.mostDamage && !suicide.value) -1f else dmg.mostDamage
            if (eff >= 0f || suicide.value) Pair(pos, eff) else null
        }

        val topPositions = scored
            .sortedByDescending { it.second }
            .take(placeCount.value)
            .map { it.first }

        val finalPositions = topPositions.ifEmpty { bases.take(placeCount.value) }
        return finalPositions.toMutableList()
    }

    private fun simulateExplosionDamage(cx: Float, cy: Float, cz: Float): ExplosionResult {
        val diameter = EXPLOSION_SIZE * 2f
        var selfDamage = 0f
        var mostDamage = 0f

        val selfDist = MathUtil.dist3(cx, cy, cz, EntityTracker.selfX, EntityTracker.selfY + 0.9f, EntityTracker.selfZ)
        if (selfDist <= diameter) {
            val exposure = exposureTo(cx, cy, cz, EntityTracker.selfX, EntityTracker.selfY, EntityTracker.selfZ)
            selfDamage = explosionDamage(selfDist, diameter, exposure)
        }

        for (p in EntityTracker.getPlayers(diameter)) {
            if (p.runtimeId == EntityTracker.selfRuntimeId) continue
            val dist = MathUtil.dist3(cx, cy, cz, p.x, p.y + 0.9f, p.z)
            if (dist > diameter) continue
            val exposure = exposureTo(cx, cy, cz, p.x, p.y, p.z)
            val dmg = explosionDamage(dist, diameter, exposure)
            if (dmg > mostDamage) mostDamage = dmg
        }

        return ExplosionResult(mostDamage, selfDamage)
    }

    private fun explosionDamage(distance: Float, diameter: Float, exposure: Float): Float {
        if (distance > diameter) return 0f
        val impact = (1f - distance / diameter) * exposure
        return (impact * impact + impact) / 2f * 7f * diameter + 1f
    }

    private fun exposureTo(cx: Float, cy: Float, cz: Float, tx: Float, ty: Float, tz: Float): Float {
        if (!WorldBlockTracker.hasAnyTerrainData()) return 1f
        val samples = arrayOf(
            Triple(tx, ty + 0.1f, tz),
            Triple(tx, ty + 0.9f, tz),
            Triple(tx, ty + 1.6f, tz),
            Triple(tx + 0.3f, ty + 0.9f, tz),
            Triple(tx - 0.3f, ty + 0.9f, tz)
        )
        var clear = 0
        for ((sx, sy, sz) in samples) {
            if (!isRayBlocked(cx, cy, cz, sx, sy, sz)) clear++
        }
        return clear.toFloat() / samples.size
    }

    private fun isRayBlocked(x0: Float, y0: Float, z0: Float, x1: Float, y1: Float, z1: Float): Boolean {
        val dist = MathUtil.dist3(x0, y0, z0, x1, y1, z1)
        if (dist < 0.01f) return false
        val steps = (dist * 2f).toInt().coerceIn(1, 40)
        for (i in 1 until steps) {
            val t = i.toFloat() / steps
            val bx = floor(x0 + (x1 - x0) * t).toInt()
            val by = floor(y0 + (y1 - y0) * t).toInt()
            val bz = floor(z0 + (z1 - z0) * t).toInt()
            val id = WorldBlockTracker.getBlockIdentifier(bx, by, bz) ?: continue
            if (id !in NON_SOLID) return true
        }
        return false
    }

    private fun searchPlaceBase(): List<Triple<Int, Int, Int>> {
        if (!WorldBlockTracker.hasAnyTerrainData()) return emptyList()
        val r  = floor(range.value).toInt()
        val vr = BASE_VERTICAL_RANGE
        val cx = floor(EntityTracker.selfX).toInt()
        val cy = floor(EntityTracker.selfY).toInt()
        val cz = floor(EntityTracker.selfZ).toInt()
        val bases = ArrayList<Triple<Int, Int, Int>>()
        for (x in cx - r..cx + r) {
            for (y in cy - vr..cy + vr) {
                for (z in cz - r..cz + r) {
                    val id = WorldBlockTracker.getBlockIdentifier(x, y, z) ?: continue
                    if (id != "minecraft:obsidian" && id != "minecraft:bedrock") continue
                    val above = WorldBlockTracker.getBlockIdentifier(x, y + 1, z)
                    if (above != null && above !in NON_SOLID) continue
                    bases.add(Triple(x, y, z))
                }
            }
        }
        return bases
    }

    private fun explodeCrystal(session: NoxNoRelaySession, runtimeId: Long) {
        CombatUtil.sendSwing(session)
        CombatUtil.sendAttack(session, runtimeId)
    }
}