package com.noxnoclient.module.visual

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Shader
import android.graphics.Typeface
import com.noxnoclient.module.BaseModule
import com.noxnoclient.module.ModuleCategory

class WatermarkModule : BaseModule(
    name = "Watermark",
    category = ModuleCategory.VISUAL,
    description = "Client watermark with optional smooth pulse animation"
) {
    private val text        = string("Text",        "NoxNoClient")
    private val showVersion = bool  ("Show Version", true)
    private val textSize    = float ("Text Size",    30f, 14f, 48f)
    private val rainbow     = bool  ("Rainbow",      true)
    private val pulse       = bool  ("Pulse",        true)
    private val scrollSpeed = float ("Scroll Speed", 120f, 0f, 400f)
    private val pulseHold   = float ("Pulse Hold (s)", 1.0f, 0.1f, 5.0f)
    private val pulseSpeed  = float ("Pulse Speed", 1.0f, 0.2f, 4.0f)
    private val background  = bool  ("Background",   true)
    private val bgOpacity   = float ("BG Opacity",   0.55f, 0f, 1f)

    companion object {
        private val RAINBOW_STOPS = intArrayOf(
            Color.rgb(255, 0, 0),
            Color.rgb(255, 140, 0),
            Color.rgb(255, 235, 0),
            Color.rgb(0, 230, 90),
            Color.rgb(0, 210, 210),
            Color.rgb(40, 90, 255),
            Color.rgb(180, 0, 255),
            Color.rgb(255, 0, 130),
            Color.rgb(255, 0, 0)
        )
        private const val RAINBOW_SPAN_PX  = 220f
        private const val VERSION_LABEL    = "v1.2"
    }

    private val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = android.graphics.Paint.Style.FILL
        color = android.graphics.Color.argb(140, 8, 8, 12)
    }
    private val reusableBgRect = android.graphics.RectF()
    private val mainPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        typeface = Typeface.create(Typeface.DEFAULT_BOLD, Typeface.BOLD)
        setShadowLayer(5f, 0f, 0f, Color.argb(210, 0, 0, 0))
    }
    private val versionPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
        color = Color.argb(210, 235, 235, 240)
        setShadowLayer(3f, 0f, 0f, Color.argb(180, 0, 0, 0))
    }

    private val rainbowShader = LinearGradient(
        0f, 0f, RAINBOW_SPAN_PX, 0f,
        RAINBOW_STOPS, null, Shader.TileMode.MIRROR
    )
    private val rainbowMatrix = Matrix()

    private var scrollPx = 0f
    private var lastFrameTimeNs = 0L

    override fun onEnable() {
        super.onEnable()
        scrollPx = 0f
        lastFrameTimeNs = 0L
    }

    fun render(canvas: Canvas, screenW: Int, screenH: Int) {
        if (!isEnabled) return

        val label = text.value.ifBlank { "NoxNoClient" }
        mainPaint.textSize = textSize.value

        if (rainbow.value) {
            val nowNs = System.nanoTime()
            val dt = if (lastFrameTimeNs == 0L) 0.016f else ((nowNs - lastFrameTimeNs) / 1_000_000_000f).coerceIn(0f, 0.1f)
            lastFrameTimeNs = nowNs
            scrollPx = (scrollPx + dt * scrollSpeed.value).mod(RAINBOW_SPAN_PX)

            rainbowMatrix.setTranslate(-scrollPx, 0f)
            rainbowShader.setLocalMatrix(rainbowMatrix)
            mainPaint.shader = rainbowShader
        } else {
            lastFrameTimeNs = 0L
            mainPaint.shader = null
            mainPaint.color = Color.rgb(0xF4, 0xF4, 0xF6)
        }

        if (rainbow.value && pulse.value) {
            val pulseTime = System.nanoTime() / 1_000_000_000.0
            val hold = pulseHold.value.coerceAtLeast(0.1f).toDouble()
            val speed = pulseSpeed.value.coerceAtLeast(0.2f).toDouble()
            val phase = pulseTime % (2.0 * hold + 2.0 / speed)
            val fadeDuration = 1.0 / speed
            val pulse = when {
                phase < hold -> 1.0
                phase < hold + fadeDuration -> {
                    val t = ((phase - hold) / fadeDuration).coerceIn(0.0, 1.0)
                    0.5 + 0.5 * kotlin.math.cos(Math.PI * t)
                }
                phase < 2.0 * hold + fadeDuration -> 0.0
                else -> {
                    val t = ((phase - 2.0 * hold - fadeDuration) / fadeDuration).coerceIn(0.0, 1.0)
                    0.5 - 0.5 * kotlin.math.cos(Math.PI * t)
                }
            }
            val green = (12.0 + 243.0 * pulse).toInt().coerceIn(0, 255)
            mainPaint.shader = null
            mainPaint.color = Color.rgb(0, green, 0)
        }

        val x = 16f
        val y = 16f - mainPaint.fontMetrics.ascent

        canvas.drawText(label, x, y, mainPaint)

        if (showVersion.value) {
            versionPaint.textSize = textSize.value * 0.42f
            val mainWidth = mainPaint.measureText(label)
            canvas.drawText(VERSION_LABEL, x + mainWidth + 8f, y, versionPaint)
        }

        if (background.value) {
            val totalWidth = mainPaint.measureText(label) +
                if (showVersion.value) (mainPaint.measureText(label) * 0f + 8f + versionPaint.measureText(VERSION_LABEL)) else 0f
            val fullW = mainPaint.measureText(label) +
                if (showVersion.value) (8f + versionPaint.measureText(VERSION_LABEL)) else 0f
            val top    = y + mainPaint.fontMetrics.ascent - 6f
            val bottom = y + mainPaint.fontMetrics.descent + 6f
            reusableBgRect.set(x - 10f, top, x + fullW + 10f, bottom)
            bgPaint.alpha = (255f * bgOpacity.value).toInt().coerceIn(0, 255)
            canvas.drawRoundRect(reusableBgRect, 8f, 8f, bgPaint)
            canvas.drawText(label, x, y, mainPaint)
            if (showVersion.value) canvas.drawText(VERSION_LABEL, x + mainPaint.measureText(label) + 8f, y, versionPaint)
        }
    }
}
