package com.noxnoclient.module.visual

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import com.noxnoclient.core.proxy.EntityTracker
import com.noxnoclient.module.BaseModule
import com.noxnoclient.module.ModuleCategory
import com.noxnoclient.module.social.isFriendEntity
import com.noxnoclient.utils.MathUtil
import com.noxnoclient.utils.UiUtil
import kotlin.math.abs

/** Independent target ring. It does not enable or depend on KillAura/TargetESP. */
class TargetCircle : BaseModule(
    name = "TargetCircle",
    category = ModuleCategory.VISUAL,
    description = "Shows a white circle around the nearest valid player"
) {
    private val range = float("Range", 64f, 8f, 256f)
    private val radius = float("Radius", 34f, 10f, 80f)
    private val thickness = float("Thickness", 3.5f, 1f, 8f)
    private val friendSkip = bool("Friend Skip", true)

    fun render(canvas: Canvas, screenW: Int, screenH: Int) {
        if (!isEnabled) return
        val selfX = EntityTracker.selfX
        val selfY = EntityTracker.selfY
        val selfZ = EntityTracker.selfZ
        val target = EntityTracker.getPlayers(range.value)
            .filter { !friendSkip.value || !it.isFriendEntity }
            .minByOrNull { MathUtil.dist3(it.x, it.y, it.z, selfX, selfY, selfZ) }
            ?: return

        val height = if (target.isSneaking) 1.5f else 1.8f
        val feet = MathUtil.worldToScreen(
            target.x, target.y, target.z, selfX, selfY, selfZ,
            EntityTracker.selfYaw, EntityTracker.selfPitch, screenW, screenH, UiUtil.currentFov
        ) ?: return
        val head = MathUtil.worldToScreen(
            target.x, target.y + height, target.z, selfX, selfY, selfZ,
            EntityTracker.selfYaw, EntityTracker.selfPitch, screenW, screenH, UiUtil.currentFov
        ) ?: return

        val projectedHeight = abs(feet.second - head.second)
        val ringRadius = (projectedHeight * 0.42f).coerceIn(radius.value * 0.55f, radius.value * 1.8f)
        val cx = (feet.first + head.first) * 0.5f
        val cy = (feet.second + head.second) * 0.5f

        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeWidth = thickness.value
            color = Color.WHITE
            alpha = 255
            setShadowLayer(7f, 0f, 0f, Color.BLACK)
        }
        canvas.drawCircle(cx, cy, ringRadius, paint)
    }
}
