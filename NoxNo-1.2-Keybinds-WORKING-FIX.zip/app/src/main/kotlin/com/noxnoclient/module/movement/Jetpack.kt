package com.noxnoclient.module.movement

import com.noxnoclient.core.proxy.EntityTracker
import com.noxnoclient.core.relay.NoxNoRelaySession
import com.noxnoclient.events.PacketEvent
import com.noxnoclient.module.*
import org.cloudburstmc.math.vector.Vector3f
import org.cloudburstmc.protocol.bedrock.data.PlayerAuthInputData
import org.cloudburstmc.protocol.bedrock.packet.PlayerAuthInputPacket
import org.cloudburstmc.protocol.bedrock.packet.SetEntityMotionPacket
import kotlin.math.cos
import kotlin.math.sin

class Jetpack : BaseModule(
    name        = "Jetpack",
    category    = ModuleCategory.MOVEMENT,
    description = "Applies a push via motion packet in the direction the character is looking while the jump key is held"
) {
    private val thrustSpeed = float("Thrust Speed", 0.55f, 0.1f, 1.5f)
    private val requireJump = bool ("Require Jump", true)
    private val interval    = int  ("Delay",        100,   50, 200)
    private val shortcut    = bool ("Shortcut",     false)

    @Volatile private var lastThrustMs = 0L
    @Volatile private var correctionCooldownUntil = 0L

    override fun onEnable() {
        super.onEnable()
        lastThrustMs = 0L
        correctionCooldownUntil = 0L
    }

    override fun onPacket(event: PacketEvent) {
        if (!isEnabled) return
        if (event.direction == PacketEvent.Direction.SERVER_TO_CLIENT) {
            if (event.packet is org.cloudburstmc.protocol.bedrock.packet.MovePlayerPacket &&
                (event.packet as org.cloudburstmc.protocol.bedrock.packet.MovePlayerPacket).runtimeEntityId == EntityTracker.selfRuntimeId) {
                correctionCooldownUntil = System.currentTimeMillis() + 350L
            }
            return
        }
        val pkt = event.packet
        if (pkt !is PlayerAuthInputPacket) return
        if (event.direction != PacketEvent.Direction.CLIENT_TO_SERVER) return
        if (System.currentTimeMillis() < correctionCooldownUntil) return

        val jumping = pkt.inputData.contains(PlayerAuthInputData.JUMPING) ||
                      pkt.inputData.contains(PlayerAuthInputData.WANT_UP)

        if (requireJump.value && !jumping) return

        val now = System.currentTimeMillis()
        if (now - lastThrustMs < interval.value) return
        lastThrustMs = now

        val pitch = Math.toRadians(pkt.rotation.x.toDouble()).toFloat()
        val yaw   = Math.toRadians(pkt.rotation.y.toDouble()).toFloat()

        val cosPitch = cos(pitch)

        val dirX = -sin(yaw) * cosPitch
        val dirY = -sin(pitch)
        val dirZ = cos(yaw) * cosPitch

        val motionPacket = SetEntityMotionPacket().apply {
            runtimeEntityId = EntityTracker.selfRuntimeId
            motion = Vector3f.from(
                dirX * thrustSpeed.value.coerceAtMost(0.75f),
                dirY * thrustSpeed.value.coerceAtMost(0.75f),
                dirZ * thrustSpeed.value.coerceAtMost(0.75f)
            )
        }

        event.session.clientBound(motionPacket)
    }
}
