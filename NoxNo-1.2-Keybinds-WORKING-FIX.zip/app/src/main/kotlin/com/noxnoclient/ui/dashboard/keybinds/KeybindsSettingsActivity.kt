package com.noxnoclient.ui.dashboard.keybinds

import android.content.Context
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.KeyEvent
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Switch
import androidx.fragment.app.Fragment
import com.noxnoclient.module.keybinds.KeybindsManager
import com.noxnoclient.module.keybinds.Keybind

/**
 * Fragment for managing keybinds in the dashboard
 */
class KeybindsSettingsFragment : Fragment() {

    private lateinit var keybindsContainer: LinearLayout

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return LinearLayout(requireContext()).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )

            // Title
            addView(TextView(requireContext()).apply {
                text = "Keybinds Settings"
                textSize = 24f
                setPadding(16, 16, 16, 16)
            })

            // Keybinds container
            keybindsContainer = LinearLayout(requireContext()).apply {
                orientation = LinearLayout.VERTICAL
                layoutParams = ViewGroup.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
                )
            }
            addView(keybindsContainer)

            // Refresh button
            addView(Button(requireContext()).apply {
                text = "Refresh Keybinds"
                setOnClickListener {
                    loadKeybinds()
                }
            })

            // Clear all button
            addView(Button(requireContext()).apply {
                text = "Clear All Keybinds"
                setOnClickListener {
                    KeybindsManager.clearAllKeybinds()
                    loadKeybinds()
                }
            })
        }
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        loadKeybinds()
    }

    private fun loadKeybinds() {
        keybindsContainer.removeAllViews()

        val allKeybinds = KeybindsManager.getAllKeybinds()

        if (allKeybinds.isEmpty()) {
            keybindsContainer.addView(TextView(requireContext()).apply {
                text = "No keybinds configured"
                setPadding(16, 8, 16, 8)
            })
            return
        }

        allKeybinds.values.forEach { keybind ->
            keybindsContainer.addView(createKeybindView(keybind))
        }
    }

    private fun createKeybindView(keybind: Keybind): View {
        return LinearLayout(requireContext()).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutParams = ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
            setPadding(16, 8, 16, 8)

            // Keybind info
            addView(LinearLayout(requireContext()).apply {
                orientation = LinearLayout.VERTICAL
                layoutParams = LinearLayout.LayoutParams(
                    0,
                    ViewGroup.LayoutParams.WRAP_CONTENT,
                    1f
                )

                addView(TextView(requireContext()).apply {
                    text = keybind.id
                    textSize = 16f
                })

                addView(TextView(requireContext()).apply {
                    text = "Key: ${KeyEvent.keyCodeToString(keybind.keyCode)} " +
                           "${if (keybind.requiresCtrl) "+ CTRL" else ""}" +
                           "${if (keybind.requiresShift) "+ SHIFT" else ""}" +
                           "${if (keybind.requiresAlt) "+ ALT" else ""}"
                    textSize = 12f
                })
            })

            // Active switch
            addView(Switch(requireContext()).apply {
                isChecked = keybind.isActive
                setOnCheckedChangeListener { _, isChecked ->
                    KeybindsManager.setKeybindActive(keybind.id, isChecked)
                }
            })
        }
    }
}


class KeybindsSettingsActivity : androidx.fragment.app.FragmentActivity() {
    override fun onCreate(savedInstanceState: android.os.Bundle?) {
        super.onCreate(savedInstanceState)
        supportFragmentManager.beginTransaction()
            .replace(android.R.id.content, KeybindsSettingsFragment())
            .commit()
    }
}
