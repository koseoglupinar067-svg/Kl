package com.noxnoclient.module.movement

import com.noxnoclient.core.proxy.EntityTracker
import com.noxnoclient.core.relay.NoxNoRelaySession
import com.noxnoclient.events.PacketEvent
import com.noxnoclient.module.*
import org.cloudburstmc.math.vector.Vector3f
import org.cloudburstmc.protocol.bedrock.data.Ability
import org.cloudburstmc.protocol.bedrock.data.AbilityLayer
import org.cloudburstmc.protocol.bedrock.data.PlayerAuthInputData
import org.cloudburstmc.protocol.bedrock.data.PlayerPermission
import org.cloudburstmc.protocol.bedrock.data.command.CommandPermission
import org.cloudburstmc.protocol.bedrock.packet.PlayerAuthInputPacket
import org.cloudburstmc.protocol.bedrock.packet.RequestAbilityPacket
import org.cloudburstmc.protocol.bedrock.packet.SetEntityMotionPacket
import org.cloudburstmc.protocol.bedrock.packet.UpdateAbilitiesPacket

class NoClipModule : BaseModule(
    name        = "NoClip",
    category    = ModuleCategory.MOVEMENT,
    description = "Pass through blocks via Ability.NO_CLIP + free vertical movement (Space/Shift)"
) {
    private val moveSpeed = float("Speed", 0.15f, 0.05f, 1.5f)
    private val motionInterval = int("Delay", 55, 15, 150)
    private val shortcut  = bool ("Shortcut", false)

    @Volatile private var noClipActive = false
    @Volatile private var lastSession: NoxNoRelaySession? = null
    @Volatile private var lastMotionMs = 0L

    override fun onEnable() {
        super.onEnable()
        noClipActive = false
        lastMotionMs = 0L
    }

    override fun onDisable() {
        lastSession?.let { disableAbilities(it) }
        noClipActive = false
        super.onDisable()
    }

    override fun onPacket(event: PacketEvent) {
        if (!isEnabled) return
        val pkt = event.packet

        if (pkt is RequestAbilityPacket && pkt.ability == Ability.NO_CLIP) {
            event.cancel()
            return
        }
        if (pkt is UpdateAbilitiesPacket) {
            event.cancel()
            return
        }

        if (pkt !is PlayerAuthInputPacket) return
        if (event.direction != PacketEvent.Direction.CLIENT_TO_SERVER) return

        lastSession = event.session

        if (!noClipActive) {
            enableAbilities(event.session)
            noClipActive = true
        }

        var verticalMotion = 0f
        if (pkt.inputData.contains(PlayerAuthInputData.JUMPING)) {
            verticalMotion = moveSpeed.value
        } else if (pkt.inputData.contains(PlayerAuthInputData.SNEAKING)) {
            verticalMotion = -moveSpeed.value
        }

        if (verticalMotion != 0f) {
            val now = System.currentTimeMillis()
            if (now - lastMotionMs >= motionInterval.value) {
                lastMotionMs = now
                event.session.clientBound(SetEntityMotionPacket().apply {
                    runtimeEntityId = EntityTracker.selfRuntimeId
                    motion = Vector3f.from(0f, verticalMotion, 0f)
                })
            }
        }
    }

    private fun enableAbilities(session: NoxNoRelaySession) {
        val packet = UpdateAbilitiesPacket().apply {
            playerPermission  = PlayerPermission.OPERATOR
            commandPermission = CommandPermission.OWNER
            uniqueEntityId    = EntityTracker.selfUniqueId
            abilityLayers.add(AbilityLayer().apply {
                layerType = AbilityLayer.Type.BASE
                abilitiesSet.addAll(Ability.entries.toTypedArray())
                abilityValues.addAll(
                    arrayOf(
                        Ability.BUILD, Ability.MINE, Ability.DOORS_AND_SWITCHES,
                        Ability.OPEN_CONTAINERS, Ability.ATTACK_PLAYERS, Ability.ATTACK_MOBS,
                        Ability.MAY_FLY, Ability.FLY_SPEED, Ability.WALK_SPEED,
                        Ability.OPERATOR_COMMANDS, Ability.NO_CLIP
                    )
                )
                walkSpeed = 0.1f
                flySpeed  = moveSpeed.value
            })
        }
        session.clientBound(packet)
    }

    private fun disableAbilities(session: NoxNoRelaySession) {
        val packet = UpdateAbilitiesPacket().apply {
            playerPermission  = PlayerPermission.OPERATOR
            commandPermission = CommandPermission.OWNER
            uniqueEntityId    = EntityTracker.selfUniqueId
            abilityLayers.add(AbilityLayer().apply {
                layerType = AbilityLayer.Type.BASE
                abilitiesSet.addAll(Ability.entries.toTypedArray())
                abilityValues.addAll(
                    arrayOf(
                        Ability.BUILD, Ability.MINE, Ability.DOORS_AND_SWITCHES,
                        Ability.OPEN_CONTAINERS, Ability.ATTACK_PLAYERS, Ability.ATTACK_MOBS,
                        Ability.FLY_SPEED, Ability.WALK_SPEED, Ability.OPERATOR_COMMANDS
                    )
                )
                walkSpeed = 0.1f
            })
        }
        session.clientBound(packet)
    }
}
