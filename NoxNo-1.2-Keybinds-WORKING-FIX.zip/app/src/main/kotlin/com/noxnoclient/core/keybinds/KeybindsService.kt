package com.noxnoclient.core.keybinds

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.AccessibilityServiceInfo
import android.content.Intent
import android.util.Log
import android.view.KeyEvent
import android.view.accessibility.AccessibilityEvent
import com.noxnoclient.module.keybinds.KeybindsManager

/**
 * Hardware-key keybind service.
 *
 * This uses Android AccessibilityService key filtering instead of an
 * InputMethodService. An InputMethodService is not a reliable way to receive
 * game keyboard events and cannot safely be instantiated with KeybindsService().
 */
class KeybindsService : AccessibilityService() {

    companion object {
        private const val TAG = "NoxNoKeybinds"

        fun isEnabled(context: android.content.Context): Boolean {
            return try {
                val manager = context.getSystemService(android.content.Context.ACCESSIBILITY_SERVICE)
                    as? android.view.accessibility.AccessibilityManager ?: return false
                manager.getEnabledAccessibilityServiceList(
                    AccessibilityServiceInfo.FEEDBACK_ALL_MASK
                ).any {
                    it.resolveInfo?.serviceInfo?.packageName == context.packageName &&
                        it.resolveInfo?.serviceInfo?.name == KeybindsService::class.java.name
                }
            } catch (_: Throwable) {
                false
            }
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()

        serviceInfo = AccessibilityServiceInfo().apply {
            eventTypes = AccessibilityEvent.TYPES_ALL_MASK
            feedbackType = AccessibilityServiceInfo.FEEDBACK_GENERIC
            flags = AccessibilityServiceInfo.FLAG_REQUEST_FILTER_KEY_EVENTS
        }

        Log.d(TAG, "Keybind accessibility service connected")
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // Deliberately empty. We only need the key-event filter.
    }

    override fun onInterrupt() {
        Log.d(TAG, "Keybind accessibility service interrupted")
    }

    override fun onKeyEvent(event: KeyEvent): Boolean {
        if (event.action != KeyEvent.ACTION_DOWN) return false
        if (event.repeatCount > 0) return false

        val meta = event.metaState
        val ctrl = (meta and KeyEvent.META_CTRL_ON) != 0
        val shift = (meta and KeyEvent.META_SHIFT_ON) != 0
        val alt = (meta and KeyEvent.META_ALT_ON) != 0

        KeybindsManager.onKeyEvent(event.keyCode, ctrl, shift, alt)

        // Return false so Minecraft still receives the physical key.
        return false
    }

    override fun onUnbind(intent: Intent?): Boolean {
        Log.d(TAG, "Keybind accessibility service unbound")
        return super.onUnbind(intent)
    }
}

/**
 * Kept for source compatibility with callers that used the old receiver.
 */
class KeybindsReceiver : android.content.BroadcastReceiver() {
    override fun onReceive(
        context: android.content.Context?,
        intent: Intent?
    ) {
        if (intent?.action != "com.noxnoclient.keybind.TRIGGER") return

        val id = intent.getStringExtra("keybind_id") ?: return
        val keybind = KeybindsManager.getKeybind(id) ?: return
        if (keybind.isActive) keybind.module.toggle()
    }
}
