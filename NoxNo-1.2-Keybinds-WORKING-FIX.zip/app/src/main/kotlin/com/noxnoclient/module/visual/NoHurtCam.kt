package com.noxnoclient.module.visual

import com.noxnoclient.core.proxy.EntityTracker
import com.noxnoclient.events.PacketEvent
import com.noxnoclient.module.BaseModule
import com.noxnoclient.module.ModuleCategory
import org.cloudburstmc.protocol.bedrock.packet.AnimatePacket
import org.cloudburstmc.protocol.bedrock.packet.EntityEventPacket

class NoHurtCam : BaseModule(
    name        = "NoHurtCam",
    category    = ModuleCategory.VISUAL,
    description = "Prevents head shake and screen shake from taking damage"
) {
    override fun onPacket(event: PacketEvent) {
        if (!isEnabled) return
        if (event.direction != PacketEvent.Direction.SERVER_TO_CLIENT) return

        when (val pkt = event.packet) {
            is EntityEventPacket -> {
                if (pkt.runtimeEntityId == EntityTracker.selfRuntimeId) {
                    val typeStr = runCatching { pkt.type?.toString()?.uppercase() ?: "" }.getOrElse { "" }
                    if (typeStr.contains("HURT")) {
                        event.cancel()
                    }
                }
            }
            is AnimatePacket -> {
                if (pkt.runtimeEntityId == EntityTracker.selfRuntimeId) {
                    val actionStr = runCatching { pkt.action?.toString()?.uppercase() ?: "" }.getOrElse { "" }
                    if (actionStr.contains("HURT")) {
                        event.cancel()
                    }
                }
            }
        }
    }
}
