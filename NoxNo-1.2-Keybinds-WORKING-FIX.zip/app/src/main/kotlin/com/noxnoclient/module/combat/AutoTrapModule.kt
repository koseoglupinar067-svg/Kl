package com.noxnoclient.module.combat

import com.noxnoclient.core.proxy.EntityTracker
import com.noxnoclient.events.PacketEvent
import com.noxnoclient.events.PacketEventBus
import com.noxnoclient.module.BaseModule
import com.noxnoclient.module.ModuleCategory
import com.noxnoclient.module.social.isFriendEntity
import com.noxnoclient.utils.InventoryUtil
import com.noxnoclient.utils.MathUtil
import com.noxnoclient.utils.WorldBlockTracker
import org.cloudburstmc.math.vector.Vector3i
import org.cloudburstmc.protocol.bedrock.packet.PlayerAuthInputPacket
import kotlin.math.floor

class AutoTrapModule : BaseModule(
    name        = "AutoTrap",
    category    = ModuleCategory.COMBAT,
    description = "Traps the opponent inside an obsidian box"
) {

    companion object {
        private val AIR_IDS = setOf(
            "minecraft:air","minecraft:cave_air","minecraft:void_air"
        )
        private val TRAP_OFFSETS = listOf(
            Triple(0, 0, 1), Triple(0, 0, -1),
            Triple(1, 0, 0), Triple(-1, 0, 0),
            Triple(0, 1, 1), Triple(0, 1, -1),
            Triple(1, 1, 0), Triple(-1, 1, 0),
            Triple(0, 2, 0),
            Triple(0, 1,  0)
        )
        private val FACE_OFFSETS = listOf(
            1 to Triple(0, 1, 0),
            2 to Triple(0, 0, -1),
            3 to Triple(0, 0, 1),
            4 to Triple(-1, 0, 0),
            5 to Triple(1, 0, 0),
            0 to Triple(0, -1, 0)
        )
    }

    private val range         = float("Range",         6f, 2f, 12f)
    private val placeDelay    = int  ("Place Delay",   100, 50, 500)
    private val blockId       = enum ("Block", BlockChoice.OBSIDIAN)
    private val includeCeiling= bool ("Ceiling",       true)
    private val ignoreFriends = bool ("Ignore Friends",true)
    private val shortcut      = bool ("Shortcut",      false)

    enum class BlockChoice(val id: String) {
        OBSIDIAN("minecraft:obsidian"),
        COBBLESTONE("minecraft:cobblestone")
    }

    private var lastPlaceMs = 0L
    private var targetQueue = ArrayDeque<Triple<Vector3i,String,Int>>()

    override fun onEnable() {
        super.onEnable()
        targetQueue.clear()
        PacketEventBus.register(this)
    }

    override fun onDisable() {
        PacketEventBus.unregister(this)
        targetQueue.clear()
        super.onDisable()
    }

    override fun onPacket(event: PacketEvent) {
        if (!isEnabled) return
        if (event.direction != PacketEvent.Direction.CLIENT_TO_SERVER) return
        if (event.packet !is PlayerAuthInputPacket) return

        val now = System.currentTimeMillis()
        if (now - lastPlaceMs < placeDelay.value) return

        val session = event.session
        val target = findTarget() ?: return
        val chosenId = blockId.value.id

        if (targetQueue.isEmpty()) {
            buildQueue(target)
        }
        if (targetQueue.isEmpty()) return

        val prepared = InventoryUtil.prepareItemForUse(session, chosenId) ?: return
        val (pos, supportId, face) = targetQueue.removeFirst()

        val placed = InventoryUtil.sendPlacementUseRaw(session, prepared, pos, supportId, face)
        if (placed) lastPlaceMs = now
        InventoryUtil.revert(session, prepared)
    }

    private fun buildQueue(target: EntityTracker.TrackedEntity) {
        val tx = floor(target.x).toInt()
        val ty = floor(target.y).toInt()
        val tz = floor(target.z).toInt()
        val offsets = if (includeCeiling.value) TRAP_OFFSETS else TRAP_OFFSETS.filter { it.second < 2 }

        for ((dx, dy, dz) in offsets) {
            val bx = tx + dx; val by = ty + dy; val bz = tz + dz

            val current = WorldBlockTracker.getBlockIdentifier(bx, by, bz)
            if (current != null && current !in AIR_IDS) continue
            val neighbor = resolvePlacementClick(bx, by, bz) ?: continue
            targetQueue.addLast(neighbor)
        }
    }

    private fun resolvePlacementClick(bx: Int, by: Int, bz: Int): Triple<Vector3i, String, Int>? {
        var anyDataFound = false
        for ((face, offset) in FACE_OFFSETS) {
            val nx = bx - offset.first
            val ny = by - offset.second
            val nz = bz - offset.third
            val id = WorldBlockTracker.getBlockIdentifier(nx, ny, nz) ?: continue
            anyDataFound = true
            if (id in AIR_IDS) continue
            return Triple(Vector3i.from(nx, ny, nz), id, face)
        }

        if (!anyDataFound) {
            return Triple(Vector3i.from(bx, by - 1, bz), "minecraft:obsidian", 1)
        }
        return null
    }

    private fun findTarget(): EntityTracker.TrackedEntity? {
        val sx = EntityTracker.selfX; val sy = EntityTracker.selfY; val sz = EntityTracker.selfZ
        return EntityTracker.getEntitiesInRange(range.value) { e ->
            e.runtimeId != EntityTracker.selfRuntimeId && e.isPlayer &&
                    !(ignoreFriends.value && e.isFriendEntity)
        }.minByOrNull { MathUtil.dist3sq(it.x, it.y, it.z, sx, sy, sz) }
    }
}
