package com.noxnoclient.core.relay

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetSocketAddress
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicBoolean

data class LanServerInfo(
    val host            : String,
    val port            : Int,
    val motd            : String,
    val subMotd         : String,
    val protocolVersion : Int,
    val mcVersion       : String,
    val playerCount     : Int,
    val maxPlayers      : Int,
    val lastSeenMs       : Long
)

object LanServerScanner {

    private const val TAG               = "LanServerScanner"
    private const val MC_PORT           = 19132
    private const val UNCONNECTED_PONG  = 0x1C.toByte()
    private const val SOCKET_TIMEOUT_MS = 2000
    private const val STALE_AFTER_MS    = 4000L
    private const val PRUNE_INTERVAL_MS = 1000L

    private const val SELF_SUB_MOTD = "NoxNoClient"

    private val running = AtomicBoolean(false)
    private var listenerThread: Thread? = null
    private var prunerThread  : Thread? = null

    private val discovered = ConcurrentHashMap<String, LanServerInfo>()

    private val _servers = MutableStateFlow<List<LanServerInfo>>(emptyList())
    val servers: StateFlow<List<LanServerInfo>> = _servers.asStateFlow()

    fun start() {
        if (running.getAndSet(true)) return
        discovered.clear()
        _servers.value = emptyList()
        startListener()
        startPruner()
    }

    fun stop() {
        if (!running.getAndSet(false)) return
        listenerThread?.interrupt(); listenerThread = null
        prunerThread?.interrupt();   prunerThread = null
        discovered.clear()
        _servers.value = emptyList()
    }

    val isRunning: Boolean get() = running.get()

    private fun startListener() {
        listenerThread = Thread({
            var socket: DatagramSocket? = null
            try {

                socket = DatagramSocket(null).apply {
                    reuseAddress = true
                    broadcast    = true
                    soTimeout    = SOCKET_TIMEOUT_MS
                    bind(InetSocketAddress(MC_PORT))
                }

                val buf = ByteArray(1024)
                while (running.get()) {
                    try {
                        val packet = DatagramPacket(buf, buf.size)
                        socket.receive(packet)
                        if (packet.length > 0 && buf[0] == UNCONNECTED_PONG) {
                            val host = packet.address?.hostAddress ?: continue
                            parsePong(buf, packet.length, host)
                        }
                    } catch (_: java.net.SocketTimeoutException) {
                    } catch (_: Exception) {
                    }
                }
            } catch (_: Exception) {
            } finally {
                try { socket?.close() } catch (_: Exception) {}
            }
        }, "NoxNoLan-Scanner").apply {
            isDaemon = true
            start()
        }
    }

    private fun startPruner() {
        prunerThread = Thread({
            while (running.get()) {
                try {
                    Thread.sleep(PRUNE_INTERVAL_MS)
                    val now = System.currentTimeMillis()
                    val removed = discovered.entries.removeIf { now - it.value.lastSeenMs > STALE_AFTER_MS }
                    if (removed) publish()
                } catch (_: InterruptedException) {
                    break
                } catch (_: Exception) {
                }
            }
        }, "NoxNoLan-ScannerPruner").apply {
            isDaemon = true
            start()
        }
    }

    private fun parsePong(buf: ByteArray, len: Int, host: String) {

        if (len < 35) return
        try {
            val bb = ByteBuffer.wrap(buf, 0, len).order(ByteOrder.BIG_ENDIAN)
            bb.get()
            bb.long
            bb.long
            bb.position(bb.position() + 16)
            val strLen = bb.short.toInt() and 0xFFFF
            if (bb.remaining() < strLen) return
            val strBytes = ByteArray(strLen)
            bb.get(strBytes)
            val parts = String(strBytes, Charsets.UTF_8).split(";")
            if (parts.size < 3 || parts[0] != "MCPE") return

            val motd            = parts.getOrNull(1) ?: ""
            val protocolVersion = parts.getOrNull(2)?.toIntOrNull() ?: 0
            val mcVersion       = parts.getOrNull(3) ?: ""
            val playerCount     = parts.getOrNull(4)?.toIntOrNull() ?: 0
            val maxPlayers      = parts.getOrNull(5)?.toIntOrNull() ?: 0
            val subMotd         = parts.getOrNull(7) ?: ""
            val port            = parts.getOrNull(10)?.toIntOrNull() ?: MC_PORT

            if (subMotd == SELF_SUB_MOTD) return

            val key = "$host:$port"
            discovered[key] = LanServerInfo(
                host            = host,
                port            = port,
                motd            = motd,
                subMotd         = subMotd,
                protocolVersion = protocolVersion,
                mcVersion       = mcVersion,
                playerCount     = playerCount,
                maxPlayers      = maxPlayers,
                lastSeenMs      = System.currentTimeMillis()
            )
            publish()
        } catch (_: Exception) {
        }
    }

    private fun publish() {
        _servers.value = discovered.values.sortedBy { it.motd.lowercase() }
    }
}
