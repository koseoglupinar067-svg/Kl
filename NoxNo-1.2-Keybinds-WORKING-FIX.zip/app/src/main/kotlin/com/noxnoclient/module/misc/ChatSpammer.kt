package com.noxnoclient.module.misc

import com.noxnoclient.core.proxy.EntityTracker
import com.noxnoclient.core.relay.NoxNoRelaySession
import com.noxnoclient.events.PacketEvent
import com.noxnoclient.module.BaseModule
import com.noxnoclient.module.ModuleCategory
import com.noxnoclient.module.social.isFriendEntity
import kotlinx.coroutines.Job
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import org.cloudburstmc.protocol.bedrock.packet.EntityEventPacket
import org.cloudburstmc.protocol.bedrock.packet.TextPacket
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.ConcurrentLinkedQueue
import kotlin.random.Random

class ChatSpammer : BaseModule(
    name        = "ChatSpammer",
    category    = ModuleCategory.MISC,
    description = "Drops a PVP message into chat on nearby kill/logout events"
) {
    companion object {
        private const val QUEUE_DELAY_MS = 700L
        private const val MAX_QUEUE_SIZE = 20
        private const val POLL_INTERVAL_MS = 500L
        private const val KILL_RANGE   = 8f
        private const val LOGOUT_RANGE = 12f
        private const val DEBOUNCE_MS  = 1000L

        private val JUNK_CHARS = "abcdefghjklmnopqrstuvwxyz0123456789"
        private val JUNK_RANGE = 10..18
        private const val INTERNAL_SOURCE = "__noxno_internal__"
    }

    private val chatSuffix      = bool  ("Chat Suffix",     false)
    private val announceKills   = bool  ("Announce Kills",   true)
    private val announceLogouts = bool  ("Announce Logouts", false)
    private val killMessage     = string("Kill Message",   ">(@here {name} ez clapped) | {junk} | NoxNo")
    private val logoutMessage   = string("Logout Message", ">({name} logged out, gg) | {junk} | NoxNo")
    private val shortcut        = bool  ("Shortcut", false)

    private val messageQueue = ConcurrentLinkedQueue<String>()
    private val lastEventMs  = ConcurrentHashMap<Long, Long>()
    private val knownNearby  = ConcurrentHashMap<Long, String>()

    private var flushJob: Job? = null
    private var pollJob: Job? = null
    @Volatile private var activeSession: NoxNoRelaySession? = null

    override fun onEnable() {
        super.onEnable()
        messageQueue.clear()
        lastEventMs.clear()
        knownNearby.clear()

        flushJob = scope.launch {
            while (currentCoroutineContext().isActive) {
                flushQueue()
                delay(QUEUE_DELAY_MS)
            }
        }
        pollJob = scope.launch {
            while (currentCoroutineContext().isActive) {
                pollLogouts()
                delay(POLL_INTERVAL_MS)
            }
        }
    }

    override fun onDisable() {
        flushJob?.cancel(); flushJob = null
        pollJob?.cancel(); pollJob = null
        messageQueue.clear()
        lastEventMs.clear()
        knownNearby.clear()
        super.onDisable()
    }

    override fun onPacket(event: PacketEvent) {
        if (!isEnabled) return
        activeSession = event.session

        if (event.direction == PacketEvent.Direction.CLIENT_TO_SERVER) {
            val out = event.packet
            if (chatSuffix.value && out is TextPacket &&
                out.type == TextPacket.Type.CHAT &&
                out.sourceName != INTERNAL_SOURCE
            ) {
                val original = out.message
                if (original.isNotBlank() && !original.trimEnd().endsWith("| NoxNo")) {
                    event.cancelAndReplace(buildTextPacket(
                        "$original | ${randomJunk()} | NoxNo",
                        sourceName = out.sourceName,
                        xuid = out.xuid,
                        platformChatId = out.platformChatId
                    ))
                }
            }
            return
        }

        if (!announceKills.value) return
        if (event.direction != PacketEvent.Direction.SERVER_TO_CLIENT) return

        val p = event.packet
        if (p !is EntityEventPacket) return
        if (p.runtimeEntityId == EntityTracker.selfRuntimeId) return

        val typeStr = runCatching { p.type?.toString()?.uppercase() ?: "" }.getOrElse { "" }
        if (!typeStr.contains("DEATH")) return

        val entity = EntityTracker.getById(p.runtimeEntityId) ?: return
        if (!entity.isPlayer || entity.isFriendEntity) return
        if (EntityTracker.distanceTo(entity) > KILL_RANGE) return
        if (!shouldFire(entity.runtimeId)) return

        val name = entity.name.takeIf { it.isNotEmpty() } ?: "unknown"
        enqueue(formatMessage(killMessage.value, name))
    }

    private fun pollLogouts() {
        if (!isEnabled) return

        val currentIds = HashSet<Long>()
        EntityTracker.getPlayers(LOGOUT_RANGE).forEach { e ->
            if (e.runtimeId == EntityTracker.selfRuntimeId) return@forEach
            if (e.isFriendEntity) return@forEach
            currentIds.add(e.runtimeId)
            knownNearby[e.runtimeId] = e.name.takeIf { it.isNotEmpty() } ?: "unknown"
        }

        if (announceLogouts.value) {
            for ((runtimeId, name) in knownNearby) {
                if (runtimeId in currentIds) continue
                if (!shouldFire(runtimeId)) continue
                enqueue(formatMessage(logoutMessage.value, name))
            }
        }

        knownNearby.keys.retainAll(currentIds)
    }

    private fun shouldFire(runtimeId: Long): Boolean {
        val now = System.currentTimeMillis()
        val last = lastEventMs[runtimeId]
        if (last != null && now - last < DEBOUNCE_MS) return false
        lastEventMs[runtimeId] = now
        return true
    }

    private fun flushQueue() {
        val session = activeSession ?: return
        if (!session.isServerReady) return
        val msg = messageQueue.poll() ?: return
        runCatching { session.sendToServer(buildTextPacket(msg)) }
    }

    private fun enqueue(message: String) {
        if (messageQueue.size >= MAX_QUEUE_SIZE) messageQueue.poll()
        messageQueue.offer(message)
    }

    private fun buildTextPacket(
        message: String,
        sourceName: String = INTERNAL_SOURCE,
        xuid: String = "",
        platformChatId: String = ""
    ): TextPacket = TextPacket().apply {
        type               = TextPacket.Type.CHAT
        isNeedsTranslation = false
        this.sourceName    = sourceName
        this.xuid          = xuid
        this.platformChatId = platformChatId
        setMessage(message)
        setFilteredMessage("")
    }

    private fun formatMessage(template: String, name: String): String {
        val random = randomJunk()
        return template
            .replace("{name}", name)
            .replace("{junk}", random)
            .replace("{random}", random)
            .replace("%random%", random)
            .replace("%rand%", random)
    }

    private fun randomJunk(): String {
        val len = Random.nextInt(JUNK_RANGE.first, JUNK_RANGE.last + 1)
        return buildString(len) { repeat(len) { append(JUNK_CHARS[Random.nextInt(JUNK_CHARS.length)]) } }
    }
}
