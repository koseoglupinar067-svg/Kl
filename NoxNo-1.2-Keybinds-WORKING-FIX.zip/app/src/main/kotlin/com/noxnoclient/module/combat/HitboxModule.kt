package com.noxnoclient.module.combat

import com.noxnoclient.core.proxy.EntityTracker
import com.noxnoclient.core.relay.NoxNoRelaySession
import com.noxnoclient.events.PacketEventBus
import com.noxnoclient.module.*
import kotlinx.coroutines.Job
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import org.cloudburstmc.protocol.bedrock.data.entity.EntityDataMap
import org.cloudburstmc.protocol.bedrock.data.entity.EntityDataTypes
import org.cloudburstmc.protocol.bedrock.packet.SetEntityDataPacket
import java.util.concurrent.ConcurrentHashMap

class HitboxModule : BaseModule(
    name        = "Hitbox",
    category    = ModuleCategory.COMBAT,
    description = "Enlarges targets' hitbox size (only on your own screen), increasing melee hit accuracy"
) {

    companion object {
        private const val DEFAULT_WIDTH = 0.6f
        private const val DEFAULT_HEIGHT = 1.8f
    }

    private val hitboxWidth      = float("Width",  1.5f, 0.5f, 12f)
    private val hitboxHeight     = float("Height", 1.5f, 0.5f, 12f)
    private val playersOnly      = bool ("Players Only", true)
    private val includeMobs      = bool ("Include Mobs", false)
    private val range            = float("Range", 12f, 2f, 32f)
    private val updateIntervalMs = int  ("Update Interval", 500, 100, 2000)
    private val shortcut = bool("Shortcut", false)

    private var tickJob: Job? = null
    private val expandedIds = ConcurrentHashMap.newKeySet<Long>()
    @Volatile private var lastAppliedWidth = -1f
    @Volatile private var lastAppliedHeight = -1f

    override fun onEnable() {
        super.onEnable()
        expandedIds.clear()
        lastAppliedWidth = -1f
        lastAppliedHeight = -1f
        tickJob = scope.launch { tickLoop() }
    }

    override fun onDisable() {
        tickJob?.cancel()
        tickJob = null
        PacketEventBus.currentSession?.let { resetAll(it) }
        expandedIds.clear()
        super.onDisable()
    }

    private suspend fun tickLoop() {
        while (currentCoroutineContext().isActive) {
            if (isEnabled) {
                PacketEventBus.currentSession?.let { applyToTargets(it) }
            }
            delay(updateIntervalMs.value.toLong())
        }
    }

    private fun applyToTargets(session: NoxNoRelaySession) {
        val targets = EntityTracker.getEntitiesInRange(range.value) { e ->
            e.runtimeId != EntityTracker.selfRuntimeId && e.isTarget()
        }
        val currentIds = targets.map { it.runtimeId }.toHashSet()

        val toReset = expandedIds.filter { it !in currentIds }
        for (id in toReset) {
            sendHitbox(session, id, DEFAULT_WIDTH, DEFAULT_HEIGHT)
            expandedIds.remove(id)
        }

        val settingsChanged = hitboxWidth.value != lastAppliedWidth || hitboxHeight.value != lastAppliedHeight
        for (t in targets) {
            val isNew = expandedIds.add(t.runtimeId)
            if (isNew || settingsChanged) {
                sendHitbox(session, t.runtimeId, hitboxWidth.value, hitboxHeight.value)
            }
        }
        lastAppliedWidth = hitboxWidth.value
        lastAppliedHeight = hitboxHeight.value
    }

    private fun sendHitbox(session: NoxNoRelaySession, runtimeId: Long, w: Float, h: Float) {
        val metadata = EntityDataMap()
        metadata.put(EntityDataTypes.WIDTH, w)
        metadata.put(EntityDataTypes.HEIGHT, h)
        metadata.put(EntityDataTypes.SCALE, 1.0f)
        session.clientBound(SetEntityDataPacket().apply {
            this.runtimeEntityId = runtimeId
            this.metadata = metadata
        })
    }

    private fun resetAll(session: NoxNoRelaySession) {
        for (id in expandedIds) sendHitbox(session, id, DEFAULT_WIDTH, DEFAULT_HEIGHT)
    }

    private fun EntityTracker.TrackedEntity.isTarget(): Boolean = when {
        isPlayer  -> playersOnly.value
        isHostile -> includeMobs.value
        else      -> false
    }
}
