package com.noxnoclient.module.keybinds

import android.view.KeyEvent
import com.noxnoclient.module.BaseModule
import java.util.concurrent.ConcurrentHashMap
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * Keybind Management System for NoxNo Client
 * Handles keyboard shortcuts for various features and modules
 */
data class Keybind(
    val id: String,
    val module: BaseModule,
    val keyCode: Int,
    val requiresCtrl: Boolean = false,
    val requiresShift: Boolean = false,
    val requiresAlt: Boolean = false,
    var isActive: Boolean = true
)

object KeybindsManager {
    private val keybinds = ConcurrentHashMap<String, Keybind>()
    private val keyListeners = mutableListOf<(Keybind) -> Unit>()
    private val _captureId = MutableStateFlow<String?>(null)
    val captureId: StateFlow<String?> = _captureId.asStateFlow()

    /**
     * Register a new keybind for a module
     */
    fun registerKeybind(
        keybindId: String,
        module: BaseModule,
        keyCode: Int,
        requiresCtrl: Boolean = false,
        requiresShift: Boolean = false,
        requiresAlt: Boolean = false
    ): Boolean {
        if (keybinds.containsKey(keybindId)) {
            return false // Keybind already exists
        }

        val keybind = Keybind(
            id = keybindId,
            module = module,
            keyCode = keyCode,
            requiresCtrl = requiresCtrl,
            requiresShift = requiresShift,
            requiresAlt = requiresAlt
        )

        keybinds[keybindId] = keybind
        return true
    }

    /**
     * Update an existing keybind
     */
    fun updateKeybind(
        keybindId: String,
        keyCode: Int,
        requiresCtrl: Boolean = false,
        requiresShift: Boolean = false,
        requiresAlt: Boolean = false
    ): Boolean {
        val keybind = keybinds[keybindId] ?: return false
        
        keybinds[keybindId] = keybind.copy(
            keyCode = keyCode,
            requiresCtrl = requiresCtrl,
            requiresShift = requiresShift,
            requiresAlt = requiresAlt
        )
        return true
    }

    /**
     * Remove a keybind
     */
    fun removeKeybind(keybindId: String): Boolean {
        return keybinds.remove(keybindId) != null
    }

    /**
     * Get a keybind by ID
     */
    fun getKeybind(keybindId: String): Keybind? {
        return keybinds[keybindId]
    }

    /**
     * Get all keybinds
     */
    fun getAllKeybinds(): Map<String, Keybind> {
        return keybinds.toMap()
    }

    /**
     * Enable/Disable a keybind
     */
    fun setKeybindActive(keybindId: String, active: Boolean): Boolean {
        val keybind = keybinds[keybindId] ?: return false
        keybinds[keybindId] = keybind.copy(isActive = active)
        return true
    }

    /**
     * Handle key event and trigger appropriate keybinds
     */
    fun onKeyEvent(keyCode: Int, ctrlPressed: Boolean, shiftPressed: Boolean, altPressed: Boolean) {
        keybinds.values.forEach { keybind ->
            if (keybind.isActive && 
                keybind.keyCode == keyCode &&
                keybind.requiresCtrl == ctrlPressed &&
                keybind.requiresShift == shiftPressed &&
                keybind.requiresAlt == altPressed) {
                
                // Trigger the keybind
                triggerKeybind(keybind)
            }
        }
    }

    /** Begin capturing the next hardware key for a keybind. */
    fun beginCapture(keybindId: String) {
        if (keybinds.containsKey(keybindId)) _captureId.value = keybindId
    }

    /** Cancel the active key capture. */
    fun cancelCapture() {
        _captureId.value = null
    }

    /**
     * Consume one key event while the dashboard/overlay is assigning a key.
     * Returns true when the event was used for capture.
     */
    fun captureKeyEvent(event: KeyEvent): Boolean {
        if (event.action != KeyEvent.ACTION_DOWN || event.repeatCount > 0) return false
        val id = _captureId.value ?: return false
        if (event.keyCode == KeyEvent.KEYCODE_BACK || event.keyCode == KeyEvent.KEYCODE_ESCAPE) {
            _captureId.value = null
            return true
        }
        val meta = event.metaState
        val ctrl = (meta and KeyEvent.META_CTRL_ON) != 0
        val shift = (meta and KeyEvent.META_SHIFT_ON) != 0
        val alt = (meta and KeyEvent.META_ALT_ON) != 0
        val updated = updateKeybind(id, event.keyCode, ctrl, shift, alt)
        _captureId.value = null
        return updated
    }

    /**
     * Add a listener for keybind events
     */
    fun addKeyListener(listener: (Keybind) -> Unit) {
        keyListeners.add(listener)
    }

    /**
     * Remove a listener
     */
    fun removeKeyListener(listener: (Keybind) -> Unit) {
        keyListeners.remove(listener)
    }

    /**
     * Trigger a keybind
     */
    private fun triggerKeybind(keybind: Keybind) {
        keybind.module.toggle()
        keyListeners.forEach { it(keybind) }
    }

    /**
     * Clear all keybinds
     */
    fun clearAllKeybinds() {
        keybinds.clear()
    }

    /**
     * Get keybind by module name
     */
    fun getKeybindsByModuleName(moduleName: String): List<Keybind> {
        return keybinds.values.filter { it.module.name == moduleName }
    }
}
