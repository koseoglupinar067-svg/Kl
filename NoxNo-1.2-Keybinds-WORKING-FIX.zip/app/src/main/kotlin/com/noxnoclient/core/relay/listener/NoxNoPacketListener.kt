package com.noxnoclient.core.relay.listener

import com.noxnoclient.core.relay.NoxNoRelaySession
import org.cloudburstmc.protocol.bedrock.packet.BedrockPacket

interface NoxNoPacketListener {

    fun onClientPacket(packet: BedrockPacket, session: NoxNoRelaySession): Boolean = true

    fun onServerPacket(packet: BedrockPacket, session: NoxNoRelaySession): Boolean = true

    fun onSessionStart(session: NoxNoRelaySession) {}

    fun onSessionEnd(session: NoxNoRelaySession) {}

    val priority: Int get() = 0
}
