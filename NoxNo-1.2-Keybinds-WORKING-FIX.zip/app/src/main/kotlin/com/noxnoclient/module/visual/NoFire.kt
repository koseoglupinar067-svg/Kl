package com.noxnoclient.module.visual

import com.noxnoclient.core.proxy.EntityTracker
import com.noxnoclient.events.PacketEvent
import com.noxnoclient.module.BaseModule
import com.noxnoclient.module.ModuleCategory
import org.cloudburstmc.protocol.bedrock.packet.EntityEventPacket

/** Suppresses fire-related entity events for the local player when supported by the protocol. */
class NoFire : BaseModule(
    name = "NoFire",
    category = ModuleCategory.VISUAL,
    description = "Hides local fire effects"
) {
    override fun onPacket(event: PacketEvent) {
        if (!isEnabled || event.direction != PacketEvent.Direction.SERVER_TO_CLIENT) return
        val packet = event.packet as? EntityEventPacket ?: return
        if (packet.runtimeEntityId != EntityTracker.selfRuntimeId) return
        val type = runCatching { packet.type?.toString()?.uppercase().orEmpty() }.getOrDefault("")
        if (type.contains("FIRE") || type.contains("ON_FIRE")) event.cancel()
    }
}
