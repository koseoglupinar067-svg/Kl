package com.noxnoclient.module.combat

import com.noxnoclient.core.proxy.EntityTracker
import com.noxnoclient.core.relay.NoxNoRelaySession
import com.noxnoclient.events.PacketEvent
import com.noxnoclient.events.PacketEventBus
import com.noxnoclient.module.*
import com.noxnoclient.utils.InventoryUtil
import org.cloudburstmc.protocol.bedrock.data.inventory.ContainerId
import org.cloudburstmc.protocol.bedrock.data.inventory.ContainerSlotType
import org.cloudburstmc.protocol.bedrock.data.inventory.ItemData
import org.cloudburstmc.protocol.bedrock.packet.*

class AutoTotem : BaseModule(
    name        = "AutoTotem",
    category    = ModuleCategory.COMBAT,
    description = "Continuously equips the totem in the offhand"
) {

    override val priority = 0
    private val shortcut = bool("Shortcut", false)

    companion object {

        private const val RESEND_COOLDOWN_MS = 50L

        private const val SAFETY_TICK_MS = 20L
    }

    @Volatile private var tickJob: kotlinx.coroutines.Job? = null
    @Volatile private var totemSlot      = -1
    @Volatile private var offhandHasTotem = false
    @Volatile private var lastSendMs      = 0L

    override fun onEnable() {
        super.onEnable()
        totemSlot     = -1
        offhandHasTotem = false
        lastSendMs    = 0L
        refreshFromSnapshot()
        if (!offhandHasTotem && totemSlot >= 0) equipTotem()
        tickJob = launchTickLoop(SAFETY_TICK_MS) { tickCheck() }
    }

    override fun onDisable() {
        tickJob?.cancel()
        tickJob = null
        super.onDisable()
    }

    private fun refreshFromSnapshot() {
        val snapshot = EntityTracker.getInventorySnapshot()
        offhandHasTotem = InventoryUtil.isTotem(snapshot[InventoryUtil.OFFHAND_SLOT])
        totemSlot = -1
        for (slot in InventoryUtil.HOTBAR_START..InventoryUtil.INV_END) {
            if (InventoryUtil.isTotem(snapshot[slot])) { totemSlot = slot; break }
        }
    }

    private fun tickCheck() {

        val hasTotemNow = InventoryUtil.isTotem(EntityTracker.getInventoryItem(InventoryUtil.OFFHAND_SLOT))
        offhandHasTotem = hasTotemNow
        if (hasTotemNow) return

        if (totemSlot < 0 || !InventoryUtil.isTotem(EntityTracker.getInventoryItem(totemSlot))) refreshFromSnapshot()
        if (totemSlot < 0) return

        val now = System.currentTimeMillis()
        if (now - lastSendMs < RESEND_COOLDOWN_MS) return
        equipTotem()
    }

    override fun onPacket(event: PacketEvent) {
        if (!isEnabled) return

        when (val pkt = event.packet) {
            is InventoryContentPacket -> {
                when (pkt.containerId) {
                    0 -> {
                        totemSlot = -1
                        pkt.contents.forEachIndexed { slot, item ->
                            if (totemSlot == -1 && InventoryUtil.isTotem(item)) totemSlot = slot
                        }
                        if (!offhandHasTotem && totemSlot >= 0) equipTotem()
                    }
                    InventoryUtil.OFFHAND_SLOT -> {
                        val nowHasTotem = InventoryUtil.isTotem(pkt.contents.firstOrNull())
                        offhandHasTotem = nowHasTotem
                        if (!nowHasTotem && totemSlot >= 0) equipTotem()
                    }
                }
            }

            is InventorySlotPacket -> {
                if (pkt.containerId == InventoryUtil.OFFHAND_SLOT) {
                    val nowHasTotem = InventoryUtil.isTotem(pkt.item)
                    offhandHasTotem = nowHasTotem
                    if (!nowHasTotem && totemSlot >= 0) equipTotem()
                } else if (pkt.containerId == 0) {
                    if (InventoryUtil.isTotem(pkt.item)) {
                        if (totemSlot == -1) totemSlot = pkt.slot
                    } else if (totemSlot == pkt.slot) {
                        totemSlot = -1
                        refreshFromSnapshot()
                    }
                }
            }

            is EntityEventPacket -> {
                if (pkt.runtimeEntityId != EntityTracker.selfRuntimeId) return
                val type = runCatching { pkt.type?.toString()?.uppercase() ?: "" }.getOrElse { "" }
                if (type.contains("CONSUME") || type.contains("TOTEM")) {
                    offhandHasTotem = false
                    totemSlot = -1
                    refreshFromSnapshot()

                    if (totemSlot >= 0) equipTotem()
                }
            }
        }
    }

    private fun equipTotem() {
        val slot = totemSlot
        if (slot < 0) return

        val itemData = EntityTracker.getInventoryItem(slot)
        if (itemData == null || !InventoryUtil.isTotem(itemData)) { totemSlot = -1; return }

        val session = PacketEventBus.currentSession ?: return
        val offhandItem = EntityTracker.getInventoryItem(InventoryUtil.OFFHAND_SLOT) ?: ItemData.AIR

        lastSendMs = System.currentTimeMillis()

        InventoryUtil.sendInventoryMove(
            session           = session,
            sourceContainer   = ContainerSlotType.HOTBAR_AND_INVENTORY,
            sourceContainerId = 0,
            sourceSlot        = slot,
            sourceItem        = itemData,
            destContainer     = ContainerSlotType.OFFHAND,
            destContainerId   = ContainerId.OFFHAND,
            destSlot          = 0,
            destItem          = offhandItem
        )
    }
}
